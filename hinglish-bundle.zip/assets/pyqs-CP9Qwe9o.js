import"./apk-shell-DT9v0LPh.js";var e={msn:{id:`msn`,name:`Medical-Surgical Nursing - II`,shortName:`MSN-II`,badge:`Adult Health & Specialties`,code:`NTRUHS / MPMSU 3rd Year`,desc:`Oncology, Burns, Ophthalmology, ENT, Neurology, Critical Care & Geriatric Nursing`,icon:`activity`,color:`#8E74E5`,papers:[{year:`2025`,session:`Supplementary Examination`,title:`MSN-II Feb 2025 (Supp) Question Paper`,file:`/pyqs/msn/msn-2025-supp.pdf`,date:`February 2025`,totalMarks:75,duration:`3 Hours`,badge:`Latest Exam Paper`},{year:`2022`,session:`Main & Supplementary`,title:`MSN-II July 2022 (Main) Question Paper`,file:`/pyqs/msn/msn-2022-main.pdf`,date:`July 2022`,totalMarks:75,duration:`3 Hours`,badge:`Core Annual`},{year:`2020`,session:`Main Examination`,title:`MSN-II Feb 2020 (Main) Question Paper`,file:`/pyqs/msn/msn-2020-main.pdf`,date:`February 2020`,totalMarks:75,duration:`3 Hours`,badge:`Core Annual`},{year:`2019`,session:`Main Examination`,title:`MSN-II May 2019 (Main) Question Paper`,file:`/pyqs/msn/msn-2019-main.pdf`,date:`May 2019`,totalMarks:75,duration:`3 Hours`,badge:`Benchmark Paper`}],topics:[{id:`grp-burns`,title:`Burns & Emergency Burn Management`,repeatCount:4,years:[`2019`,`2020`,`2022`,`2025`],probability:98,priorityTier:`Tier 1 • Guaranteed`,tierClass:`tier-guaranteed`,subItems:[{concept:`Definition, etiology, depth classification & Rule of Nines`,years:`2019, 2020, 2025`},{concept:`Emergency medical & fluid resuscitation for 45% burns (Parkland formula)`,years:`2020, 2025`},{concept:`Priority nursing interventions across emergency, acute, and rehabilitative phases`,years:`2020, 2022`}],questions:[{paperBadge:`MPMSU Feb 2025 (Supp) — Q.1 [10 Marks]`,weight:`Essay Question | Target: 4–5 Handwritten Pages`,questionText:`a. Define Burn (2) | b. Write the types of burn (2) | c. Discuss the emergency management of patient with 45% of burns (6).`},{paperBadge:`MPMSU Feb 2020 (Main) — Q.4 [14 Marks]`,weight:`Full Long Essay | Target: 5 Handwritten Pages`,questionText:`a. Define burn (2) | b. Enlist the causes and clinical manifestation of burn (3) | c. Explain degree of burn (3) | d. Discuss the Immediate Medical management and Nursing Management based on priority needs (6).`},{paperBadge:`MPMSU May 2019 (Main) — Q.4 [5 Marks]`,weight:`Short Answer Question | Target: 2–3 Handwritten Pages`,questionText:`a. Define Burn (2) | b. Write down the classification of burn (3).`},{paperBadge:`MPMSU July 2022 (Main & Supp) — Q.5f [5 Marks]`,weight:`Short Note | Target: 2–3 Handwritten Pages`,questionText:`Short Note: Management of Patient with burn (5 Marks).`}],answerHtml:`<div class="concept-card">
  <div class="concept-title">1. Definition of Burn</div>
  <div class="concept-body">
    <p><strong>Burn:</strong> Burn injuries occur when energy from a heat source is transferred to the tissues of the body. Heat may be transferred through conduction or electromagnetic radiation. Injuries that result from direct contact with or exposure to any <strong>thermal, chemical, electrical, or radiation</strong> sources are termed as burns.</p>
    <p><strong>Scald:</strong> A scald is a burn caused by contact with a hot liquid or steam (e.g., hot water, oil, or steam), though the term "burn" is often used to include scalds.</p>
    <p>Tissue destruction results from <strong>coagulation, protein denaturation, or ionization of cellular contents</strong>. The skin (epidermal tissue and dermis) and mucosa of the upper airways are the primary sites of tissue destruction. Rarely deeper tissues such as muscle, bone, and blood vessels are involved.</p>
    <p><strong>Types of Injury:</strong></p>
    <ul>
      <li><strong>(A) The Primary Injury:</strong> The immediate damage caused by the burn. Prompt removal of the heat source and rapid cooling limits the extent of primary injury.</li>
      <li><strong>(B) The Secondary Injury:</strong> Deleterious effects resulting from the primary injury, such as fluid loss, secondary infection, release of toxins, inflammatory response, fluid shift, coagulopathy, edema, and constriction caused by burn eschar.</li>
    </ul>
  </div>
</div>

<div class="concept-card">
  <div class="concept-title">2. Causes of Burns</div>
  <div class="concept-body">
    <div class="exam-svg-box">
      <svg viewBox="0 0 420 230" width="380" height="210" xmlns="http://www.w3.org/2000/svg">
        <polygon points="210,48 232,102 290,102 243,136 261,192 210,158 159,192 177,136 130,102 188,102" fill="rgba(56,189,248,0.18)" stroke="currentColor" stroke-width="2"/>
        <text x="210" y="128" text-anchor="middle" fill="currentColor" font-size="14" font-weight="700">Burns</text>
        <text x="210" y="34" text-anchor="middle" fill="currentColor" font-size="13" font-weight="600">(1) Thermal Burn</text>
        <text x="352" y="106" text-anchor="middle" fill="currentColor" font-size="13" font-weight="600">(2) Chemical Burn</text>
        <text x="295" y="212" text-anchor="middle" fill="currentColor" font-size="13" font-weight="600">(4) Radiation Burn</text>
        <text x="125" y="212" text-anchor="middle" fill="currentColor" font-size="13" font-weight="600">(3) Electrical Burn</text>
        <text x="64" y="106" text-anchor="middle" fill="currentColor" font-size="13" font-weight="600">(5) Inhalation Injury</text>
      </svg>
      <div class="exam-svg-caption">Fig: Major Causes of Burns (Draw in Exam)</div>
    </div>
    <ul>
      <li><strong>(1) Thermal Burn:</strong> Caused by exposure to or contact with flame, hot liquids, semi-liquids (steam), semi-solids (tar), or hot objects (e.g., residential fire, automobile accidents, scalds, clothing ignition).</li>
      <li><strong>(2) Chemical Burn:</strong> Caused by tissue contact with strong acids (sulfuric acid, hydrofluoric acid), alkalis (sodium hydroxide), or organic compounds.</li>
      <li><strong>(3) Electrical Burn:</strong> Caused by heat generated as electrical energy passes through the body (faulty wiring, high-voltage lines, workplace injuries, defibrillation without conductive gel). Deep tissues and viscera can be damaged.</li>
      <li><strong>(4) Radiation Burn:</strong> Caused by protracted exposure to UV light (sunburn — UVA &amp; UVB), tanning booths, radiation therapy, radioactive substances, and X-rays.</li>
      <li><strong>(5) Inhalation Injury:</strong> Upper airway (supraglottic) or lower airway injury from smoke poisoning, asphyxiants, and direct thermal injury to lung tissue causing ARDS (50–60% of fire deaths are secondary to inhalation injury).</li>
    </ul>
  </div>
</div>

<div class="concept-card">
  <div class="concept-title">3. Classification of Burns</div>
  <div class="concept-body">
    <p><strong>(A) According to the Burn Depth:</strong></p>
    <div class="exam-svg-box">
      <svg viewBox="0 0 460 175" width="430" height="165" xmlns="http://www.w3.org/2000/svg">
        <rect x="20" y="38" width="420" height="28" fill="rgba(56,189,248,0.12)" stroke="currentColor" stroke-width="1"/>
        <rect x="20" y="66" width="420" height="44" fill="rgba(56,189,248,0.06)" stroke="currentColor" stroke-width="1"/>
        <rect x="20" y="110" width="420" height="26" fill="rgba(255,255,255,0.03)" stroke="currentColor" stroke-width="1"/>
        <rect x="20" y="136" width="420" height="24" fill="rgba(239,68,68,0.08)" stroke="currentColor" stroke-width="1"/>
        <text x="28" y="56" fill="currentColor" font-size="11.5" font-weight="600">Epidermis</text>
        <text x="28" y="92" fill="currentColor" font-size="11.5" font-weight="600">Dermis</text>
        <text x="28" y="127" fill="currentColor" font-size="11.5" font-weight="600">Subcutaneous fat</text>
        <text x="28" y="152" fill="currentColor" font-size="11.5" font-weight="600">Muscle</text>
        <!-- Depth indicators -->
        <line x1="170" y1="22" x2="170" y2="66" stroke="#38bdf8" stroke-width="2.5"/>
        <text x="170" y="16" text-anchor="middle" fill="currentColor" font-size="11" font-weight="700">1st° Superficial</text>
        <line x1="265" y1="22" x2="265" y2="110" stroke="#fbbf24" stroke-width="2.5"/>
        <text x="265" y="16" text-anchor="middle" fill="currentColor" font-size="11" font-weight="700">2nd° Partial</text>
        <line x1="350" y1="22" x2="350" y2="136" stroke="#f87171" stroke-width="2.5"/>
        <text x="350" y="16" text-anchor="middle" fill="currentColor" font-size="11" font-weight="700">3rd° Full</text>
        <line x1="418" y1="22" x2="418" y2="160" stroke="#ef4444" stroke-width="2.5"/>
        <text x="418" y="16" text-anchor="middle" fill="currentColor" font-size="11" font-weight="700">4th° Deep</text>
      </svg>
      <div class="exam-svg-caption">Fig: Classification of Burn Depth Across Skin Layers</div>
    </div>
    <ul>
      <li><strong>(1) Superficial Partial Thickness / First-Degree Burns:</strong> Involves only the outer layer of skin (epidermis), e.g., sunburn.
        <br>• <em>Signs and Symptoms:</em> Pink to reddish color (erythema), blanches on light pressure, pain, minor swelling; skin is dry without blisters.
        <br>• <em>Healing Time:</em> About 3 to 6 days; superficial skin peels off in 1–2 days without scarring.</li>
      <li><strong>(2) Deep Partial Thickness / Second-Degree Burns:</strong> Affects both epidermis and underlying dermis, often involving sweat glands and hair follicles.
        <br>• <em>Signs and Symptoms:</em> Bright pink to cherry-red color, <strong>fluid-filled blisters (bullae)</strong>, severe pain, redness, and swelling; wet weeping surface if blisters break.
        <br>• <em>Healing Time:</em> 1 to 3 weeks (may produce scarring; if infected, can convert to third-degree).</li>
      <li><strong>(3) Full Thickness / Third-Degree Burns:</strong> Destroys epidermis, dermis, and hypodermis; coagulated vessels visible beneath skin.
        <br>• <em>Signs and Symptoms:</em> Dry, waxy white, leathery, brown, or charred appearance; <strong>little or no pain / numb</strong> because nerve endings are destroyed.
        <br>• <em>Healing Time:</em> Very slow; requires skin grafting and reconstructive surgery; causes extensive scarring.</li>
      <li><strong>(4) Fourth-Degree Burns:</strong> Extends into underlying fascia, muscle, bone, and tendons. Wound is blackened and depressed, sensation completely absent; amputation may be required.</li>
    </ul>

    <p><strong>(B) According to the Burn Severity:</strong></p>
    <ul>
      <li><strong>Minor Burns:</strong> All 1st-degree burns and 2nd-degree burns involving &lt;10% TBSA.</li>
      <li><strong>Moderate Burns:</strong> 2nd-degree burns &gt;10% TBSA, or superficial partial-thickness burns of head, hands, feet, or perineum.</li>
      <li><strong>Severe Burns:</strong> Burns involving &ge;25% TBSA, all 3rd-degree burns (&gt;10% TBSA), deep burns of face/hands/feet/perineum, inhalation injury, chemical or high-voltage electrical burns.</li>
    </ul>

    <p><strong>(C) According to the Extent of Body Surface Area (TBSA):</strong></p>
    <ul>
      <li><strong>(1) Rule of Nines (Alexander Wallace):</strong> Quick method assigning multiples of 9% to major body areas in adults:
        <br>• Head &amp; Neck = <strong>9%</strong> (Child: 18%)
        <br>• Anterior Chest &amp; Abdomen = <strong>18%</strong> | Posterior Back = <strong>18%</strong>
        <br>• Right Arm = <strong>9%</strong> | Left Arm = <strong>9%</strong>
        <br>• Right Leg = <strong>18%</strong> (Child: 13.5%) | Left Leg = <strong>18%</strong> (Child: 13.5%)
        <br>• Perineum / Genitalia = <strong>1%</strong> (Total = 100%)</li>
      <li><strong>(2) Lund and Browder Method:</strong> More precise method accounting for age-related differences in head and leg proportions (revised on day 2–3 post-burn).</li>
      <li><strong>(3) Palm Method:</strong> Used for scattered burns; size of the patient's own palm (including fingers) = approximately <strong>1% TBSA</strong>.</li>
    </ul>

    <p><strong>(4) Jackson's Burn Model (3 Concentric Zones):</strong></p>
    <div class="exam-svg-box">
      <svg viewBox="0 0 360 160" width="320" height="145" xmlns="http://www.w3.org/2000/svg">
        <ellipse cx="180" cy="80" rx="155" ry="66" fill="rgba(16,185,129,0.12)" stroke="#34d399" stroke-width="1.8"/>
        <ellipse cx="180" cy="80" rx="102" ry="44" fill="rgba(251,191,36,0.14)" stroke="#fbbf24" stroke-width="1.8"/>
        <ellipse cx="180" cy="80" rx="52" ry="24" fill="rgba(239,68,68,0.22)" stroke="#f87171" stroke-width="1.8"/>
        <text x="180" y="77" text-anchor="middle" fill="currentColor" font-size="11" font-weight="700">Zone of</text>
        <text x="180" y="90" text-anchor="middle" fill="currentColor" font-size="11" font-weight="700">Coagulation</text>
        <text x="180" y="47" text-anchor="middle" fill="currentColor" font-size="11" font-weight="600">Zone of Stasis</text>
        <text x="180" y="25" text-anchor="middle" fill="currentColor" font-size="11" font-weight="600">Zone of Hyperaemia</text>
      </svg>
      <div class="exam-svg-caption">Fig: Jackson's Burn Wound Model</div>
    </div>
    <ul>
      <li><strong>Zone of Coagulation (Central):</strong> Severe irreversible damage from primary injury; tissue will slough out.</li>
      <li><strong>Zone of Stasis (Surrounding):</strong> Impaired vascularity and inflammation; potentially recoverable with proper fluid resuscitation (can convert to necrosis if hypovolemia/infection occurs).</li>
      <li><strong>Zone of Hyperaemia (Outer):</strong> Intense vasodilation and increased blood flow; recovers spontaneously.</li>
    </ul>
  </div>
</div>

<div class="concept-card">
  <div class="concept-title">4. Pathophysiology &amp; Physiologic Alterations</div>
  <div class="concept-body">
    <p>Burns &le;25% TBSA produce a primarily local response. Burns <strong>&gt;25% TBSA</strong> produce both local and systemic responses (cytokine release, capillary permeability leak, third-spacing of plasma fluid into interstitial tissue).</p>
    <p><strong>Physiologic Alterations:</strong></p>
    <ul>
      <li>Loss of protective barriers against infection</li>
      <li>Escape of body fluids &amp; electrolytes (hypovolemic shock stage &rarr; followed by diuretic stage)</li>
      <li>Lack of temperature control (hypothermia risk)</li>
      <li>Destroyed sweat and sebaceous glands</li>
      <li>Decrease in sensory receptors</li>
    </ul>
  </div>
</div>

<div class="concept-card">
  <div class="concept-title">5. Emergency Medical &amp; Nursing Management (45% TBSA Burns)</div>
  <div class="concept-body">
    <p><strong>A. Immediate First Aid &amp; Airway (ABC):</strong></p>
    <ul>
      <li>Extinguish flames (Stop, Drop, Roll), remove smoldering clothes and jewelry, cool with clean tap water (15–20°C; avoid ice), cover with clean dry sterile sheet.</li>
      <li>Assess for inhalation injury (facial burns, singed nasal hairs, hoarseness, stridor); give 100% humidified O2 and prepare for early intubation.</li>
    </ul>
    <p><strong>B. Fluid Resuscitation (Parkland / Baxter Formula):</strong></p>
    <div class="calc-box">
      <strong>Formula:</strong> <code>4 mL &times; Body Weight (kg) &times; %TBSA</code> of Ringer's Lactate (RL) in 24 hours.<br>
      <em>Example for 60 kg adult with 45% burns:</em> 4 &times; 60 &times; 45 = <strong>10,800 mL RL</strong><br>
      &bull; <strong>First 8 hours (from time of burn):</strong> Give 50% = <strong>5,400 mL</strong><br>
      &bull; <strong>Next 16 hours:</strong> Give remaining 50% = <strong>5,400 mL</strong><br>
      &bull; <strong>Monitoring Target:</strong> Maintain hourly urine output at <strong>30–50 mL/hr (0.5–1 mL/kg/hr)</strong>.
    </div>
    <p><strong>C. Medications &amp; Wound Care:</strong></p>
    <ul>
      <li><strong>Analgesia:</strong> IV Morphine Sulfate (2–4 mg) titrated slowly (never IM/SC during shock).</li>
      <li><strong>Prophylaxis:</strong> Tetanus Toxoid 0.5 mL IM; IV Pantoprazole to prevent Curling's stress ulcer.</li>
      <li><strong>Topical &amp; Surgical Care:</strong> 1% Silver Sulfadiazine (SSD) cream, strict aseptic dressing, escharotomy for circumferential burns, and split-thickness skin grafting (STSG).</li>
    </ul>
    <p><strong>D. Priority Nursing Diagnoses &amp; Interventions:</strong></p>
    <ol>
      <li><strong>Ineffective Airway Clearance:</strong> Elevate head, 100% humidified O2, monitor ABG &amp; SpO2, suction as needed.</li>
      <li><strong>Deficient Fluid Volume:</strong> Two large-bore IV cannulas (16G), infuse RL per Parkland formula, strict hourly urine output &amp; vital signs monitoring.</li>
      <li><strong>Acute Pain:</strong> Assess pain score, administer IV opioids 30 min before dressing, prevent drafts over exposed wounds.</li>
      <li><strong>Risk for Infection:</strong> Reverse isolation, sterile technique, daily wound culture &amp; inspection, high-protein/high-calorie diet (3,000–5,000 kcal/day).</li>
    </ol>
  </div>
</div>`},{id:`grp-onco`,title:`Oncology & Cancer Nursing`,repeatCount:4,years:[`2019`,`2020`,`2022`,`2025`],probability:98,priorityTier:`Tier 1 • Guaranteed`,tierClass:`tier-guaranteed`,subItems:[{concept:`Benign vs malignant differentiation, TNM staging & warning signs`,years:`2022, 2025`},{concept:`Chemotherapy side effects, extravasation & bone marrow nadir management`,years:`2020, 2022`},{concept:`Organ cancers & surgery: Stomach (gastrectomy), Breast (mastectomy), Larynx (laryngectomy)`,years:`2019, 2020, 2025`}],questions:[{paperBadge:`MPMSU Feb 2025 (Supp) — Q.2 [15 Marks]`,weight:`Full Long Essay | Target: 5 Handwritten Pages`,questionText:`a. Define Cancer (2) | b. Differentiate between Benign and Malignant tumors (5) | c. Enlist the clinical manifestations of Cancer (3) | d. Discuss the nursing management of patient with cancer stomach (5).`},{paperBadge:`MPMSU July 2022 (Main & Supp) — Q.3 [10 Marks]`,weight:`Essay Question | Target: 4 Handwritten Pages`,questionText:`a. Difference between benign and malignant tumour (3) | b. Write warning signs of cancer (2) | c. Write side effect of chemotherapy (5).`},{paperBadge:`MPMSU Feb 2020 (Main) — Q.2 [11 Marks]`,weight:`Full Essay | Target: 4–5 Handwritten Pages`,questionText:`a. Define Carcinoma of Breast (2) | b. Write down clinical manifestation and diagnostic evaluation of breast cancer (4) | c. Discuss the management of breast cancer and prepare nursing care plan for a patient with Modified Radical Mastectomy (5).`},{paperBadge:`MPMSU May 2019 (Main) — Q.2 [15 Marks]`,weight:`Full Long Essay | Target: 5 Handwritten Pages`,questionText:`a. Define laryngeal cancer (2) | b. List down the clinical manifestation and diagnostic evaluation of laryngeal cancer (5) | c. Write down the medical and nursing management of patient with total laryngectomy (8).`}],answerHtml:`<!-- ======================================================== -->
        <!-- CATEGORIZED CLINICAL CONCEPTS & MEDICAL EXPLANATIONS     -->
        <!-- ======================================================== -->
        <div class="concept-category-title">Categorized Clinical Guide & Oncology Breakdown</div>

        <!-- 1. CARCINOGENESIS & METASTATIC CASCADE -->
        <div class="concept-card">
          <div class="concept-title">1. Cellular Carcinogenesis & The Multistep Metastatic Cascade</div>
          <div class="concept-body">
            <p><strong>The Hallmarks of Cancer (Hanahan & Weinberg):</strong> Cancer arises from acquired genetic mutations in proto-oncogenes (activating gain-of-function, e.g., <em>HER2, KRAS</em>) and tumor suppressor genes (inactivating loss-of-function, e.g., <em>TP53, BRCA1/2</em>). Neoplastic cells acquire six fundamental biological capabilities: (1) Self-sufficiency in growth signals, (2) Insensitivity to anti-growth signals, (3) Evasion of apoptosis, (4) Limitless replicative potential (telomerase activation), (5) Sustained angiogenesis (VEGF secretion), and (6) Tissue invasion and distant metastasis.</p>
            
            <table class="clinical-table" style="margin-top: 10px;">
              <thead>
                <tr><th>Phase</th><th>Biological Mechanism</th><th>Cellular Manifestation</th><th>Clinical & Chemotherapeutic Target</th></tr>
              </thead>
              <tbody>
                <tr>
                  <td><strong>1. Initiation</strong></td>
                  <td>Carcinogen exposure (chemical, radiation, oncogenic HPV/EBV) induces permanent DNA mutations.</td>
                  <td>Proto-oncogene activation (RAS, HER2) or tumor suppressor inactivation (p53, BRCA1/2).</td>
                  <td>Irreversible. Primary prevention: tobacco cessation, HPV vaccination, occupational protective gear.</td>
                </tr>
                <tr>
                  <td><strong>2. Promotion</strong></td>
                  <td>Epigenetic stimulation promoting accelerated clonal proliferation of mutated pre-neoplastic cells.</td>
                  <td>Sustained mitotic division driven by hormonal stimulation (estrogen in ER+ breast cancer) or chronic inflammation.</td>
                  <td><strong>Reversible phase.</strong> Antihormonal therapy (Tamoxifen, Letrozole) blocks receptor-mediated promotion.</td>
                </tr>
                <tr>
                  <td><strong>3. Progression</strong></td>
                  <td>Genomic instability produces phenotypic heterogeneity, high invasiveness, and loss of apoptotic checkpoints.</td>
                  <td>Marked cellular atypia, pleomorphism, high nuclear-to-cytoplasmic ratio, and uncontrolled growth.</td>
                  <td>Cytotoxic chemotherapy (Alkylating agents, Antimetabolites like 5-FU, Taxanes) disrupts cell division.</td>
                </tr>
                <tr>
                  <td><strong>4. Angiogenesis & Invasion</strong></td>
                  <td>Tumor hypoxia triggers vascular endothelial growth factor (VEGF) secretion; cells secrete matrix metalloproteinases.</td>
                  <td>Neovascularization of fragile capillaries; basement membrane and extracellular matrix enzymatic degradation.</td>
                  <td>Anti-angiogenic monoclonal antibodies (Bevacizumab) inhibit tumor vessel formation.</td>
                </tr>
                <tr>
                  <td><strong>5. Metastasis</strong></td>
                  <td>Intravasation into blood/lymphatic channels, survival against sheer stress, extravasation into distant capillary beds.</td>
                  <td>Colonization of distant target organs (Bone, Brain, Liver, Lung &mdash; the "BBLL" rule of metastasis).</td>
                  <td>Systemic chemotherapy, targeted biological therapies, and palliative radiation to bone metastases.</td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>

        <!-- 2. BREAST & AXILLARY LYMPHATIC NETWORK -->
        <div class="concept-card">
          <div class="concept-title">2. Breast & Axillary Lymphatic Network (Surgical Oncology & Lymphedema Care)</div>
          <div class="concept-body">
            <p>The lymphatic system is the primary route for regional breast cancer dissemination. Understanding nodal levels dictates surgical staging and determines lifelong nursing precautions post-mastectomy:</p>
            
            <img src="/pyqs/images/breast_lymph_nodes.svg" class="med-img" style="max-height: 420px; object-fit: contain; background: #ffffff; padding: 14px; border-radius: 8px;" alt="Breast and Axillary Lymphatic Network (Cancer Research UK)">
            
            <div class="img-notes">
              <strong>Clinical Surgical Oncology & Nursing Implications (CRUK Standards):</strong>
              <br>&bull; <strong>Axillary Node Levels:</strong> Level I (lateral to pectoralis minor), Level II (deep to pectoralis minor), and Level III (medial/subclavicular to pectoralis minor). More than 75% of breast lymph drains into the ipsilateral axillary chain; 20% drains to internal mammary nodes.
              <br>&bull; <strong>Sentinel Lymph Node Biopsy (SLNB):</strong> Identification and excision of the first tumor-draining node using Technetium-99m sulfur colloid radiotracer and Isosulfan Blue dye spares women unnecessary complete axillary dissection if negative.
              <br>&bull; <strong>Lymphedema Prevention Guidelines (Mandatory Nursing Protocol):</strong> Following axillary lymph node dissection (ALND), place a sign above the patient's bed: <em>"NO VENIPUNCTURE, NO IV INFUSIONS, NO BLOOD PRESSURE READINGS, NO INJECTIONS ON THE OPERATIVE ARM."</em> Elevate affected arm on a pillow above heart level to facilitate lymphatic return; encourage gentle ball squeezing and progressive wall climbing exercises starting on post-op day 1–2.
            </div>
          </div>
        </div>

        <!-- 3. TNM STAGING & CHEMOTHERAPY PROTOCOLS -->
        <div class="concept-card">
          <div class="concept-title">3. TNM Clinical Staging Classification & Chemotherapy Protocols</div>
          <div class="concept-body">
            <p><strong>The TNM Staging Classification System (AJCC / UICC):</strong></p>
            <ul>
              <li><strong>T (Primary Tumor Size & Local Extent):</strong> TX (cannot assess), T0 (no evidence), Tis (carcinoma in situ), T1–T4 (progressive increase in tumor size and depth of anatomical wall invasion).</li>
              <li><strong>N (Regional Lymph Node Involvement):</strong> NX (nodes cannot assess), N0 (no regional lymph node metastasis), N1–N3 (increasing number and regional stations of involved nodes).</li>
              <li><strong>M (Distant Hematogenous Metastasis):</strong> M0 (no distant metastasis), M1 (distant organ metastasis present—automatically designates <strong>Stage IV Disease</strong>).</li>
            </ul>

            <p style="margin-top: 10px;"><strong>Classes of Antineoplastic Chemotherapy & Mechanisms:</strong></p>
            <ul>
              <li><em>Alkylating Agents (Cyclophosphamide, Cisplatin):</em> Form covalent bonds with DNA, causing cross-linking and strand breaks. (Non-cell-cycle specific).</li>
              <li><em>Antimetabolites (Methotrexate, 5-Fluorouracil):</em> Inhibit essential enzymes in purine/pyrimidine synthesis; halt DNA replication in <strong>S-Phase</strong>.</li>
              <li><em>Plant Alkaloids (Vincristine, Paclitaxel):</em> Bind to tubulin and disrupt mitotic spindle formation, halting mitosis in <strong>M-Phase</strong>.</li>
              <li><em>Antitumor Antibiotics (Doxorubicin / Adriamycin):</em> Intercalate between DNA base pairs and inhibit Topoisomerase II. (Cardiotoxic).</li>
            </ul>

            <div class="callout" style="margin-top: 12px;">
              <strong>Vesicant Extravasation Emergency Protocol:</strong>
              <br>1. <strong>STOP INFUSION IMMEDIATELY:</strong> Do not remove cannula.
              <br>2. <strong>Aspirate:</strong> Attempt to aspirate remaining drug/blood through IV catheter.
              <br>3. <strong>Administer Antidote:</strong> (e.g., Dexrazoxane for Anthracyclines; Hyaluronidase for Vinca alkaloids).
              <br>4. <strong>Thermal Dressing:</strong> Cold compress for Doxorubicin (localizes drug); Warm compress for Vincristine (disperses drug).
              <br>5. <strong>Elevate Extremity:</strong> Elevate arm for 48 hours; document wound dimensions.
            </div>
          </div>
        </div>

        <!-- ======================================================== -->
        <!-- SECTION B: PAST UNIVERSITY EXAM QUESTIONS & ANSWERS      -->
        <!-- ======================================================== -->
        <div class="section-divider-title">Exact University Exam Questions & 2–5 Page Model Answers</div>

        <!-- QUESTION 1: FEB 2025 (SUPP) Q.2 [15 MARKS] -->
        <div class="q-block">
          <div class="q-header">
            <span class="q-badge">MPMSU Feb 2025 (Supp) — Q.2 [15 Marks]</span>
            <span class="q-weight">Full Long Essay | Target: 5 Handwritten Pages</span>
          </div>
          <div class="q-text-prompt">
            <strong>Exam Question:</strong> a. Define Cancer (2) | b. Differentiate between Benign and Malignant tumors (5) | c. Enlist the clinical manifestations of Cancer (3) | d. Discuss the nursing management of patient with cancer stomach (5).
          </div>
          <div class="q-answer-content">
            <div class="ans-part">
              <div class="ans-part-title">Part (a): Definition of Cancer (2 Marks)</div>
              <div class="ans-part-body">
                <p><strong>Cancer (Neoplasia):</strong> A broad group of diseases characterized by unregulated, uncontrolled cellular proliferation, loss of normal contact inhibition, evasion of apoptosis, accelerated angiogenesis, and the ability to invade surrounding anatomical structures and metastasize to distant organ sites via hematogenous or lymphatic pathways.</p>
              </div>
            </div>

            <div class="ans-part">
              <div class="ans-part-title">Part (b): Differentiation Between Benign and Malignant Tumors (5 Marks)</div>
              <div class="ans-part-body">
                <table class="clinical-table">
                  <thead>
                    <tr>
                      <th style="width: 20%;">Feature</th>
                      <th style="width: 40%;">Benign Tumor (e.g., Lipoma, Fibroma)</th>
                      <th style="width: 40%;">Malignant Tumor (e.g., Carcinoma, Sarcoma)</th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr>
                      <td><strong>Differentiation / Anaplasia</strong></td>
                      <td>Well-differentiated; cells closely resemble normal parent tissue architecture and function.</td>
                      <td>Poorly differentiated or undifferentiated (anaplastic); atypical polymorphic cellular structure with pleomorphism.</td>
                    </tr>
                    <tr>
                      <td><strong>Rate of Growth</strong></td>
                      <td>Slow, progressive growth; may remain stationary or regress.</td>
                      <td>Rapid, erratic growth with high mitotic index and abnormal mitotic figures.</td>
                    </tr>
                    <tr>
                      <td><strong>Local Invasion & Encapsulation</strong></td>
                      <td>Cohesive, expansive growth; enclosed in a true fibrous capsule; does not infiltrate surrounding tissues.</td>
                      <td>Infiltrative and destructive; non-encapsulated; penetrates basement membranes and lymphovascular spaces.</td>
                    </tr>
                    <tr>
                      <td><strong>Metastasis</strong></td>
                      <td>Never metastasizes; remains localized to tissue of origin.</td>
                      <td>Frequently metastasizes via lymphatic channels and blood vessels to distant organs (liver, lungs, bone, brain).</td>
                    </tr>
                    <tr>
                      <td><strong>Systemic Effects & Prognosis</strong></td>
                      <td>Usually localized effects (pressure symptoms); rarely fatal unless located in critical brain areas.</td>
                      <td>Severe systemic effects (cancer cachexia, anemia, paraneoplastic syndromes); fatal if untreated.</td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>

            <div class="ans-part">
              <div class="ans-part-title">Part (c): Clinical Manifestations of Cancer & CAUTION Acronym (3 Marks)</div>
              <div class="ans-part-body">
                <p>The American Cancer Society defines the 7 universal warning signs of cancer via the mnemonic <strong>CAUTION</strong>:</p>
                <ul>
                  <li><strong>C:</strong> Change in bowel or bladder habits (e.g., alternating diarrhea and constipation in colorectal carcinoma; hematuria in bladder cancer).</li>
                  <li><strong>A:</strong> A sore that does not heal (e.g., non-healing oral ulcer in squamous cell carcinoma).</li>
                  <li><strong>U:</strong> Unusual bleeding or discharge (e.g., postmenopausal vaginal bleeding in cervical/endometrial cancer; hemoptysis in bronchogenic carcinoma).</li>
                  <li><strong>T:</strong> Thickening or lump in the breast, testicle, or elsewhere.</li>
                  <li><strong>I:</strong> Indigestion or difficulty in swallowing (dysphagia in esophageal or gastric cancer).</li>
                  <li><strong>O:</strong> Obvious change in a wart or mole (ABCDE criteria for melanoma: Asymmetry, Border irregularity, Color variation, Diameter &gt;6mm, Evolving).</li>
                  <li><strong>N:</strong> Nagging cough or persistent hoarseness (laryngeal or lung cancer).</li>
                </ul>
                <p><em>Constitutional Symptoms:</em> Unexplained rapid weight loss (&gt;10% in 6 months), severe asthenia/fatigue, night sweats, low-grade fever, and anemia (Cancer Cachexia Syndrome mediated by TNF-alpha/cachectin).</p>
              </div>
            </div>

            <div class="ans-part">
              <div class="ans-part-title">Part (d): Nursing Management of Patient with Stomach Cancer (Gastric Adenocarcinoma) (5 Marks)</div>
              <div class="ans-part-body">
                <p>Stomach cancer typically requires surgical resection (Subtotal or Total Gastrectomy). Nursing management encompasses pre-operative, post-operative, and long-term nutritional rehabilitation:</p>
                
                <p><strong>1. Post-Operative Clinical Interventions:</strong></p>
                <ul>
                  <li><strong>Nasogastric (NG) Tube Management:</strong>
                    <ul>
                      <li>Secure and monitor low intermittent suction to keep surgical suture lines decompressed.</li>
                      <li>Drainage is initially bloody for the first 12–24 hours, transitioning to normal bile-stained brownish/green.</li>
                      <li><em>CRITICAL SAFETY RULE:</em> NEVER irrigate, reposition, or reinsert the NG tube if dislodged, as this can tear the fresh gastric anastomosis, causing catastrophic peritonitis.</li>
                    </ul>
                  </li>
                  <li><strong>Prevention of Pulmonary Complications:</strong> Patient has a high upper abdominal incision causing splinting and hypoventilation; encourage incentive spirometry q1h, splinted coughing with an abdominal pillow, and early ambulation on POD 1.</li>
                  <li><strong>Pain Control:</strong> Continuous epidural analgesia or IV patient-controlled analgesia (PCA) with Fentanyl/Morphine to facilitate deep breathing and mobility.</li>
                </ul>

                <p><strong>2. Management & Prevention of Dumping Syndrome:</strong></p>
                <div class="callout">
                  <strong>DUMPING SYNDROME PROTOCOL:</strong> Rapid hyperosmolar gastric emptying into the jejunum draws fluid from the intravascular space into the bowel lumen, causing autonomic hypovolemia and reactive hypoglycemia (weakness, palpitations, diaphoresis, cramping, explosive diarrhea 15–30 min post-prandial).
                  <br>&bull; Provide 6 small, dry, frequent meals daily.
                  <br>&bull; Strictly separate liquids from solids: No fluids 30–60 minutes before, during, or after meals.
                  <br>&bull; Diet: High protein, moderate fat, strictly low in simple refined carbohydrates/sugars.
                  <br>&bull; Patient must lie flat (supine or semi-recumbent) for 20–30 minutes immediately following meals to delay transit.
                </div>

                <p><strong>3. Long-Term Lifelong Nursing Considerations:</strong></p>
                <ul>
                  <li><strong>Vitamin B12 Deficiency (Pernicious Anemia):</strong> Total gastrectomy removes all parietal cells, eliminating Intrinsic Factor (IF). Educate patient on the mandatory need for monthly lifelong intramuscular Vitamin B12 (Cyanocobalamin 1000 mcg IM) injections.</li>
                  <li><strong>Iron & Calcium Supplementation:</strong> Absence of gastric acid reduces iron ionization; monitor for microcytic anemia and osteoporosis.</li>
                </ul>
              </div>
            </div>
          </div>
        </div>

        <!-- QUESTION 2: JULY 2022 (MAIN) Q.3 [10 MARKS] -->
        <div class="q-block">
          <div class="q-header">
            <span class="q-badge">MPMSU July 2022 (Main & Supp) — Q.3 [10 Marks]</span>
            <span class="q-weight">Essay Question | Target: 4 Handwritten Pages</span>
          </div>
          <div class="q-text-prompt">
            <strong>Exam Question:</strong> a. Difference between benign and malignant tumour (3) | b. Write warning signs of cancer (2) | c. Write side effect of chemotherapy (5).
          </div>
          <div class="q-answer-content">
            <div class="ans-part">
              <div class="ans-part-title">Part (a): Difference Between Benign and Malignant Tumours (3 Marks)</div>
              <div class="ans-part-body">
                <table class="clinical-table">
                  <thead>
                    <tr><th>Parameter</th><th>Benign Tumour</th><th>Malignant Tumour</th></tr>
                  </thead>
                  <tbody>
                    <tr><td><strong>Capsule</strong></td><td>Well-encapsulated by fibrous tissue.</td><td>Non-encapsulated; irregular infiltrative margins.</td></tr>
                    <tr><td><strong>Histology</strong></td><td>Cells normal in size/shape; normal N:C ratio (1:4).</td><td>Marked pleomorphism; enlarged hyperchromatic nuclei; high N:C ratio (1:1).</td></tr>
                    <tr><td><strong>Invasion & Metastasis</strong></td><td>No local invasion; zero metastasis.</td><td>Invades surrounding tissue; metastasizes via blood/lymphatics.</td></tr>
                    <tr><td><strong>Recurrence</strong></td><td>Rare after complete surgical excision.</td><td>Frequent local recurrence and distant metastasis.</td></tr>
                  </tbody>
                </table>
              </div>
            </div>

            <div class="ans-part">
              <div class="ans-part-title">Part (b): Warning Signs of Cancer (2 Marks)</div>
              <div class="ans-part-body">
                <p>The 7 universal warning signs (mnemonic <strong>CAUTION</strong>):</p>
                <ol>
                  <li><strong>C</strong> - Change in bowel or bladder habits.</li>
                  <li><strong>A</strong> - A sore that fails to heal.</li>
                  <li><strong>U</strong> - Unusual bleeding or discharge from any body orifice.</li>
                  <li><strong>T</strong> - Thickening or lump in breast, testicle, or soft tissue.</li>
                  <li><strong>I</strong> - Indigestion or difficulty swallowing (dysphagia).</li>
                  <li><strong>O</strong> - Obvious change in a wart, mole, or skin pigmentation.</li>
                  <li><strong>N</strong> - Nagging persistent cough or hoarseness of voice.</li>
                </ol>
              </div>
            </div>

            <div class="ans-part">
              <div class="ans-part-title">Part (c): Side Effects of Chemotherapy & Nursing Management (5 Marks)</div>
              <div class="ans-part-body">
                <p>Chemotherapeutic antineoplastic agents act on rapidly dividing cells, producing toxicities across multiple organ systems:</p>
                <table class="clinical-table">
                  <thead>
                    <tr>
                      <th style="width: 25%;">Toxicity / Side Effect</th>
                      <th style="width: 45%;">Clinical Mechanism & Manifestation</th>
                      <th style="width: 30%;">Priority Nursing Interventions</th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr>
                      <td><strong>Bone Marrow Suppression (Myelosuppression)</strong></td>
                      <td>Destruction of hematopoietic stem cells leads to nadir (lowest blood counts) typically at 7–14 days post-chemo:
                        <br>&bull; <em>Neutropenia (ANC &lt;1000/mm3):</em> Severe risk of life-threatening bacteremia/sepsis.
                        <br>&bull; <em>Thrombocytopenia (Platelets &lt;50,000/mm3):</em> Spontaneous petechiae, ecchymosis, mucosal bleeding.
                        <br>&bull; <em>Anemia (Hb &lt;8 g/dL):</em> Extreme fatigue, dyspnea, pallor.
                      </td>
                      <td>
                        &bull; Enforce neutropenic precautions: Reverse isolation, strict hand hygiene, no fresh flowers, thoroughly cooked foods only.<br>
                        &bull; Check temperature q4h; temp &gt;38.0°C (100.4°F) is a medical emergency.<br>
                        &bull; Administer G-CSF (Filgrastim) as ordered.<br>
                        &bull; Bleeding precautions: Soft toothbrush, electric razor, no IM injections.
                      </td>
                    </tr>
                    <tr>
                      <td><strong>Gastrointestinal: CINV & Mucositis</strong></td>
                      <td>Chemotherapy-Induced Nausea & Vomiting (CINV) triggered by CTZ stimulation. Mucositis/stomatitis caused by epithelial sloughing throughout GI tract.</td>
                      <td>
                        &bull; Pre-medicate with 5-HT3 antagonists (Ondansetron 8 mg IV) + Dexamethasone 30 min before infusion.<br>
                        &bull; Bland mouth rinses with normal saline or sodium bicarbonate q2h; avoid alcohol-based mouthwashes.<br>
                        &bull; Magic mouthwash (viscous lidocaine, diphenhydramine, antacid) before meals.
                      </td>
                    </tr>
                    <tr>
                      <td><strong>Alopecia</strong></td>
                      <td>Atrophy and breakage of hair root shafts at follicular level (reversible 1–2 months post-chemotherapy).</td>
                      <td>
                        &bull; Reassure patient that hair regrowth occurs.<br>
                        &bull; Recommend scalp hypothermia (cold caps) during infusion; suggest wigs, scarves, gentle baby shampoo.
                      </td>
                    </tr>
                    <tr>
                      <td><strong>Vesicant Extravasation</strong></td>
                      <td>Accidental leakage of vesicants (Doxorubicin, Vincristine) into subcutaneous tissue causes severe blistering, tissue ulceration, and necrosis.</td>
                      <td>
                        &bull; <strong>STOP INFUSION IMMEDIATELY.</strong><br>
                        &bull; Leave cannula in place; aspirate residual drug; administer antidote (Dexrazoxane for anthracyclines, Hyaluronidase for vinca alkaloids).<br>
                        &bull; Elevate limb; apply cold/warm compress per drug protocol.
                      </td>
                    </tr>
                    <tr>
                      <td><strong>Organ-Specific Toxicities</strong></td>
                      <td>&bull; Cardiotoxicity: Doxorubicin (Adriamycin) - lifetime cumulative dose limit &lt;550 mg/m2.<br>&bull; Nephrotoxicity: Cisplatin (requires vigorous hydration).<br>&bull; Hemorrhagic Cystitis: Cyclophosphamide (prevented with MESNA).</td>
                      <td>
                        &bull; Baseline 2D Echocardiogram / LVEF monitoring.<br>
                        &bull; Force IV fluids 2–3 L/day; administer MESNA as uroprotective agent.
                      </td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </div>

        <!-- QUESTION 3: FEB 2020 (MAIN) Q.2 [11 MARKS] -->
        <div class="q-block">
          <div class="q-header">
            <span class="q-badge">MPMSU Feb 2020 (Main) — Q.2 [11 Marks]</span>
            <span class="q-weight">Full Essay | Target: 4–5 Handwritten Pages</span>
          </div>
          <div class="q-text-prompt">
            <strong>Exam Question:</strong> a. Define Carcinoma of Breast (2) | b. Write down clinical manifestation and diagnostic evaluation of breast cancer (4) | c. Discuss the management of breast cancer and prepare nursing care plan for a patient with Modified Radical Mastectomy (5).
          </div>
          <div class="q-answer-content">
            <div class="ans-part">
              <div class="ans-part-title">Part (a): Definition of Carcinoma of Breast (2 Marks)</div>
              <div class="ans-part-body">
                <p><strong>Breast Carcinoma:</strong> A malignant neoplasm originating from the epithelial tissue of the breast parenchyma, most commonly from the terminal duct lobular units (Infiltrating Ductal Carcinoma - 80%, or Infiltrating Lobular Carcinoma - 10–15%). It exhibits uncontrolled proliferation, local infiltration into Cooper's ligaments and pectoral fascia, and metastasis to regional axillary lymph nodes, bone, lungs, liver, and brain.</p>
              </div>
            </div>

            <div class="ans-part">
              <div class="ans-part-title">Part (b): Clinical Manifestations & Diagnostic Evaluation (4 Marks)</div>
              <div class="ans-part-body">
                <p><strong>Clinical Manifestations:</strong></p>
                <ul>
                  <li><strong>Painless Palpable Mass:</strong> Hard, solitary, irregularly bordered, non-mobile (fixed to skin or chest wall), most commonly in the Upper Outer Quadrant (50%).</li>
                  <li><strong>Skin Changes:</strong>
                    <ul>
                      <li><em>Peau d'orange (Orange peel appearance):</em> Cutaneous edema caused by lymphatic obstruction by tumor emboli with tethered hair follicles.</li>
                      <li>Skin dimpling/retraction due to neoplastic invasion and shortening of Cooper's suspensory ligaments.</li>
                    </ul>
                  </li>
                  <li><strong>Nipple Abnormalities:</strong> Recent nipple retraction/inversion, deviation, ulceration, or spontaneous unilateral serosanguinous/bloody nipple discharge.</li>
                  <li><strong>Axillary Lymphadenopathy:</strong> Firm, enlarged, matted, non-tender palpable axillary nodes.</li>
                </ul>

                <p><strong>Diagnostic Evaluation (The Triple Assessment Approach):</strong></p>
                <ol>
                  <li><strong>Clinical Examination:</strong> Bilateral breast palpation, axillary and supraclavicular lymph node assessment.</li>
                  <li><strong>Imaging:</strong>
                    <ul>
                      <li><em>Digital Mammography (Gold Standard):</em> Detects microcalcifications (&lt;1 cm) and architectural distortion before lesions become clinically palpable.</li>
                      <li><em>Breast Ultrasound:</em> Differentiates solid tumors from benign fluid-filled cysts.</li>
                    </ul>
                  </li>
                  <li><strong>Histopathology:</strong> Core Needle Biopsy (CNB) or Stereotactic Biopsy to determine histological grade, Estrogen Receptor (ER), Progesterone Receptor (PR), and HER2/neu receptor status.</li>
                </ol>
              </div>
            </div>

            <div class="ans-part">
              <div class="ans-part-title">Part (c): Management & Post-Op Nursing Care Plan for Modified Radical Mastectomy (MRM) (5 Marks)</div>
              <div class="ans-part-body">
                <p><strong>Modified Radical Mastectomy (MRM):</strong> Removal of the entire breast tissue, nipple-areolar complex, overlying skin, and Level I and II axillary lymph nodes, while preserving the Pectoralis Major and Minor muscles.</p>

                <p><strong>Comprehensive Nursing Care Plan:</strong></p>
                <table class="clinical-table">
                  <thead>
                    <tr>
                      <th style="width: 25%;">Nursing Diagnosis</th>
                      <th style="width: 20%;">Goal</th>
                      <th style="width: 35%;">Nursing Interventions & Rationales</th>
                      <th style="width: 20%;">Evaluation</th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr>
                      <td><strong>Risk for Impaired Physical Mobility & Lymphedema</strong> r/t axillary dissection and lymphatic disruption.</td>
                      <td>Prevent operative arm lymphedema and restore full shoulder range of motion.</td>
                      <td>
                        &bull; <em>STRICT RULE:</em> NO venipunctures, IV lines, blood pressure readings, or injections in the affected arm for life.<br>
                        &bull; Elevate affected arm on a pillow above heart level with hand higher than elbow.<br>
                        &bull; Post-Op Exercises: Day 1: Squeeze rubber ball, wrist flexion/extension. POD 3–5: Pendulum swings. After drain removal: Wall climbing (spider walk) and rope turning.<br>
                        <em>Rationale:</em> Elevation promotes collateral lymphatic return; early graded exercise prevents frozen shoulder.
                      </td>
                      <td>Operative arm has zero edema; full shoulder abduction and rotation achieved by week 6.</td>
                    </tr>
                    <tr>
                      <td><strong>Ineffective Tissue Perfusion & Risk for Seroma/Hematoma</strong> r/t extensive skin flap dissection.</td>
                      <td>Maintain patent surgical drainage and secure skin flap adherence.</td>
                      <td>
                        &bull; Monitor closed-suction drain (Jackson-Pratt or Hemovac).<br>
                        &bull; Record color, volume, and consistency of output q8h.<br>
                        &bull; Maintain continuous negative suction.<br>
                        &bull; Drain removal criteria: When 24-hr drainage is &lt;30 mL for 2 consecutive days.
                      </td>
                      <td>Flaps flat and adherent; drainage clear serous &lt;30 mL/day; absence of hematoma.</td>
                    </tr>
                    <tr>
                      <td><strong>Disturbed Body Image</strong> r/t loss of breast and altered feminine appearance.</td>
                      <td>Express feelings openly and adapt constructively to body changes.</td>
                      <td>
                        &bull; Provide empathetic emotional support; encourage patient to view incision when ready.<br>
                        &bull; Involve spouse/partner in counseling.<br>
                        &bull; Discuss breast reconstruction options (autologous TRAM flap or silicone implants) and temporary lightweight silicone breast prostheses.
                      </td>
                      <td>Patient looks at surgical site without acute distress; actively selects appropriate prosthesis.</td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </div>

        <!-- QUESTION 4: MAY 2019 (MAIN) Q.2 [15 MARKS] -->
        <div class="q-block">
          <div class="q-header">
            <span class="q-badge">MPMSU May 2019 (Main) — Q.2 [15 Marks]</span>
            <span class="q-weight">Full Long Essay | Target: 5 Handwritten Pages</span>
          </div>
          <div class="q-text-prompt">
            <strong>Exam Question:</strong> a. Define laryngeal cancer (2) | b. List down the clinical manifestation and diagnostic evaluation of laryngeal cancer (5) | c. Write down the medical and nursing management of patient with total laryngectomy (8).
          </div>
          <div class="q-answer-content">
            <div class="ans-part">
              <div class="ans-part-title">Part (a): Definition of Laryngeal Cancer (2 Marks)</div>
              <div class="ans-part-body">
                <p><strong>Laryngeal Carcinoma:</strong> A malignant neoplasm arising from the epithelial lining of the larynx, predominantly Squamous Cell Carcinoma (&gt;95%). Topographically classified into Glottic (true vocal cords - 60–65%), Supraglottic (epiglottis, false cords - 30–35%), and Subglottic (&lt;5%). Highly associated with chronic tobacco smoking and excessive alcohol consumption (synergistic risk).</p>
              </div>
            </div>

            <div class="ans-part">
              <div class="ans-part-title">Part (b): Clinical Manifestations & Diagnostic Evaluation (5 Marks)</div>
              <div class="ans-part-body">
                <p><strong>Clinical Manifestations:</strong></p>
                <ul>
                  <li><em>Early Symptoms (Glottic Cancer):</em> <strong>Persistent hoarseness of voice (&gt;2 weeks)</strong> or change in voice pitch. (Vocal cords cannot approximate during phonation).</li>
                  <li><em>Supraglottic Cancer Early Signs:</em> Persistent sore throat, "lump in the throat" sensation, unilateral otalgia (referred ear pain via glossopharyngeal nerve / Arnold's nerve).</li>
                  <li><em>Late Symptoms:</em> Progressive dysphagia, dyspnea, inspiratory stridor, foul halitosis, blood-tinged sputum/hemoptysis, weight loss, and palpable cervical lymphadenopathy.</li>
                </ul>

                <p><strong>Diagnostic Evaluation:</strong></p>
                <ol>
                  <li><strong>Indirect Laryngoscopy & Flexible Fiberoptic Nasopharyngolaryngoscopy:</strong> Direct visualization of vocal cord mobility, tumor margins, and mucosal infiltration.</li>
                  <li><strong>Direct Laryngoscopy with Biopsy under GA:</strong> Definitive tissue diagnosis; histological examination of tumor grade.</li>
                  <li><strong>CT Neck and Thorax / MRI:</strong> Evaluates pre-epiglottic space invasion, cartilage destruction, and cervical lymph node involvement.</li>
                  <li><strong>Barium Swallow:</strong> Assesses esophageal involvement in advanced tumors.</li>
                </ol>
              </div>
            </div>

            <div class="ans-part">
              <div class="ans-part-title">Part (c): Medical & Nursing Management of Patient with Total Laryngectomy (8 Marks)</div>
              <div class="ans-part-body">
                <p><strong>Total Laryngectomy:</strong> Complete surgical excision of the larynx, hyoid bone, thyroid cartilage, epiglottis, cricoid cartilage, and several tracheal rings. The trachea is permanently sutured to the anterior neck skin, creating a permanent end-tracheostoma. <em>Key Anatomical Change:</em> Complete anatomical separation of the digestive and respiratory tracts; the patient becomes a permanent neck breather and loses the ability to speak naturally.</p>

                <p><strong>1. Pre-Operative Nursing Interventions:</strong></p>
                <ul>
                  <li><strong>Communication Planning:</strong> Establish non-verbal communication methods (picture boards, writing pads, tablet, magic slates) before surgery. Reassure the patient that alternative voice rehabilitation will follow.</li>
                  <li><strong>Education & Counseling:</strong> Explain the permanent stoma, loss of normal voice, and absence of sense of smell/taste. Introduce to a laryngectomy club survivor.</li>
                </ul>

                <p><strong>2. Immediate Post-Operative Nursing Care (Life-Saving Priorities):</strong></p>
                <table class="clinical-table">
                  <thead>
                    <tr>
                      <th style="width: 25%;">Care Domain</th>
                      <th style="width: 50%;">Specific Clinical Interventions & Protocols</th>
                      <th style="width: 25%;">Medical Rationale</th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr>
                      <td><strong>Airway Patency & Secretion Clearance</strong></td>
                      <td>
                        &bull; Position in Semi-Fowler's (30–45°) to reduce surgical edema and facilitate diaphragmatic excursion.<br>
                        &bull; Continuous warm humidification (tracheostomy collar / mist tent).<br>
                        &bull; Suction stoma aseptically using sterile catheter (suction pressure 80–120 mmHg, duration &lt;10–15 sec; pre-oxygenate with 100% O2).<br>
                        &bull; Clean inner cannula q4–8h to prevent crusting.
                      </td>
                      <td>Absence of upper airway filtration and humidification causes thick mucosal plugs, risking fatal asphyxiation.</td>
                    </tr>
                    <tr>
                      <td><strong>Wound & Drain Management</strong></td>
                      <td>
                        &bull; Monitor Jackson-Pratt / Hemovac surgical drains connected to continuous negative suction.<br>
                        &bull; Output expected &lt;50 mL/24h before drain removal.<br>
                        &bull; Inspect for hematoma formation (rapid neck swelling can compress the stoma).
                      </td>
                      <td>Prevents seroma, flap necrosis, and pharyngocutaneous fistula.</td>
                    </tr>
                    <tr>
                      <td><strong>Nutritional Management</strong></td>
                      <td>
                        &bull; NPO for 7–10 days until pharyngeal suture line completely heals.<br>
                        &bull; Enteral feeding via Nasogastric (NG) tube or gastrostomy.<br>
                        &bull; Perform Barium or gastrografin swallow study around POD 7–10 before initiating oral liquids.
                      </td>
                      <td>Early oral intake can rupture the pharyngeal suture line, causing saliva extravasation and fistula.</td>
                    </tr>
                  </tbody>
                </table>

                <p><strong>3. Comprehensive Vocal & Stoma Rehabilitation:</strong></p>
                <ul>
                  <li><strong>Methods of Voice Restoration:</strong>
                    <ol>
                      <li><strong>Tracheoesophageal Puncture (TEP) with Blom-Singer Valve (Gold Standard):</strong> A small surgical fistula created between the posterior tracheal wall and anterior esophagus. A one-way silicone voice prosthesis allows pulmonary air into the esophagus to vibrate the pharyngoesophageal segment, producing natural-sounding speech.</li>
                      <li><strong>Electrolarynx:</strong> Battery-operated vibrating device held against the submandibular neck skin; converts vibrations into mechanical speech.</li>
                      <li><strong>Esophageal Speech:</strong> Patient swallows air into the esophagus and regurgitates it in a controlled manner, vibrating the cricopharyngeal sphincter.</li>
                    </ol>
                  </li>
                  <li><strong>Stoma Care & Home Discharge Teaching:</strong>
                    <ul>
                      <li>Wear a protective stoma bib or cover to filter dust and warm inspired air.</li>
                      <li><em>Water Safety:</em> Never swim; use a specialized shower shield when bathing to prevent water aspiration into lungs.</li>
                      <li>Avoid aerosol sprays, powders, and smoke environments.</li>
                      <li>Instruct on MedicAlert bracelet stating: <em>"Total Neck Breather - Apply resuscitation mask to neck stoma, NOT mouth/nose."</em></li>
                    </ul>
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </div>

      </div>
    </div>

    <!-- ------------------------------------------------------------ -->
    <!-- TOPIC 3: EYE DISORDERS (REPEATED 4/4)                        -->
    <!-- ------------------------------------------------------------ -->`},{id:`grp-eye`,title:`Eye Disorders (Glaucoma, Cataract, Retinal Detachment)`,repeatCount:4,years:[`2019`,`2020`,`2022`,`2025`],probability:98,priorityTier:`Tier 1 • Guaranteed`,tierClass:`tier-guaranteed`,subItems:[{concept:`Glaucoma: open-angle vs angle-closure, tonometry & pharmacotherapy`,years:`2019, 2022`},{concept:`Cataract: surgical phacoemulsification, IOL implantation & post-op nursing care`,years:`2025`},{concept:`Retinal detachment: scleral buckling, vitrectomy & post-op prone positioning`,years:`2020`}],questions:[{paperBadge:`MPMSU July 2022 (Main & Supp) — Q.2 [15 Marks]`,weight:`Full Long Essay | Target: 5 Handwritten Pages`,questionText:`a. Define glaucoma (2) | b. State the causes and classification of glaucoma (5) | c. Explain the medical, surgical management and the nursing management of glaucoma (8).`},{paperBadge:`MPMSU May 2019 (Main) — Q.3 [15 Marks]`,weight:`Full Long Essay | Target: 5 Handwritten Pages`,questionText:`a. Define Glaucoma (2) | b. Discuss the sign and symptoms of Glaucoma (7) | c. Explain national blindness control program (6).`},{paperBadge:`MPMSU Feb 2025 (Supp) — Q.4 [10 Marks]`,weight:`Essay Question | Target: 4 Handwritten Pages`,questionText:`a. Define cataract and describe its types (5) | b. Plan a post operative nursing care for a patient who had undergone eye surgery (5).`},{paperBadge:`MPMSU Feb 2020 (Main) — Q.1 [15 Marks]`,weight:`Full Long Essay | Target: 5 Handwritten Pages`,questionText:`a. Define retinal detachment (2) | b. Enlist sign and symptoms of retinal detachment (4) | c. Explain the medical management of retinal detachment (4) | d. Formulates a nursing care plan for a patient with retinal detachment (5).`}],answerHtml:`<!-- ======================================================== -->
        <!-- CATEGORIZED CLINICAL CONCEPTS & MEDICAL EXPLANATIONS     -->
        <!-- ======================================================== -->
        <div class="concept-category-title">Categorized Clinical Guide & Ophthalmology Breakdown</div>

        <!-- 1. CLINICAL FUNDUS EXAMINATION & OPTIC CUPPING -->
        <div class="concept-card">
          <div class="concept-title">1. Clinical Color Fundus Examination & Glaucoma Optic Neuropathy</div>
          <div class="concept-body">
            <p>Glaucoma is a progressive optic neuropathy characterized by loss of retinal ganglion cells, excavation of the optic nerve head, and characteristic visual field loss (arcuate scotoma to tunnel vision):</p>
            
            <img src="/pyqs/images/glaucoma_fundus_grid.png" class="med-img" alt="Fundus Examination: Normal vs Cataract vs Glaucoma Optic Cupping">
            
            <div class="img-notes">
              <strong>Clinical Diagnostic Standards & Tonometry:</strong>
              <br>&bull; <strong>Normal Optic Disc:</strong> Healthy pink neuroretinal rim with a central physiological cup occupying &le;30–40% of the disc diameter (Cup-to-Disc [C/D] ratio &le; 0.3–0.4).
              <br>&bull; <strong>Glaucomatous Optic Cupping:</strong> Progressive retinal ganglion cell apoptosis causes deep excavation, backward bowing of the lamina cribrosa, neuroretinal rim thinning (notching), and vertical Cup-to-Disc ratio enlargement &gt;0.6–0.7 with bayoneting of retinal vessels.
              <br>&bull; <strong>Intraocular Pressure (IOP) Benchmarks:</strong> Normal baseline = <strong>10–21 mmHg</strong> (measured via Goldmann Applanation Tonometry). In Primary Open-Angle Glaucoma (POAG), IOP is chronically elevated (22–32 mmHg). In Acute Angle-Closure Glaucoma (AACG), pupillary block causes sudden acute IOP spikes to <strong>&gt;50–70 mmHg</strong>, demanding emergency medical decompression within hours (IV Mannitol 20%, IV Acetazolamide, topical Pilocarpine 2%) to prevent permanent blindness.
            </div>
          </div>
        </div>

        <!-- 2. AQUEOUS HUMOR HYDRODYNAMICS & GLAUCOMA TYPES -->
        <div class="concept-card">
          <div class="concept-title">2. Aqueous Humor Outflow Dynamics & Glaucoma Pathophysiology</div>
          <div class="concept-body">
            <p><strong>Aqueous Humor Production & Drainage:</strong> Aqueous humor is actively secreted by non-pigmented ciliary epithelium of the ciliary body into the posterior chamber (2.0–2.5 &mu;L/min). It flows through the pupillary aperture into the anterior chamber, where 85–90% filters through the trabecular meshwork into the Canal of Schlemm (conventional outflow), and 10–15% exits via the uveoscleral pathway.</p>
            
            <table class="clinical-table" style="margin-top: 10px;">
              <thead>
                <tr><th>Feature</th><th>Primary Open-Angle Glaucoma (POAG)</th><th>Acute Angle-Closure Glaucoma (AACG)</th></tr>
              </thead>
              <tbody>
                <tr><td><strong>Drainage Angle</strong></td><td>Anatomically open; wide iridocorneal angle.</td><td>Mechanically closed; iris root obstructs trabecular meshwork.</td></tr>
                <tr><td><strong>Etiology</strong></td><td>Microscopic sclerosis/thickening of trabecular meshwork.</td><td>Pupillary block in shallow anterior chamber &rarr; iris bombé.</td></tr>
                <tr><td><strong>Onset & Symptoms</strong></td><td>Insidious, painless, bilateral; asymptomatic until peripheral vision loss occurs ("silent thief of sight").</td><td>Sudden, acute, severe periorbital pain, headache, nausea, blurred vision with rainbow halos around lights.</td></tr>
                <tr><td><strong>Physical Findings</strong></td><td>Normal anterior chamber depth; pale excavated optic cup.</td><td>Steamy cloudy cornea, mid-dilated non-reactive pupil, ciliary flush, stony-hard globe on palpation.</td></tr>
                <tr><td><strong>Definitive Surgery</strong></td><td>Trabeculectomy (creates scleral filtering bleb).</td><td>Laser Peripheral Iridotomy (LPI) creates bypass hole in iris.</td></tr>
              </tbody>
            </table>
          </div>
        </div>

        <!-- 3. CATARACT & RETINAL DETACHMENT CLINICAL ESSENTIALS -->
        <div class="concept-card">
          <div class="concept-title">3. Cataract Pathogenesis & Retinal Detachment Protocols</div>
          <div class="concept-body">
            <p><strong>Cataract Surgical Management (Phacoemulsification):</strong> Ultrasonic fragmentation and aspiration of the cataractous crystalline lens through a clear corneal micro-incision, followed by foldable Intraocular Lens (IOL) implantation into the capsular bag.</p>
            <ul>
              <li><strong>Post-Op Restrictions (Prevent IOP elevation):</strong> Instruct patient <em>never to bend over at waist</em>, avoid lifting objects &gt;5 kg, avoid coughing, sneezing, or straining during defecation (prescribe stool softeners). Wear protective rigid eye shield during sleep for 1–2 weeks. Instill topical antibiotic-corticosteroid drops (e.g., Moxifloxacin + Prednisolone).</li>
            </ul>

            <p style="margin-top: 12px;"><strong>Retinal Detachment (Emergency Rhegmatogenous Detachment):</strong> Separation of neurosensory retina from the underlying retinal pigment epithelium (RPE) by subretinal fluid leaking through a full-thickness retinal tear.</p>
            <ul>
              <li><strong>Classic Triad:</strong> Photopsia (flashes of light), sudden shower of black floaters, followed by a painless dark "curtain falling over the visual field."</li>
              <li><strong>Surgical Repair & Gas Tamponade:</strong> Scleral buckling (silicone band indents sclera against retinal tear) or Pars Plana Vitrectomy with intraocular gas tamponade (SF6 / C3F8 gas).</li>
              <li><strong>Mandatory Nursing Prone Positioning:</strong> Patient must maintain <strong>strict prone (face-down) position for 16–20 hours daily for 10–14 days</strong> so the buoyant intraocular gas bubble floats upward to tamponade the retinal tear against the posterior choroid!</li>
            </ul>
          </div>
        </div>

        <!-- ======================================================== -->
        <!-- SECTION B: PAST UNIVERSITY EXAM QUESTIONS & ANSWERS      -->
        <!-- ======================================================== -->
        <div class="section-divider-title">Exact University Exam Questions & 2–5 Page Model Answers</div>

        <!-- QUESTION 1: JULY 2022 (MAIN) Q.2 [15 MARKS] -->
        <div class="q-block">
          <div class="q-header">
            <span class="q-badge">MPMSU July 2022 (Main & Supp) — Q.2 [15 Marks]</span>
            <span class="q-weight">Full Long Essay | Target: 5 Handwritten Pages</span>
          </div>
          <div class="q-text-prompt">
            <strong>Exam Question:</strong> a. Define glaucoma (2) | b. State the causes and classification of glaucoma (5) | c. Explain the medical, surgical management and the nursing management of glaucoma (8).
          </div>
          <div class="q-answer-content">
            <div class="ans-part">
              <div class="ans-part-title">Part (a): Definition of Glaucoma (2 Marks)</div>
              <div class="ans-part-body">
                <p><strong>Glaucoma:</strong> A group of ocular progressive optic neuropathies characterized by pathological elevation of Intraocular Pressure (IOP &gt;21 mmHg; normal is 10–21 mmHg measured by Goldmann applanation tonometry), leading to mechanical compression and ischemic apoptosis of retinal ganglion cell axons, progressive optic nerve head cupping (cup-to-disc ratio &gt;0.5), and irreversible tunnel vision visual field deficits.</p>
              </div>
            </div>

            <div class="ans-part">
              <div class="ans-part-title">Part (b): Causes and Classification of Glaucoma (5 Marks)</div>
              <div class="ans-part-body">
                <p><strong>Etiology & Risk Factors:</strong> Impaired outflow of aqueous humor through the trabecular meshwork and Canal of Schlemm, age &gt;40 years, positive family history, high myopia, diabetes mellitus, hypertension, prolonged topical/systemic corticosteroid therapy, and shallow anterior chamber anatomy.</p>
                <p><strong>Classification:</strong></p>
                <table class="clinical-table">
                  <thead>
                    <tr><th>Type</th><th>Anatomical Mechanism</th><th>Clinical Presentation</th></tr>
                  </thead>
                  <tbody>
                    <tr>
                      <td><strong>Primary Open-Angle Glaucoma (POAG - 90%)</strong></td>
                      <td>Anterior chamber angle remains anatomically wide and open (35–45°), but progressive microscopic trabecular sclerosis impedes drainage.</td>
                      <td>"Silent thief of sight." Insidious, painless, bilateral; gradual loss of peripheral vision resulting in classic "tunnel vision". IOP 22–32 mmHg.</td>
                    </tr>
                    <tr>
                      <td><strong>Acute Angle-Closure Glaucoma (AACG - Emergency!)</strong></td>
                      <td>Iris root is pushed forward against trabecular meshwork, completely obliterating drainage angle (pupillary block).</td>
                      <td>Sudden excruciating ocular and periorbital pain, rainbow-colored halos around lights, blurred vision, nausea/vomiting, steamy/hazy cornea, fixed semi-dilated pupil, rock-hard eyeball. IOP spikes to 50–70 mmHg.</td>
                    </tr>
                    <tr>
                      <td><strong>Congenital / Infantile Glaucoma (Buphthalmos)</strong></td>
                      <td>Developmental dysgenesis of anterior chamber angle (Barkan's membrane obstruction).</td>
                      <td>Triad: Epiphora (tearing), Photophobia, Blepharospasm. Enlarged cornea ("ox eye"), corneal haziness.</td>
                    </tr>
                    <tr>
                      <td><strong>Secondary Glaucoma</strong></td>
                      <td>Secondary to trauma, intraocular tumors, neovascularization (proliferative diabetic retinopathy), uveitis, or steroid use.</td>
                      <td>Depends on underlying etiology.</td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>

            <div class="ans-part">
              <div class="ans-part-title">Part (c): Medical, Surgical & Nursing Management of Glaucoma (8 Marks)</div>
              <div class="ans-part-body">
                <p><strong>1. Medical Management:</strong></p>
                <ul>
                  <li><strong>Prostaglandin Analogs (1st Line for POAG):</strong> Latanoprost 0.005%, Bimatoprost 1 drop at bedtime. Increases uveoscleral outflow. <em>Side effects:</em> Iris hyperpigmentation, eyelash lengthening.</li>
                  <li><strong>Beta-Adrenergic Blockers:</strong> Timolol maleate 0.25–0.5% 1 drop BID. Decreases aqueous humor production. <em>Caution:</em> Systemic absorption causes bradycardia and bronchospasm; punctal occlusion mandatory; contraindicated in asthma/COPD/heart block.</li>
                  <li><strong>Alpha-2 Adrenergic Agonists:</strong> Brimonidine 0.2% TID. Decreases aqueous production and increases uveoscleral outflow.</li>
                  <li><strong>Carbonic Anhydrase Inhibitors:</strong> Dorzolamide 2% eye drops or Oral Acetazolamide (Diamox) 250 mg QID. Decreases aqueous humor formation by ciliary body.</li>
                  <li><strong>Emergency Management for Acute Angle-Closure Glaucoma:</strong>
                    <ul>
                      <li>IV Mannitol 20% (1.5–2 g/kg over 30–60 min) or oral glycerol to rapidly withdraw vitreous water into circulation.</li>
                      <li>Topical Pilocarpine 2–4% (cholinergic miotic) 1 drop q15min &times; 4 doses. Induces pupillary constriction (miosis), pulling the peripheral iris away from the trabecular meshwork to reopen the filtration angle.</li>
                    </ul>
                  </li>
                </ul>

                <p><strong>2. Surgical Management:</strong></p>
                <ul>
                  <li><em>Laser Trabeculoplasty (ALT/SLT):</em> Applies laser burns to trabecular meshwork to widen drainage spaces in POAG.</li>
                  <li><em>Laser Peripheral Iridotomy (LPI):</em> Laser puncture hole in peripheral iris creates an alternate channel between posterior and anterior chambers for angle-closure glaucoma.</li>
                  <li><em>Trabeculectomy (Filtering Surgery):</em> Creates a partial-thickness scleral flap and fistula connecting anterior chamber to subconjunctival space, forming a filtering bleb.</li>
                </ul>

                <p><strong>3. Nursing Care Plan for Patient with Glaucoma:</strong></p>
                <table class="clinical-table">
                  <thead>
                    <tr><th>Diagnosis</th><th>Interventions & Rationales</th><th>Evaluation</th></tr>
                  </thead>
                  <tbody>
                    <tr>
                      <td><strong>Disturbed Visual Sensory Perception</strong> r/t optic nerve damage.</td>
                      <td>&bull; Educate on proper technique of eye drop instillation: Wash hands, pull lower conjunctival sac, instill 1 drop, apply digital pressure to inner canthus (lacrimal punctum) for 2–3 minutes.<br><em>Rationale:</em> Nasolacrimal punctal occlusion prevents systemic vascular absorption.<br>&bull; Strict adherence teaching: Glaucoma medication is lifelong; missed doses cause silent optic nerve damage.<br>&bull; Orient patient to room environment; ensure clutter-free pathways.</td>
                      <td>Patient correctly demonstrates punctal occlusion; adheres to medication schedule; maintains stable visual field.</td>
                    </tr>
                    <tr>
                      <td><strong>Deficient Knowledge regarding Contraindicated Medications</strong></td>
                      <td>&bull; Warn patient NEVER to take over-the-counter cold medications, decongestants (pseudoephedrine), or anticholinergics (atropine, scopolamine).<br><em>Rationale:</em> Anticholinergics cause pupillary dilation (mydriasis), which can precipitate acute angle closure and blindness.<br>&bull; Educate on wearing a MedicAlert bracelet.</td>
                      <td>Patient lists contraindicated medications and carries medical ID card.</td>
                    </tr>
                    <tr>
                      <td><strong>Post-Trabeculectomy Care</strong></td>
                      <td>&bull; Avoid activities that increase IOP: No bending at waist, lifting &gt;5 kg, straining at stool (prescribe docusate sodium), coughing, or vomiting.<br>&bull; Wear rigid eye shield during sleep.<br>&bull; Report signs of bleb infection (endophthalmitis: pain, severe redness, purulent discharge).</td>
                      <td>IOP maintained &lt;18 mmHg; filtering bleb diffuse and intact; absence of infection.</td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </div>

        <!-- QUESTION 2: MAY 2019 (MAIN) Q.3 [15 MARKS] -->
        <div class="q-block">
          <div class="q-header">
            <span class="q-badge">MPMSU May 2019 (Main) — Q.3 [15 Marks]</span>
            <span class="q-weight">Full Long Essay | Target: 5 Handwritten Pages</span>
          </div>
          <div class="q-text-prompt">
            <strong>Exam Question:</strong> a. Define Glaucoma (2) | b. Discuss the sign and symptoms of Glaucoma (7) | c. Explain national blindness control program (6).
          </div>
          <div class="q-answer-content">
            <div class="ans-part">
              <div class="ans-part-title">Part (a): Definition of Glaucoma (2 Marks)</div>
              <div class="ans-part-body">
                <p><strong>Glaucoma:</strong> An optic neuropathy characterized by structural changes in the optic nerve head (optic disc cupping and neuroretinal rim thinning) and progressive retinal ganglion cell loss, commonly associated with elevated intraocular pressure exceeding the physiological tolerance of the optic nerve, leading to irreversible visual field loss.</p>
              </div>
            </div>

            <div class="ans-part">
              <div class="ans-part-title">Part (b): Signs and Symptoms of Glaucoma (7 Marks)</div>
              <div class="ans-part-body">
                <p>Signs and symptoms depend on the clinical presentation:</p>
                <p><strong>1. Primary Open-Angle Glaucoma (POAG):</strong></p>
                <ul>
                  <li>Early stages: Completely asymptomatic. Central visual acuity remains 6/6 until advanced disease.</li>
                  <li>Gradual bilateral reduction in peripheral vision (peripheral visual field scotomas, arcuate scotoma / Bjerrum scotoma).</li>
                  <li>Progression to classic <em>"Tunnel Vision"</em> (bumping into objects, difficulty driving at night).</li>
                  <li>Frequent changes in presbyopic spectacle glasses.</li>
                  <li>Physical signs: Elevated IOP (22–32 mmHg on Goldmann applanation), increased optic disc cup-to-disc ratio (&gt;0.5 or asymmetry &gt;0.2 between eyes).</li>
                </ul>

                <p><strong>2. Acute Angle-Closure Glaucoma (AACG - Emergency):</strong></p>
                <ul>
                  <li>Sudden, excruciating, unilateral ocular pain radiating along the trigeminal distribution (forehead, temple).</li>
                  <li>Colored rainbow halos around point sources of light (caused by corneal epithelial edema acting as a prism).</li>
                  <li>Rapid severe visual blurring / loss of acuity.</li>
                  <li>Systemic autonomic signs: Nausea, profuse vomiting, bradycardia, abdominal pain.</li>
                  <li>Ocular signs: Marked ciliary injection/hyperemia, hazy/steamy cornea, shallow anterior chamber, vertically oval semi-dilated unreactive pupil, IOP spiked to 50–70 mmHg ("stony hard" globe).</li>
                </ul>

                <p><strong>3. Congenital Glaucoma (Buphthalmos):</strong></p>
                <ul>
                  <li>Classic clinical triad: Epiphora (excessive watering), Photophobia (intolerance to light), Blepharospasm (involuntary eyelid spasm).</li>
                  <li>Enlarged corneal diameter (&gt;12 mm in infant), corneal cloudiness/haziness, Haab's striae (tears in Descemet's membrane).</li>
                </ul>
              </div>
            </div>

            <div class="ans-part">
              <div class="ans-part-title">Part (c): National Programme for Control of Blindness and Visual Impairment (NPCBVI) (6 Marks)</div>
              <div class="ans-part-body">
                <p><strong>Overview:</strong> Launched in India in 1976 as a 100% centrally sponsored programme with the goal of reducing the prevalence of blindness from 1.4% to &lt;0.3% of the population.</p>
                <p><strong>Major Causes of Blindness Targeted in India:</strong> Cataract (66.2%), Refractive errors (7.5%), Glaucoma (5.5%), Corneal blindness (0.9%), Diabetic retinopathy, and Childhood blindness.</p>
                <p><strong>Key Objectives & Strategies of NPCBVI:</strong></p>
                <ul>
                  <li><strong>1. Decentralized Infrastructure:</strong> Establishment of District Health Societies (Blindness Control Division) in each district; strengthening tertiary eye care hospitals (Regional Institutes of Ophthalmology - RIOs), district eye units, and vision centers at Primary Health Centers (PHCs).</li>
                  <li><strong>2. High-Quality Cataract Surgical Coverage:</strong> Transition from intracapsular extraction to Modern Small Incision Cataract Surgery (MSICS) and Phacoemulsification with Intraocular Lens (IOL) implantation; organized screening camps and free transportation for rural elderly.</li>
                  <li><strong>3. School Eye Screening Programme:</strong> Trained school teachers screen primary and secondary school children for refractive errors; free corrective spectacles are distributed to children from economically weaker families.</li>
                  <li><strong>4. Glaucoma & Diabetic Retinopathy Screening:</strong> Integration of non-contact tonometry and fundus photography screening in non-communicable disease (NCD) clinics at the district level.</li>
                  <li><strong>5. Eye Banking & Corneal Transplantation:</strong> Promoting voluntary eye donation after death; development of community eye banks; Hospital Cornea Retrieval Programme (HCRP).</li>
                  <li><strong>6. Role of Public Health Nurse in NPCBVI:</strong>
                    <ul>
                      <li>Community health education on eye hygiene, prevention of ocular trauma, and timely eye examinations.</li>
                      <li>Screening high-risk groups (diabetics, hypertensives, family history of glaucoma).</li>
                      <li>Organizing screening camps and post-operative follow-up visits in rural communities.</li>
                    </ul>
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </div>

        <!-- QUESTION 3: FEB 2025 (SUPP) Q.4 [10 MARKS] -->
        <div class="q-block">
          <div class="q-header">
            <span class="q-badge">MPMSU Feb 2025 (Supp) — Q.4 [10 Marks]</span>
            <span class="q-weight">Essay Question | Target: 4 Handwritten Pages</span>
          </div>
          <div class="q-text-prompt">
            <strong>Exam Question:</strong> a. Define cataract and describe its types (5) | b. Plan a post operative nursing care for a patient who had undergone eye surgery (5).
          </div>
          <div class="q-answer-content">
            <div class="ans-part">
              <div class="ans-part-title">Part (a): Definition and Types of Cataract (5 Marks)</div>
              <div class="ans-part-body">
                <p><strong>Cataract:</strong> Any pathological opacification or loss of transparency of the crystalline crystalline lens of the eye or its capsule, causing scattering and obstruction of incoming light rays and progressive painless blurring of vision.</p>

                <p><strong>Types and Classification:</strong></p>
                <ul>
                  <li><strong>1. Classification by Age / Onset:</strong>
                    <ul>
                      <li><em>Congenital / Developmental Cataract:</em> Present at birth or early childhood; associated with intrauterine infections (Maternal Rubella, Toxoplasmosis, CMV) or metabolic errors (Galactosemia).</li>
                      <li><em>Acquired Cataract:</em> Develops later in life.</li>
                    </ul>
                  </li>
                  <li><strong>2. Senile (Age-Related) Cataract (Most Common &gt;90%):</strong>
                    <ul>
                      <li><em>Nuclear Cataract:</em> Dense opacification in the lens nucleus; progressive myopia ("second sight" where elderly can read without reading glasses temporarily), brown/black discoloration (cataracta brunescens).</li>
                      <li><em>Cortical Cataract:</em> Radial spoke-like, wedge-shaped opacities in the lens cortex periphery; causes glare when facing headlights.</li>
                      <li><em>Posterior Subcapsular Cataract (PSC):</em> Granular opacities just inside the posterior capsule; common in diabetics and long-term steroid users; severe glare and poor near vision.</li>
                    </ul>
                  </li>
                  <li><strong>3. Stages of Senile Cortical Cataract:</strong>
                    <ol>
                      <li><em>Stage of Lamellar Separation / Incipient:</em> Early peripheral spoke-like opacities; vision mildly affected.</li>
                      <li><em>Immature Cataract:</em> Lens becomes partially opaque; iris shadow visible on oblique illumination.</li>
                      <li><em>Mature Cataract:</em> Lens cortex is totally pearly white and opaque; iris shadow absent; vision reduced to hand movements or perception of light (PL).</li>
                      <li><em>Hypermature Cataract:</em> Cortex liquefies and nucleus sinks to the bottom (Morgagnian cataract) or shrinks and shrivels; risk of phacolytic glaucoma.</li>
                    </ol>
                  </li>
                  <li><strong>4. Secondary / Traumatic Cataracts:</strong> Secondary to blunt/penetrating ocular trauma, diabetes mellitus ("snowflake cataract"), high-voltage electrical shock, or chronic anterior uveitis.</li>
                </ul>
              </div>
            </div>

            <div class="ans-part">
              <div class="ans-part-title">Part (b): Post-Operative Nursing Care Plan After Eye Surgery (Cataract Extraction / IOL) (5 Marks)</div>
              <div class="ans-part-body">
                <p><strong>1. Immediate Post-Operative Management:</strong></p>
                <ul>
                  <li><strong>Positioning:</strong> Position patient supine or on the <em>unoperated side</em> with the head slightly elevated (30°). <em>Strictly avoid:</em> Lying on the operative eye side or lying prone (increases IOP and mechanical pressure on the incision).</li>
                  <li><strong>Eye Shield & Dressing:</strong> Keep the operative eye protected with a sterile eye patch and perforated plastic/aluminum eye shield to prevent accidental rubbing or trauma during sleep.</li>
                  <li><strong>Pain Management:</strong> Mild discomfort or a scratchy sensation is normal. Administer mild oral analgesics (Paracetamol 500–1000 mg). <em>CRITICAL ALERT:</em> Sudden, severe, deep throbbing ocular pain accompanied by nausea indicates an acute spike in IOP or choroidal hemorrhage; notify the ophthalmologist immediately.</li>
                </ul>

                <p><strong>2. Pharmacological Regimen:</strong></p>
                <ul>
                  <li>Instill topical antibiotic drops (Moxifloxacin 0.5% QID) to prevent bacterial endophthalmitis.</li>
                  <li>Instill topical corticosteroid drops (Prednisolone acetate 1% or Dexamethasone tapered over 4–6 weeks) to suppress intraocular inflammation.</li>
                  <li>Instill NSAID eye drops (Nepafenac 0.1% or Ketorolac) to prevent post-operative cystoid macular edema (CME).</li>
                </ul>

                <p><strong>3. Discharge Education & Prevention of Elevated IOP:</strong></p>
                <div class="callout">
                  <strong>PATIENT HOME TEACHING PROTOCOL:</strong>
                  <br>&bull; <strong>Strict Activity Restrictions for 2–4 Weeks:</strong> No bending from the waist to pick up objects; no lifting heavy weights (&gt;5 kg); avoid vigorous coughing, sneezing, straining during defecation (prescribe stool softeners).
                  <br>&bull; <strong>Hygiene:</strong> Do not splash water into the eye; avoid head baths for 2 weeks (sponge bath only); no eye makeup for 4 weeks.
                  <br>&bull; <strong>Protection:</strong> Wear dark sunglasses outdoors to minimize photophobia; wear protective eye shield every night during sleep for 2 weeks.
                  <br>&bull; <strong>Red Flag Symptoms:</strong> Immediately report to emergency if: sudden drop in vision, increasing redness, purulent discharge, flashes of light, floaters, or severe intractable ocular pain.
                </div>
              </div>
            </div>
          </div>
        </div>

        <!-- QUESTION 4: FEB 2020 (MAIN) Q.1 [15 MARKS] -->
        <div class="q-block">
          <div class="q-header">
            <span class="q-badge">MPMSU Feb 2020 (Main) — Q.1 [15 Marks]</span>
            <span class="q-weight">Full Long Essay | Target: 5 Handwritten Pages</span>
          </div>
          <div class="q-text-prompt">
            <strong>Exam Question:</strong> a. Define retinal detachment (2) | b. Enlist sign and symptoms of retinal detachment (4) | c. Explain the medical management of retinal detachment (4) | d. Formulates a nursing care plan for a patient with retinal detachment (5).
          </div>
          <div class="q-answer-content">
            <div class="ans-part">
              <div class="ans-part-title">Part (a): Definition of Retinal Detachment (2 Marks)</div>
              <div class="ans-part-body">
                <p><strong>Retinal Detachment (RD):</strong> An ocular emergency characterized by the separation of the neurosensory retina (photoreceptor rods and cones) from the underlying retinal pigment epithelium (RPE) and choroid. This deprives the photoreceptors of their essential choroidal blood supply and oxygenation; unless surgically reapposed promptly, permanent irreversible photoreceptor necrosis and blindness result.</p>
              </div>
            </div>

            <div class="ans-part">
              <div class="ans-part-title">Part (b): Signs and Symptoms of Retinal Detachment (4 Marks)</div>
              <div class="ans-part-body">
                <p>Retinal detachment is classically <strong>completely painless</strong>. The clinical presentation follows a characteristic temporal sequence:</p>
                <ul>
                  <li><strong>1. Photopsia (Flashes of Light):</strong> Sensation of instantaneous lightning-like flashes in the peripheral visual field, caused by vitreous traction mechanically stimulating the retina.</li>
                  <li><strong>2. Floaters (Muscae Volitantes):</strong> Sudden shower of dark floating spots, cobwebs, or ring-like opacities (Weiss ring) caused by vitreous condensation, pigment granules, or red blood cells from a torn retinal vessel.</li>
                  <li><strong>3. "Curtain / Shadow Falling" Phenomenon:</strong> A progressive, dark veil or shadow spreading across the visual field from the periphery toward the center, corresponding to the area of subretinal fluid accumulation.</li>
                  <li><strong>4. Central Vision Loss:</strong> Sudden profound drop in central visual acuity if the detachment extends into the fovea/macula ("Macula-Off" detachment).</li>
                  <li><strong>5. Funduscopic Signs:</strong> Ophthalmoscopy reveals elevated, grayish-opaque, corrugated, billowing retina with loss of choroidal background pattern; undulating retinal folds with eye movement; visible red horse-shoe tear or hole.</li>
                </ul>
              </div>
            </div>

            <div class="ans-part">
              <div class="ans-part-title">Part (c): Medical & Surgical Management of Retinal Detachment (4 Marks)</div>
              <div class="ans-part-body">
                <p>Medical management alone cannot repair a mechanical detachment; surgery is definitive and mandatory:</p>
                <ul>
                  <li><strong>Pre-Operative Bedrest & Immobilization:</strong> Strict bedrest with bilateral eye patches to minimize ocular micromovements; position patient head so that the retinal tear depends downward (allows gravity to prevent fluid from dissecting the retina further).</li>
                  <li><strong>Retinopexy (Creating Chorioretinal Adhesion):</strong>
                    <ul>
                      <li><em>Cryopexy:</em> Application of a cold cryoprobe (-70°C) to the external sclera to produce an aseptic chorioretinal scar around the tear.</li>
                      <li><em>Laser Photocoagulation:</em> Argon laser burns placed circumferentially around the retinal hole to seal margins.</li>
                    </ul>
                  </li>
                  <li><strong>Scleral Buckling Surgery:</strong> Placement of a flexible silicone sponge or band (buckle) around the globe's circumference, indenting the sclera inward against the detached neurosensory retina to relieve vitreous traction. Subretinal fluid is surgically drained.</li>
                  <li><strong>Pneumatic Retinopexy:</strong> Intravitreal injection of an expandable gas bubble (C3F8 or SF6) that floats against the retinal tear, tamponading it closed while laser/cryo scars mature.</li>
                  <li><strong>Pars Plana Vitrectomy (PPV):</strong> Surgical excision of the vitreous gel, membrane peeling, fluid-air exchange, and internal tamponade using gas or silicone oil.</li>
                </ul>
              </div>
            </div>

            <div class="ans-part">
              <div class="ans-part-title">Part (d): Comprehensive Nursing Care Plan for Retinal Detachment (5 Marks)</div>
              <div class="ans-part-body">
                <table class="clinical-table">
                  <thead>
                    <tr><th>Nursing Diagnosis</th><th>Goal</th><th>Interventions & Rationales</th><th>Evaluation</th></tr>
                  </thead>
                  <tbody>
                    <tr>
                      <td><strong>Risk for Re-detachment & Failed Tamponade</strong> r/t improper head positioning after gas injection.</td>
                      <td>Maintain prescribed positioning 16–20 hrs/day to ensure bubble tamponades tear.</td>
                      <td>
                        &bull; Position patient in strict <strong>prone (face-down) position</strong> or specific lateral tilt as ordered by retinal surgeon.<br>
                        &bull; Educate patient that the gas bubble rises to the top; face-down positioning pushes the bubble directly against the posterior retinal break.<br>
                        &bull; Provide massage-table style cushions or face-down support chairs to minimize neck strain.<br>
                        &bull; <em>AIR TRAVEL RESTRICTION:</em> Educate patient NEVER to fly in an airplane or travel to high altitudes while gas bubble is in eye (atmospheric pressure drop expands gas, causing acute angle closure and retinal artery occlusion).
                      </td>
                      <td>Patient maintains strict face-down positioning; gas bubble tamponades tear; retina completely flat.</td>
                    </tr>
                    <tr>
                      <td><strong>Anxiety & Fear of Blindness</strong> r/t sudden visual deficit and surgical intervention.</td>
                      <td>Demonstrate reduced anxiety and understand post-op expectations.</td>
                      <td>
                        &bull; Explain all procedures simply and calmly; orient patient to auditory and tactile cues while patched.<br>
                        &bull; Reassure patient that vision will improve as gas bubble is gradually reabsorbed by the body over 4–8 weeks.<br>
                        &bull; Encourage presence of family members.
                      </td>
                      <td>Patient exhibits relaxed behavior; verbalizes realistic recovery expectations.</td>
                    </tr>
                    <tr>
                      <td><strong>Risk for Increased Intraocular Pressure</strong> r/t surgical manipulation and gas expansion.</td>
                      <td>Maintain IOP within normal range (10–21 mmHg).</td>
                      <td>
                        &bull; Avoid coughing, sneezing, straining, and rapid head movements.<br>
                        &bull; Administer prescribed topical antiglaucoma drops (Timolol, Brimonidine) and anti-inflammatory eye drops.<br>
                        &bull; Report sudden sharp pain or emesis immediately.
                      </td>
                      <td>IOP remains 12–18 mmHg; patient free from ocular pain and nausea.</td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </div>

      </div>
    </div>

    <!-- ------------------------------------------------------------ -->
    <!-- TOPIC 4: GERIATRIC NURSING & CARE OF ELDERLY (REPEATED 4/4) -->
    <!-- ------------------------------------------------------------ -->`},{id:`grp-geriatric`,title:`Geriatric Nursing & Care of Elderly`,repeatCount:4,years:[`2019`,`2020`,`2022`,`2025`],probability:98,priorityTier:`Tier 1 • Guaranteed`,tierClass:`tier-guaranteed`,subItems:[{concept:`Role of nurse in physical, nutritional, and pharmacological care of elderly`,years:`2022, 2025`},{concept:`Psychological aspects of aging, Erikson's stage (Ego Integrity vs Despair) & dementia`,years:`2020`},{concept:`Legal and ethical issues in geriatric care: Elder abuse, autonomy, informed consent & DNR`,years:`2019`}],questions:[{paperBadge:`MPMSU Feb 2025 (Supp) Q.5d & July 2022 Q.5c [5 Marks]`,weight:`Repeated Short Note | Target: 2–3 Handwritten Pages`,questionText:`Short Note: Role of nurse in care of elderly (5 Marks).`},{paperBadge:`MPMSU Feb 2020 (Main) — Q.5b [5 Marks]`,weight:`Short Note | Target: 2–3 Handwritten Pages`,questionText:`Short Note: Psychological aspects of aging (5 Marks).`},{paperBadge:`MPMSU May 2019 (Main) — Q.5e [5 Marks]`,weight:`Short Note | Target: 2–3 Handwritten Pages`,questionText:`Short Note: Legal and ethical issues in geriatric care (5 Marks).`}],answerHtml:`<!-- ======================================================== -->
        <!-- CATEGORIZED CLINICAL CONCEPTS & MEDICAL EXPLANATIONS     -->
        <!-- ======================================================== -->
        <div class="concept-category-title">Categorized Clinical Guide & Gerontology Breakdown</div>

        <!-- 1. PHYSIOLOGICAL SENESCENCE -->
        <div class="concept-card">
          <div class="concept-title">1. Multiorgan Physiological Changes of Aging (Senescence)</div>
          <div class="concept-body">
            <ul>
              <li><strong>Cardiovascular:</strong> Arterial wall stiffening (arteriosclerosis) causing isolated systolic hypertension; left ventricular hypertrophy; decreased baroreceptor sensitivity predisposing to <em>Orthostatic Hypotension</em> and fall injuries.</li>
              <li><strong>Respiratory:</strong> Reduced chest wall compliance, calcification of costal cartilages, decreased alveolar surface area, and blunted cough reflex, predisposing to silent aspiration pneumonia.</li>
              <li><strong>Renal:</strong> Progressive decline in Glomerular Filtration Rate (GFR decreases ~1 mL/min/yr after age 40) and reduction in renal cortical blood flow. <em>Clinical Warning:</em> Serum creatinine remains deceptively normal due to decreased skeletal muscle mass; creatinine clearance must be calculated.</li>
              <li><strong>Gastrointestinal & Hepatic:</strong> Decreased gastric acid secretion (achlorhydria reduces Vitamin B12, Iron, and Calcium absorption); slowed peristalsis causing chronic constipation; reduced hepatic cytochrome P450 enzyme activity prolongs drug half-life.</li>
            </ul>
          </div>
        </div>

        <!-- 2. PHARMACOLOGICAL SAFETY & BEERS CRITERIA -->
        <div class="concept-card">
          <div class="concept-title">2. Pharmacological Safety, Polypharmacy & AGS Beers Criteria</div>
          <div class="concept-body">
            <p>Polypharmacy (&ge;5 concurrent medications) exponentially multiplies adverse drug-drug interactions. The <em>American Geriatrics Society Beers Criteria</em> strictly advises against high-risk medications in older adults:</p>
            <ul>
              <li><strong>Long-acting benzodiazepines (Diazepam, Flurazepam):</strong> High risk of prolonged sedation, ataxia, severe falls, and fractures.</li>
              <li><strong>First-generation antihistamines (Diphenhydramine, Hydroxyzine):</strong> Potent anticholinergic effects causing acute delirium, urinary retention, dry mouth, and constipation.</li>
              <li><strong>Chronic NSAIDs (Indomethacin, Ketorolac, Ibuprofen):</strong> High risk of occult GI bleeding, peptic ulcer disease, and acute renal failure.</li>
            </ul>
          </div>
        </div>

        <!-- ======================================================== -->
        <!-- SECTION B: PAST UNIVERSITY EXAM QUESTIONS & ANSWERS      -->
        <!-- ======================================================== -->
        <div class="section-divider-title">Exact University Exam Questions & 2–5 Page Model Answers</div>

        <!-- QUESTION 1: FEB 2025 (SUPP) Q.5d & JULY 2022 Q.5c [5 MARKS] -->
        <div class="q-block">
          <div class="q-header">
            <span class="q-badge">MPMSU Feb 2025 (Supp) Q.5d & July 2022 Q.5c [5 Marks]</span>
            <span class="q-weight">Repeated Short Note | Target: 2–3 Handwritten Pages</span>
          </div>
          <div class="q-text-prompt">
            <strong>Exam Question:</strong> Short Note: Role of nurse in care of elderly (5 Marks).
          </div>
          <div class="q-answer-content">
            <div class="ans-part">
              <div class="ans-part-title">Comprehensive Clinical Answer: Role of Nurse in Care of Elderly</div>
              <div class="ans-part-body">
                <p><strong>Introduction:</strong> Geriatric nursing focuses on the comprehensive assessment, health promotion, disease prevention, and specialized clinical care of older adults (&gt;60–65 years), addressing the physiological, psychological, and social declines of senescence.</p>

                <p><strong>1. Comprehensive Geriatric Physical & Physiological Care:</strong></p>
                <ul>
                  <li><strong>Fall Prevention & Mobility Safety (Hendrich II / Morse Fall Scale):</strong>
                    <ul>
                      <li>Assess gait, balance, postural instability, and orthostatic hypotension.</li>
                      <li>Environmental modifications: Ensure adequate glare-free lighting, nightlights, non-skid rubber footwear, remove scatter rugs, install sturdy grab bars in bathrooms, keep bed in lowest position with side rails up.</li>
                      <li>Assist with mobility aids (walker, cane) and encourage daily gentle weight-bearing exercises to prevent disuse osteoporosis.</li>
                    </ul>
                  </li>
                  <li><strong>Skin Integrity & Pressure Injury Prevention (Braden Scale):</strong>
                    <ul>
                      <li>Aging causes epidermal thinning, loss of subcutaneous fat, and reduced vascularity.</li>
                      <li>Reposition bedbound elderly every 2 hours; use pressure-relieving air mattresses.</li>
                      <li>Apply skin moisturizers; avoid harsh alkaline soaps; keep skin clean, dry, and hydrated.</li>
                    </ul>
                  </li>
                  <li><strong>Nutritional & Hydration Support:</strong>
                    <ul>
                      <li>Reduced sense of taste/smell, loss of dentition, and decreased gastric motility lead to anorexia.</li>
                      <li>Provide nutrient-dense, high-fiber diets (prevent constipation) with adequate calcium (1200 mg/day) and Vitamin D (800 IU/day).</li>
                      <li>Offer frequent small sips of water throughout the day (elderly have blunted thirst mechanism, predisposing to hypernatremic dehydration).</li>
                    </ul>
                  </li>
                  <li><strong>Elimination Needs:</strong>
                    <ul>
                      <li>Establish a scheduled toileting regimen q2h to manage urge/stress incontinence; avoid unnecessary indwelling catheterization to prevent CAUTI.</li>
                    </ul>
                  </li>
                </ul>

                <p><strong>2. Pharmacological Safety & Polypharmacy Management:</strong></p>
                <ul>
                  <li>Elderly have altered pharmacokinetics: Reduced hepatic cytochrome P450 metabolism and decreased glomerular filtration rate (GFR), increasing drug half-life and toxicity risks.</li>
                  <li>Nurse's Role: Review all prescriptions against the <em>Beers Criteria</em> (avoid anticholinergics, long-acting benzodiazepines, and high-dose NSAIDs). "Start low and go slow." Use pill organizers and large-print labels.</li>
                </ul>

                <p><strong>3. Psychosocial Support & Cognitive Monitoring:</strong></p>
                <ul>
                  <li>Differentiate between the 3 D's of Geriatric Psychiatry: <strong>Delirium</strong> (acute, fluctuating, reversible), <strong>Dementia</strong> (chronic, progressive, irreversible), and <strong>Depression</strong> (pseudodementia, treatable).</li>
                  <li>Facilitate reality orientation, reminiscence therapy, and encourage socialization to counteract loneliness and bereavement depression.</li>
                </ul>
              </div>
            </div>
          </div>
        </div>

        <!-- QUESTION 2: FEB 2020 (MAIN) Q.5b [5 MARKS] -->
        <div class="q-block">
          <div class="q-header">
            <span class="q-badge">MPMSU Feb 2020 (Main) — Q.5b [5 Marks]</span>
            <span class="q-weight">Short Note | Target: 2–3 Handwritten Pages</span>
          </div>
          <div class="q-text-prompt">
            <strong>Exam Question:</strong> Short Note: Psychological aspects of aging (5 Marks).
          </div>
          <div class="q-answer-content">
            <div class="ans-part">
              <div class="ans-part-title">Comprehensive Clinical Answer: Psychological Aspects of Aging</div>
              <div class="ans-part-body">
                <p><strong>Overview:</strong> Psychological aging encompasses changes in cognitive functioning, emotional coping, personality dynamics, and developmental tasks as individuals confront physical decline, loss of social roles, and impending mortality.</p>

                <p><strong>1. Erik Erikson's Psychosocial Developmental Stage (Ego Integrity vs. Despair):</strong></p>
                <ul>
                  <li><em>Ego Integrity:</em> The older adult looks back over their lifespan with a sense of fulfillment, acceptance of life choices, and peaceful reconciliation with mortality. Result: Wisdom.</li>
                  <li><em>Despair:</em> Feeling that life was meaningless, filled with missed opportunities, deep regret, bitterness, and intense terror of death. Leads to late-life depression.</li>
                </ul>

                <p><strong>2. Cognitive Changes Associated with Normal Aging:</strong></p>
                <ul>
                  <li><em>Fluid Intelligence:</em> Speed of information processing, novel problem solving, and divided attention mildly decline.</li>
                  <li><em>Crystallized Intelligence:</em> Accumulated wisdom, vocabulary, general knowledge, and semantic memory remain completely preserved or improve.</li>
                  <li><em>Benign Senescent Forgetfulness:</em> Occasional difficulty retrieving names or recent details (prompted by cues), which differs distinctly from the executive and memory deficits of Alzheimer's dementia.</li>
                </ul>

                <p><strong>3. Common Psychosocial Stressors & Mental Health Challenges:</strong></p>
                <ul>
                  <li><strong>Multiple Losses (Bereavement Overload):</strong> Death of spouse, siblings, and lifelong peers; loss of economic independence post-retirement ("Empty Nest Syndrome"); loss of physical vigor.</li>
                  <li><strong>Social Isolation & Loneliness:</strong> Nuclear family transitions lead to severe isolation, triggering geriatric depression (often masked by somatic complaints like insomnia, fatigue, and pain).</li>
                  <li><strong>Anxiety & Fear of Dependency:</strong> Dread of becoming a burden to children, fear of institutionalization in nursing homes, and fear of prolonged painful dying.</li>
                </ul>

                <p><strong>4. Nursing Interventions for Psychological Well-Being:</strong></p>
                <ul>
                  <li>Conduct <em>Reminiscence Therapy and Life Review</em>: Encourage older adults to share past life accomplishments, photos, and stories to reinforce ego integrity.</li>
                  <li>Promote autonomy and decision-making in daily hospital routines (choice of clothing, food, timing of baths).</li>
                  <li>Connect to community senior citizen centers, religious forums, and active hobby groups.</li>
                </ul>
              </div>
            </div>
          </div>
        </div>

        <!-- QUESTION 3: MAY 2019 (MAIN) Q.5e [5 MARKS] -->
        <div class="q-block">
          <div class="q-header">
            <span class="q-badge">MPMSU May 2019 (Main) — Q.5e [5 Marks]</span>
            <span class="q-weight">Short Note | Target: 2–3 Handwritten Pages</span>
          </div>
          <div class="q-text-prompt">
            <strong>Exam Question:</strong> Short Note: Legal and ethical issues in geriatric care (5 Marks).
          </div>
          <div class="q-answer-content">
            <div class="ans-part">
              <div class="ans-part-title">Comprehensive Clinical Answer: Legal and Ethical Issues in Geriatric Care</div>
              <div class="ans-part-body">
                <p><strong>Overview:</strong> Geriatric care frequently involves vulnerable older adults who may experience cognitive impairment, physical debility, and complete financial dependence, raising profound legal and ethical challenges.</p>

                <p><strong>1. Autonomy vs. Beneficence & Paternalism:</strong></p>
                <ul>
                  <li><em>Ethical Dilemma:</em> Balancing the elderly patient's fundamental right to self-determination (autonomy) against the nurse/family desire to protect them from harm (beneficence).</li>
                  <li><em>Example:</em> An 82-year-old insists on living alone despite frequent falls; forcing institutionalization without consent violates autonomy unless mental incompetence is legally proven.</li>
                </ul>

                <p><strong>2. Informed Consent & Decision-Making Capacity:</strong></p>
                <ul>
                  <li>Every adult is legally presumed competent until adjudicated otherwise by a court of law.</li>
                  <li>The nurse must assess decision-making capacity: Can the patient understand treatment risks, benefits, alternatives, and express a voluntary choice?</li>
                  <li>If cognitive impairment (severe dementia/coma) exists, care decisions revert to a legally appointed surrogate, durable power of attorney (DPOA) for healthcare, or legal guardian.</li>
                </ul>

                <p><strong>3. End-of-Life Care, Advance Directives & DNR Orders:</strong></p>
                <ul>
                  <li><strong>Living Wills & Advance Directives:</strong> Legal documents specifying treatments the patient wishes to receive or refuse if incapacitated.</li>
                  <li><strong>Do Not Resuscitate (DNR) / Allow Natural Death (AND):</strong> Must have a written physician order based on explicit patient/family wishes. The nurse must understand that DNR does NOT mean "do not care"—it forbids CPR, electrical cardioversion, and invasive intubation, but mandates vigorous palliative comfort care, pain relief, and symptom management.</li>
                  <li>Withholding vs. Withdrawing Life-Sustaining Treatment: Ethically equivalent when treatments are deemed medically futile.</li>
                </ul>

                <p><strong>4. Elder Abuse and Neglect (Legal Mandates):</strong></p>
                <ul>
                  <li>Types: Physical abuse, psychological/emotional abuse, financial exploitation (misappropriation of pension/property), sexual abuse, and active/passive caregiver neglect (withholding food, hygiene, or medications).</li>
                  <li><em>Nurse's Legal Responsibility:</em> The nurse is a mandated reporter. Must document unexplained bruises, burns, malnutrition, pressure sores, and poor hygiene, and report suspected elder abuse to hospital authorities and social services under the <em>Maintenance and Welfare of Parents and Senior Citizens Act (India, 2007)</em>.</li>
                </ul>

                <p><strong>5. Use of Physical and Chemical Restraints:</strong></p>
                <ul>
                  <li>Restraints compromise dignity, increase fall severity, cause nerve damage, and provoke fatal asphyxiation. Restraints are an intervention of absolute last resort, requiring a time-limited physician order, continuous q15min monitoring, and release q2h for skin care and ROM.</li>
                </ul>
              </div>
            </div>
          </div>
        </div>

      </div>
    </div>

    <!-- ------------------------------------------------------------ -->
    <!-- TOPIC 5: NEUROLOGY: MENINGITIS & CEREBROVASCULAR ACCIDENT    -->
    <!-- ------------------------------------------------------------ -->`},{id:`grp-neuro`,title:`Neurology (Meningitis & Cerebrovascular Accident / CVA)`,repeatCount:3,years:[`2019`,`2020`,`2022`,`2025`],probability:90,priorityTier:`Tier 2 • Very High`,tierClass:`tier-high`,subItems:[{concept:`Bacterial meningitis: Kernig's/Brudzinski's signs, CSF profile & antibiotic therapy`,years:`2020, 2025`},{concept:`CVA (Stroke): Ischemic vs hemorrhagic, NIHSS, tPA protocols & ICP control`,years:`2019, 2022`},{concept:`Comprehensive Nursing Care Plan for hemiplegic patient & rehabilitation`,years:`2022`}],questions:[{paperBadge:`MPMSU Feb 2025 (Supp) Q.3 & Feb 2020 Q.3 [15 Marks]`,weight:`Full Long Essay | Target: 5 Handwritten Pages`,questionText:`a. Define Meningitis (2) | b. Enlist the causes, types and clinical features of Meningitis (5) | c. Discuss the medical and nursing management of a patient with Meningitis (8).`},{paperBadge:`MPMSU July 2022 (Main & Supp) — Q.1 [15 Marks]`,weight:`Full Long Essay | Target: 5 Handwritten Pages`,questionText:`a. Define Cerebrovascular Accident (CVA) (2) | b. Explain the etiology, risk factors and pathophysiology of CVA (5) | c. Discuss the emergency and acute medical management of ischemic vs hemorrhagic stroke (4) | d. Formulate a comprehensive Nursing Care Plan for a hemiplegic patient (4).`}],answerHtml:`<!-- ======================================================== -->
        <!-- CATEGORIZED CLINICAL CONCEPTS & MEDICAL EXPLANATIONS     -->
        <!-- ======================================================== -->
        <div class="concept-category-title">Categorized Clinical Guide & Neurology Breakdown</div>

        <!-- 1. MENINGEAL ANATOMY & SUBARACHNOID DYNAMICS -->
        <div class="concept-card">
          <div class="concept-title">1. Cranial Meningeal Architecture & Subarachnoid Space Dynamics</div>
          <div class="concept-body">
            <p><strong>Pathophysiology of Bacterial Meningitis:</strong> Encapsulated pathogens (<em>Streptococcus pneumoniae, Neisseria meningitidis</em>) colonize the nasopharynx, enter the bloodstream, and breach the blood-brain barrier at the choroid plexus into the subarachnoid space. Bacterial endotoxin release triggers massive neutrophilic degranulation, producing thick, purulent exudate along basal cisterns and sulci:</p>
            
            <img src="/pyqs/images/meninges.jpg" class="med-img" alt="3D Medical Illustration: Cranial Meninges & CSF Subarachnoid Space">
            
            <div class="img-notes">
              <strong>Meningeal Layers & Clinical Correlates:</strong>
              <br>&bull; <strong>Dura Mater (Pachymeninx):</strong> Thick, fibrous outer dual layer adherent to the inner skull, enclosing dural venous sinuses.
              <br>&bull; <strong>Arachnoid Mater & Villi:</strong> Avascular web-like intermediate layer with arachnoid granulations that resorb CSF into venous circulation. Exudate blocks these villi, precipitating acute hydrocephalus and ICP elevation.
              <br>&bull; <strong>Subarachnoid Space:</strong> Contains ~150 mL of circulating CSF. Site of purulent accumulation causing classic meningeal signs: Nuchal rigidity, Kernig's sign (pain/resistance on knee extension with hip flexed 90&deg;), and Brudzinski's sign (involuntary hip/knee flexion when neck is flexed).
              <br>&bull; <strong>Pia Mater:</strong> Delicate, highly vascular membrane intimately adherent to cerebral cortex gyri.
            </div>
          </div>
        </div>

        <!-- 2. LUMBAR PUNCTURE & CSF DIFFERENTIATION -->
        <div class="concept-card">
          <div class="concept-title">2. Lumbar Puncture & CSF Laboratory Diagnostic Differentiation</div>
          <div class="concept-body">
            <p>Lumbar puncture (performed at L3–L4 or L4–L5 interspace) provides definitive microbiological and biochemical differentiation:</p>
            
            <table class="clinical-table" style="margin-top: 8px;">
              <thead>
                <tr><th>Diagnostic Parameter</th><th>Normal Reference Values</th><th>Bacterial (Pyogenic) Meningitis</th><th>Viral (Aseptic) Meningitis</th><th>Tubercular (TB) Meningitis</th></tr>
              </thead>
              <tbody>
                <tr><td><strong>Opening Pressure</strong></td><td>70–180 mmH2O</td><td><strong>Markedly Elevated (&gt;200–300 mmH2O)</strong></td><td>Normal to slightly elevated</td><td>Markedly elevated</td></tr>
                <tr><td><strong>Gross Appearance</strong></td><td>Crystal clear, colorless</td><td><strong>Turbid, cloudy, purulent</strong></td><td>Clear to faintly opalescent</td><td>Clear to yellowish (cobweb coagulum)</td></tr>
                <tr><td><strong>WBC Count</strong></td><td>0–5 /&mu;L (mononuclear)</td><td><strong>Markedly Elevated (1,000–10,000+ /&mu;L)</strong><br>&gt;80–90% Polymorphonuclear (PMNs)</td><td>Mildly elevated (50–500 /&mu;L)<br>Predominantly Lymphocytes</td><td>Moderately elevated (100–500 /&mu;L)<br>Predominantly Lymphocytes</td></tr>
                <tr><td><strong>Protein Level</strong></td><td>15–45 mg/dL</td><td><strong>Severely Elevated (100–500+ mg/dL)</strong></td><td>Normal to slightly high (&lt;100 mg/dL)</td><td>Markedly high (100–500 mg/dL)</td></tr>
                <tr><td><strong>Glucose Concentration</strong></td><td>50–80 mg/dL (&gt;60% blood)</td><td><strong>Severely Depressed (&lt;40 mg/dL)</strong><br>CSF:Serum Glucose Ratio &lt; 0.4</td><td>Normal (&gt;60% blood glucose)</td><td>Severely depressed (&lt;30 mg/dL)</td></tr>
                <tr><td><strong>Gram Stain / Culture</strong></td><td>Sterile</td><td><strong>Positive in 60–80%</strong></td><td>Negative for bacteria (PCR positive)</td><td>Acid-Fast Bacilli (AFB / GeneXpert)</td></tr>
              </tbody>
            </table>
          </div>
        </div>

        <!-- 3. CVA STROKE & ISCHEMIC PENUMBRA -->
        <div class="concept-card">
          <div class="concept-title">3. Cerebrovascular Accident (CVA / Stroke): Ischemic Penumbra & Thrombolysis</div>
          <div class="concept-body">
            <p><strong>Ischemic Core vs Penumbra:</strong> In acute ischemic stroke, the central "Ischemic Core" undergoes rapid liquefaction necrosis within minutes. Surrounding it is the <strong>Ischemic Penumbra</strong> &mdash; hypoperfused but metabolically salvageable tissue. The therapeutic window to restore perfusion via IV rt-PA (Alteplase 0.9 mg/kg) is strictly <strong>3 to 4.5 hours from symptom onset</strong> ("Time is Brain").</p>
            <ul>
              <li><strong>Acute Stroke Nursing Priorities:</strong> Maintain NPO until formal swallow screen; elevate head of bed 30&deg; to promote venous drainage without compromising cerebral perfusion pressure; maintain blood pressure &lt;185/110 mmHg if receiving tPA; perform serial neurological assessments using the NIH Stroke Scale (NIHSS).</li>
            </ul>
          </div>
        </div>

        <!-- ======================================================== -->
        <!-- SECTION B: PAST UNIVERSITY EXAM QUESTIONS & ANSWERS      -->
        <!-- ======================================================== -->
        <div class="section-divider-title">Exact University Exam Questions & 2–5 Page Model Answers</div>

        <!-- QUESTION 1: FEB 2025 (SUPP) Q.3 & FEB 2020 Q.3 [15 MARKS] -->
        <div class="q-block">
          <div class="q-header">
            <span class="q-badge">MPMSU Feb 2025 (Supp) Q.3 & Feb 2020 Q.3 [15 Marks]</span>
            <span class="q-weight">Full Long Essay | Target: 5 Handwritten Pages</span>
          </div>
          <div class="q-text-prompt">
            <strong>Exam Question:</strong> a. Define Meningitis (2) | b. Enlist the causes, types and clinical features of Meningitis (5) | c. Discuss the medical and nursing management of a patient with Meningitis (8).
          </div>
          <div class="q-answer-content">
            <div class="ans-part">
              <div class="ans-part-title">Part (a): Definition of Meningitis (2 Marks)</div>
              <div class="ans-part-body">
                <p><strong>Meningitis:</strong> An acute, life-threatening infectious inflammation of the pia mater, arachnoid mater, and the intervening subarachnoid cerebrospinal fluid (CSF) space. It results in purulent exudate accumulation in the subarachnoid space, cerebral endothelial injury, blood-brain barrier disruption, cerebral edema, elevated intracranial pressure (ICP), and risk of brain herniation and death.</p>
              </div>
            </div>

            <div class="ans-part">
              <div class="ans-part-title">Part (b): Causes, Types & Clinical Features (5 Marks)</div>
              <div class="ans-part-body">
                <p><strong>1. Classification by Etiological Organism:</strong></p>
                <ul>
                  <li><strong>Acute Bacterial (Pyogenic) Meningitis (Medical Emergency):</strong>
                    <ul>
                      <li>Adults: <em>Streptococcus pneumoniae</em> (Pneumococcus) and <em>Neisseria meningitidis</em> (Meningococcus).</li>
                      <li>Neonates: <em>Group B Streptococcus (GBS)</em>, <em>Escherichia coli</em>, and <em>Listeria monocytogenes</em>.</li>
                      <li>Children: <em>Haemophilus influenzae</em> type b (Hib) and Pneumococcus.</li>
                    </ul>
                  </li>
                  <li><strong>Viral (Aseptic) Meningitis:</strong> Enteroviruses (Coxsackievirus, Echovirus), HSV-2, Arboviruses; usually benign and self-limiting.</li>
                  <li><strong>Tuberculous (TB) Meningitis:</strong> <em>Mycobacterium tuberculosis</em>; causes thick gelatinous basal exudates entrapping cranial nerves (III, IV, VI, VII).</li>
                  <li><strong>Fungal Meningitis:</strong> <em>Cryptococcus neoformans</em> in immunocompromised (HIV/AIDS) patients.</li>
                </ul>

                <p><strong>2. Cerebrospinal Fluid (CSF) Analysis (Lumbar Puncture):</strong></p>
                <table class="clinical-table">
                  <thead>
                    <tr><th>Parameter</th><th>Normal</th><th>Bacterial Meningitis</th><th>Viral Meningitis</th><th>Tubercular (TB)</th></tr>
                  </thead>
                  <tbody>
                    <tr><td><strong>Appearance</strong></td><td>Clear, water-like</td><td>Turbid, purulent, cloudy</td><td>Clear or opalescent</td><td>Cobweb coagulum / hazy</td></tr>
                    <tr><td><strong>Opening Pressure</strong></td><td>70–180 mmH2O</td><td>Markedly elevated (&gt;250)</td><td>Normal or slightly elevated</td><td>Markedly elevated</td></tr>
                    <tr><td><strong>WBC Count</strong></td><td>0–5 /mm3 (lymphocytes)</td><td>1,000–10,000+ (predominantly Neutrophils)</td><td>50–500 (predominantly Lymphocytes)</td><td>100–500 (predominantly Lymphocytes)</td></tr>
                    <tr><td><strong>Protein</strong></td><td>15–45 mg/dL</td><td>Markedly elevated (&gt;100–500)</td><td>Slightly elevated (50–100)</td><td>Extremely elevated (&gt;100–500)</td></tr>
                    <tr><td><strong>Glucose Ratio</strong></td><td>&gt;60% of blood glucose</td><td>Markedly decreased (&lt;40% or undetectable)</td><td>Normal (&gt;60% of blood glucose)</td><td>Markedly decreased (&lt;30%)</td></tr>
                  </tbody>
                </table>

                <p><strong>3. Classical Clinical Features:</strong></p>
                <ul>
                  <li><strong>Classic Meningeal Triad:</strong> Fever (high-grade &gt;39°C), Severe throbbing generalized headache, and Nuchal Rigidity (neck stiffness unable to touch chin to chest).</li>
                  <li><strong>Signs of Meningeal Irritation:</strong>
                    <ul>
                      <li><em>Kernig's Sign:</em> Inability or severe pain on extending the leg at the knee when the thigh is flexed at 90° to the hip.</li>
                      <li><em>Brudzinski's Neck Sign:</em> Involuntary reflexive flexion of the patient's hips and knees upon passive flexion of the neck.</li>
                    </ul>
                  </li>
                  <li><strong>Signs of Elevated ICP:</strong> Projectile vomiting without nausea, altered sensorium (lethargy to coma), papilledema, photophobia, seizures, and Cushing's Triad (systolic hypertension with widening pulse pressure, bradycardia, irregular respirations).</li>
                  <li><strong>Meningococcal Characteristic:</strong> Petechial or purpuric skin rash; risk of fulminant Waterhouse-Friderichsen syndrome (bilateral adrenal hemorrhage, DIC, and septic shock).</li>
                </ul>
              </div>
            </div>

            <div class="ans-part">
              <div class="ans-part-title">Part (c): Medical & Nursing Management of Meningitis (8 Marks)</div>
              <div class="ans-part-body">
                <p><strong>1. Emergency Medical Management:</strong></p>
                <ul>
                  <li><strong>Immediate Empirical IV Antibiotic Therapy (Within 30–60 Min):</strong>
                    <ul>
                      <li>Cefrtiaxone 2 g IV q12h OR Cefotaxime 2 g IV q4h PLUS Vancomycin 15–20 mg/kg IV q8–12h (covers penicillin-resistant pneumococci).</li>
                      <li>Add Ampicillin 2 g IV q4h in patients &gt;50 years or immunocompromised (covers <em>Listeria</em>).</li>
                    </ul>
                  </li>
                  <li><strong>Adjunctive Corticosteroid:</strong> IV Dexamethasone 10 mg administered 15–20 minutes <em>before or with the first dose</em> of antibiotics, continued q6h for 4 days. (Significantly reduces meningeal inflammation, cerebral edema, and prevents sensorineural hearing loss).</li>
                  <li><strong>Osmotherapy for Elevated ICP:</strong> IV Mannitol 20% (0.5–1.0 g/kg over 20 min) or Hypertonic Saline (3% NaCl).</li>
                  <li><strong>Anticonvulsant Prophylaxis:</strong> IV Levetiracetam (Keppra) 500–1000 mg BID or IV Lorazepam for active seizures.</li>
                </ul>

                <p><strong>2. Comprehensive Nursing Management:</strong></p>
                <table class="clinical-table">
                  <thead>
                    <tr><th>Intervention Domain</th><th>Specific Nursing Action</th><th>Rationale</th></tr>
                  </thead>
                  <tbody>
                    <tr>
                      <td><strong>Droplet Isolation Precautions</strong></td>
                      <td>Place patient in single room on strict Droplet Precautions for at least 24 hours after initiating effective antibiotic therapy. Staff wear surgical masks within 3 feet.</td>
                      <td>Prevents airborne droplet transmission of <em>N. meningitidis</em> and <em>H. influenzae</em>. Chemoprophylaxis (Rifampicin or Ciprofloxacin) for close contacts.</td>
                    </tr>
                    <tr>
                      <td><strong>Neurological & ICP Monitoring</strong></td>
                      <td>Perform Glasgow Coma Scale (GCS) and pupil assessment q1h. Monitor vital signs for Cushing's Triad (widening pulse pressure, bradycardia).</td>
                      <td>Early detection of brainstem compression and impending uncal herniation.</td>
                    </tr>
                    <tr>
                      <td><strong>Positioning & Comfort</strong></td>
                      <td>Elevate head of bed 30° with neck in neutral midline position. Avoid neck flexion, hip hyperflexion, or prone position. Keep room quiet and lights dimmed.</td>
                      <td>Facilitates cerebral venous drainage via internal jugular veins, minimizing intracranial pressure and photophobia.</td>
                    </tr>
                    <tr>
                      <td><strong>Seizure Precautions</strong></td>
                      <td>Padded side rails, suction equipment, oxygen flowmeter, and oral airway available at bedside. Never force objects into mouth during seizure.</td>
                      <td>Meningeal cortical irritation lowers seizure threshold; prevents hypoxia and physical trauma.</td>
                    </tr>
                    <tr>
                      <td><strong>Fever & Fluid Balance</strong></td>
                      <td>Administer IV Paracetamol; use tepid sponging and cooling blankets. Avoid shivering (increases metabolic rate and ICP). Maintain normovolemia; avoid overhydration (worsens cerebral edema).</td>
                      <td>Hyperthermia exacerbates cerebral metabolic demand and neuronal ischemic injury.</td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </div>

        <!-- QUESTION 2: JULY 2022 (MAIN) Q.1 [15 MARKS] -->
        <div class="q-block">
          <div class="q-header">
            <span class="q-badge">MPMSU July 2022 (Main & Supp) — Q.1 [15 Marks]</span>
            <span class="q-weight">Full Long Essay | Target: 5 Handwritten Pages</span>
          </div>
          <div class="q-text-prompt">
            <strong>Exam Question:</strong> a. Define Cerebrovascular Accident (CVA) (2) | b. Explain the etiology, risk factors and pathophysiology of CVA (5) | c. Discuss the emergency and acute medical management of ischemic vs hemorrhagic stroke (4) | d. Formulate a comprehensive Nursing Care Plan for a hemiplegic patient (4).
          </div>
          <div class="q-answer-content">
            <div class="ans-part">
              <div class="ans-part-title">Part (a): Definition of Cerebrovascular Accident (CVA / Stroke) (2 Marks)</div>
              <div class="ans-part-body">
                <p><strong>Cerebrovascular Accident (Stroke / Brain Attack):</strong> A sudden focal neurological deficit lasting &gt;24 hours (or leading to death), caused by acute vascular injury to the central nervous system. It results either from vascular occlusion causing localized cerebral tissue infarction (Ischemic Stroke - 85%) or rupture of a cerebral blood vessel causing intracerebral or subarachnoid hemorrhage (Hemorrhagic Stroke - 15%).</p>
              </div>
            </div>

            <div class="ans-part">
              <div class="ans-part-title">Part (b): Etiology, Risk Factors & Pathophysiology (5 Marks)</div>
              <div class="ans-part-body">
                <p><strong>Etiology:</strong></p>
                <ul>
                  <li><em>Thrombotic Stroke:</em> Atherosclerotic plaque rupture and thrombosis in large cerebral arteries (carotid bifurcation, middle cerebral artery).</li>
                  <li><em>Embolic Stroke:</em> Cardiogenic emboli originating from atrial fibrillation, mural thrombi after myocardial infarction, prosthetic heart valves, or infective endocarditis.</li>
                  <li><em>Hemorrhagic Stroke:</em> Chronic hypertension causing Charcot-Bouchard microaneurysm rupture in lenticulostriate vessels; rupture of Berry aneurysms in the Circle of Willis (Subarachnoid Hemorrhage); or arteriovenous malformations (AVMs).</li>
                </ul>
                <p><strong>Risk Factors:</strong></p>
                <ul>
                  <li><em>Modifiable:</em> Hypertension (Single most critical risk factor!), diabetes mellitus, atrial fibrillation, hyperlipidemia, cigarette smoking, obesity, physical inactivity.</li>
                  <li><em>Non-Modifiable:</em> Age &gt;55 years, male gender, positive family history, ethnicity.</li>
                </ul>
                <p><strong>Pathophysiology (Ischemic Penumbra Concept):</strong></p>
                <div class="callout">
                  Vascular occlusion ceases blood flow to central core tissue (CBF &lt;10 mL/100g/min), producing rapid irreversible liquefactive necrosis within minutes. Surrounding the necrotic core is the <strong>Ischemic Penumbra</strong>—hypoperfused, metabolically compromised but viable tissue (CBF 10–20 mL/100g/min). Loss of ATP halts Na+/K+ ATPase pumps, causing massive calcium influx, glutamate excitotoxicity, release of free radicals, and cytotoxic edema. <em>The therapeutic window is strictly 3–4.5 hours</em> to restore reperfusion before the penumbra undergoes irreversible infarction ("Time is Brain").
                </div>
              </div>
            </div>

            <div class="ans-part">
              <div class="ans-part-title">Part (c): Emergency & Acute Medical Management (Ischemic vs. Hemorrhagic) (4 Marks)</div>
              <div class="ans-part-body">
                <p><strong>Immediate Step 1: Emergency Non-Contrast Head CT Scan:</strong> The absolute mandatory first step to differentiate ischemic from hemorrhagic stroke before any antithrombotic or thrombolytic therapy can be considered.</p>

                <p><strong>Ischemic Stroke Management:</strong></p>
                <ul>
                  <li><strong>IV Thrombolysis (rt-PA / Alteplase 0.9 mg/kg, max 90 mg):</strong> Administer within <strong>3 to 4.5 hours</strong> of symptom onset. (Give 10% as IV bolus over 1 min, remaining 90% over 60 min).
                    <br><em>Contraindications:</em> Intracranial hemorrhage, active internal bleeding, platelet &lt;100,000, BP &gt;185/110 mmHg, recent stroke/head trauma within 3 months, INR &gt;1.7.</li>
                  <li><strong>Endovascular Mechanical Thrombectomy:</strong> For large vessel occlusions (LVO) of anterior circulation up to 6–24 hours from onset.</li>
                  <li><strong>Permissive Hypertension:</strong> Allow blood pressure up to 220/120 mmHg in non-thrombolyzed patients (or &lt;185/110 mmHg if receiving rt-PA) to maintain collateral perfusion to the penumbra.</li>
                  <li><strong>Antiplatelet Therapy:</strong> Oral Aspirin 150–325 mg started at 24–48 hours post-stroke (delay 24 hours if rt-PA given).</li>
                </ul>

                <p><strong>Hemorrhagic Stroke Management:</strong></p>
                <ul>
                  <li>Strict blood pressure lowering (Target SBP 140 mmHg) using IV Labetalol or Nicardipine infusion.</li>
                  <li>Rapid reversal of anticoagulation: Administer Prothrombin Complex Concentrate (PCC) and Vitamin K for Warfarin; Idarucizumab for Dabigatran.</li>
                  <li>Surgical decompression: Craniotomy and hematoma evacuation for cerebellar hematomas &gt;3 cm or decompressive hemicraniectomy for refractory intracranial hypertension.</li>
                  <li>Administer oral Nimodipine 60 mg q4h for 21 days in Subarachnoid Hemorrhage to prevent delayed cerebral vasospasm.</li>
                </ul>
              </div>
            </div>

            <div class="ans-part">
              <div class="ans-part-title">Part (d): Comprehensive Nursing Care Plan for Hemiplegic Stroke Patient (4 Marks)</div>
              <div class="ans-part-body">
                <table class="clinical-table">
                  <thead>
                    <tr><th>Nursing Diagnosis</th><th>Goal</th><th>Interventions & Rationales</th><th>Evaluation</th></tr>
                  </thead>
                  <tbody>
                    <tr>
                      <td><strong>Impaired Physical Mobility</strong> r/t hemiparesis/flaccidity and neuromuscular impairment.</td>
                      <td>Prevent joint contractures, shoulder subluxation, and achieve progressive mobility.</td>
                      <td>
                        &bull; Position flaccid upper limb: Support affected arm on a pillow in slight abduction, elbow slightly flexed, wrist extended, and fingers slightly flexed holding a hand roll.<br>
                        &bull; <em>PREVENT SHOULDER SUBLUXATION:</em> Never pull on the flaccid affected arm when moving or transferring the patient; use a supportive arm sling when out of bed.<br>
                        &bull; Apply high-top sneakers or footboards to prevent foot drop (plantar flexion contracture).<br>
                        &bull; Initiate passive Range of Motion (ROM) exercises 4–5 times daily beginning POD 1; progress to active-assistive exercises.
                      </td>
                      <td>No shoulder subluxation or flexion contractures; transfers safely with minimal assistance.</td>
                    </tr>
                    <tr>
                      <td><strong>Impaired Swallowing (Dysphagia) & Risk for Aspiration</strong> r/t cranial nerve impairment (IX, X, XII).</td>
                      <td>Prevent pulmonary aspiration and maintain adequate nutrition.</td>
                      <td>
                        &bull; Keep patient strictly NPO until formal bedside water swallow screen is performed.<br>
                        &bull; Position patient fully upright (90° High Fowler's) during all feedings and for 30–45 min after.<br>
                        &bull; Provide thickened liquids (nectar or honey consistency); avoid thin water and straws.<br>
                        &bull; Place food on the <em>unaffected side</em> of mouth; instruct patient to perform "Chin-tuck" maneuver while swallowing.<br>
                        &bull; Keep suction apparatus functioning at bedside.
                      </td>
                      <td>Lungs clear to auscultation bilaterally; afebrile; maintains weight without aspiration pneumonia.</td>
                    </tr>
                    <tr>
                      <td><strong>Unilateral Neglect & Sensory Deficit</strong> r/t right hemisphere parietal infarction.</td>
                      <td>Acknowledge affected side and maintain environmental safety.</td>
                      <td>
                        &bull; Initially approach patient from unaffected side, then gradually encourage scanning toward neglected side.<br>
                        &bull; Place personal care items and call bell within unaffected visual field.<br>
                        &bull; Teach patient to consciously turn head and visually inspect affected left arm/leg to avoid accidental trauma.
                      </td>
                      <td>Patient actively scans environment and touches neglected limb; zero accidental injury.</td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </div>

      </div>
    </div>

    <!-- ------------------------------------------------------------ -->
    <!-- TOPIC 6: CRITICAL CARE, TRIAGE & SHOCK (REPEATED 3/4)       -->
    <!-- ------------------------------------------------------------ -->`},{id:`grp-shock`,title:`Critical Care, Triage & Shock`,repeatCount:3,years:[`2019`,`2020`,`2022`],probability:90,priorityTier:`Tier 2 • Very High`,tierClass:`tier-high`,subItems:[{concept:`Shock: Stages, hypovolemic vs septic pathophysiology & vasoactive drugs`,years:`2022`},{concept:`Disaster & Emergency Triage: START algorithm & color-coded tagging (Red, Yellow, Green, Black)`,years:`2020`},{concept:`Role of nurse in disaster preparedness, response, and mitigating crisis`,years:`2019`}],questions:[{paperBadge:`MPMSU July 2022 (Main & Supp) — Q.4 [15 Marks]`,weight:`Full Long Essay | Target: 5 Handwritten Pages`,questionText:`a. Define Shock (2) | b. Explain the stages and types of Shock (5) | c. Discuss the clinical manifestations and medical management of Hypovolemic & Septic shock (4) | d. Nursing management of a patient in Shock (4).`},{paperBadge:`MPMSU Feb 2020 (Main) — Q.5a [5 Marks]`,weight:`Short Note | Target: 2–3 Handwritten Pages`,questionText:`Short Note: Triage in disaster / emergency (5 Marks).`},{paperBadge:`MPMSU May 2019 (Main) — Q.5d [5 Marks]`,weight:`Short Note | Target: 2–3 Handwritten Pages`,questionText:`Short Note: Role of nurse in disaster management (5 Marks).`}],answerHtml:`<!-- QUESTION 1: JULY 2022 (MAIN) Q.4 [15 MARKS] -->
        <div class="q-block">
          <div class="q-header">
            <span class="q-badge">MPMSU July 2022 (Main & Supp) — Q.4 [15 Marks]</span>
            <span class="q-weight">Full Long Essay | Target: 5 Handwritten Pages</span>
          </div>
          <div class="q-text-prompt">
            <strong>Exam Question:</strong> a. Define Shock (2) | b. Explain the stages and types of Shock (5) | c. Discuss the clinical manifestations and medical management of Hypovolemic & Septic shock (4) | d. Nursing management of a patient in Shock (4).
          </div>
          <div class="q-answer-content">
            <div class="ans-part">
              <div class="ans-part-title">Part (a): Definition of Shock (2 Marks)</div>
              <div class="ans-part-body">
                <p><strong>Shock:</strong> A state of acute, life-threatening circulatory failure characterized by inadequate tissue perfusion and impaired cellular oxygen utilization. The imbalance between cellular oxygen supply and metabolic demand leads to cellular hypoxia, shift from aerobic to anaerobic metabolism, lactic acidosis, cell membrane dysfunction, organ failure, and death.</p>
              </div>
            </div>

            <div class="ans-part">
              <div class="ans-part-title">Part (b): Stages and Types of Shock (5 Marks)</div>
              <div class="ans-part-body">
                <p><strong>1. Classification / Types of Shock:</strong></p>
                <ul>
                  <li><strong>Hypovolemic Shock:</strong> Loss of intravascular volume (hemorrhage, severe burns, trauma, dehydration, diabetic ketoacidosis).</li>
                  <li><strong>Cardiogenic Shock:</strong> Pump failure of the heart (acute massive MI, dysrhythmias, severe cardiomyopathy).</li>
                  <li><strong>Distributive (Vasodilatory) Shock:</strong> Loss of vascular tone and massive peripheral vasodilation:
                    <ul>
                      <li><em>Septic Shock:</em> Dysregulated host response to severe bacterial infection (endotoxin release).</li>
                      <li><em>Anaphylactic Shock:</em> Severe IgE-mediated hypersensitivity reaction (histamine release).</li>
                      <li><em>Neurogenic Shock:</em> Loss of sympathetic vasomotor tone following high spinal cord injury (&gt;T6).</li>
                    </ul>
                  </li>
                  <li><strong>Obstructive Shock:</strong> Physical mechanical obstruction to cardiac filling/outflow (cardiac tamponade, tension pneumothorax, massive pulmonary embolism).</li>
                </ul>

                <p><strong>2. Progressive Stages of Shock:</strong></p>
                <table class="clinical-table">
                  <thead>
                    <tr><th>Stage</th><th>Pathophysiological Mechanism</th><th>Clinical Manifestations</th></tr>
                  </thead>
                  <tbody>
                    <tr>
                      <td><strong>1. Compensatory (Non-Progressive)</strong></td>
                      <td>Baroreceptors stimulate SNS (epinephrine/norepinephrine release); RAAS activation; vasoconstriction; fluid retention. Blood shunted from skin, kidneys, GI tract to heart and brain.</td>
                      <td>Normal BP (or narrow pulse pressure); tachycardia (HR &gt;100 bpm); tachypnea; cool, pale, clammy skin; hypoactive bowel sounds; mild oliguria (30–35 mL/hr); anxiety, restlessness.</td>
                    </tr>
                    <tr>
                      <td><strong>2. Progressive (Decompensated)</strong></td>
                      <td>Compensatory mechanisms fail; capillary permeability increases; massive fluid extravasation into interstitium; profound tissue ischemia; anaerobic glycolysis causes lactic acidosis.</td>
                      <td>Hypotension (SBP &lt;90 mmHg or drop &gt;40 mmHg); rapid, thready pulse; rapid shallow breathing with crackles; oliguria (&lt;20 mL/hr); cold, mottled, cyanotic skin; lethargy, stupor; elevated lactate (&gt;2 mmol/L).</td>
                    </tr>
                    <tr>
                      <td><strong>3. Irreversible (Refractory)</strong></td>
                      <td>Severe cellular necrosis, mitochondrial death, microvascular thrombosis (DIC), myocardial depression, and Multiple Organ Dysfunction Syndrome (MODS - ARDS, acute renal failure, hepatic failure).</td>
                      <td>Severe refractory hypotension unresponsive to fluids and vasopressors; profound coma; anuria; hypothermia; death is imminent.</td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>

            <div class="ans-part">
              <div class="ans-part-title">Part (c): Clinical Manifestations & Medical Management (Hypovolemic vs. Septic) (4 Marks)</div>
              <div class="ans-part-body">
                <p><strong>Hypovolemic Shock:</strong></p>
                <ul>
                  <li><em>Manifestations:</em> Hypotension, tachycardia, flat neck veins, dry mucous membranes, oliguria, cold extremities.</li>
                  <li><em>Medical Management:</em>
                    <ul>
                      <li>Rapid Volume Replacement (1st Priority): 2 large-bore IV lines (14–16G); infuse warm crystalloids (Ringer's Lactate or Normal Saline 0.9% 30 mL/kg bolus).</li>
                      <li>Blood Transfusion: Packed Red Blood Cells (PRBCs) if hemorrhagic shock (transfusion threshold Hb &lt;7 g/dL or active bleeding); activate massive transfusion protocol (1:1:1 ratio of PRBCs, FFP, platelets).</li>
                      <li>Stop ongoing loss (surgical hemostasis, tourniquet, endoscopy).</li>
                    </ul>
                  </li>
                </ul>

                <p><strong>Septic Shock (Surviving Sepsis Campaign 1-Hour Bundle):</strong></p>
                <ul>
                  <li><em>Manifestations:</em> Hyperthermia or hypothermia (&lt;36°C), tachycardia, tachypnea, warm flushed extremities (early "warm shock") transitioning to cold mottled skin (late "cold shock"), mental confusion, serum lactate &gt;2 mmol/L.</li>
                  <li><em>Medical Management:</em>
                    <ol>
                      <li>Measure serum lactate level immediately; remeasure if initial lactate &gt;2 mmol/L.</li>
                      <li>Obtain blood cultures (2 sets from different sites) BEFORE initiating antimicrobials.</li>
                      <li>Administer broad-spectrum IV antibiotics within 1 hour of recognition.</li>
                      <li>Rapid administration of 30 mL/kg crystalloid for hypotension or lactate &ge;4 mmol/L.</li>
                      <li>Apply vasopressors if hypotensive during or after fluid resuscitation to maintain Mean Arterial Pressure (MAP) &ge;65 mmHg: <strong>Norepinephrine is the 1st choice vasopressor</strong>; add Vasopressin (0.03 units/min) if needed.</li>
                    </ol>
                  </li>
                </ul>
              </div>
            </div>

            <div class="ans-part">
              <div class="ans-part-title">Part (d): Nursing Management of Patient in Shock (4 Marks)</div>
              <div class="ans-part-body">
                <table class="clinical-table">
                  <thead>
                    <tr><th>Priority Domain</th><th>Nursing Action & Protocol</th><th>Scientific Rationale</th></tr>
                  </thead>
                  <tbody>
                    <tr>
                      <td><strong>Positioning</strong></td>
                      <td>Place patient in <strong>Modified Trendelenburg position</strong> (head flat or elevated 10°, legs elevated 20–30° at hips with knees straight). <em>NEVER use full Trendelenburg</em>.</td>
                      <td>Elevating legs autotransfuses ~300–500 mL of blood from lower extremities back to central circulation without compromising lung expansion or increasing ICP.</td>
                    </tr>
                    <tr>
                      <td><strong>Oxygenation & Airway</strong></td>
                      <td>Administer high-flow oxygen via non-rebreather mask; assist with early endotracheal intubation and mechanical ventilation for respiratory exhaustion.</td>
                      <td>Maximizes arterial oxygen content (CaO2) and eliminates the high metabolic work of breathing.</td>
                    </tr>
                    <tr>
                      <td><strong>Hemodynamic Monitoring</strong></td>
                      <td>Monitor BP, HR, SpO2, and CVP continuously. Target MAP &ge;65 mmHg. Titrate vasopressor infusions via dedicated central venous line with an infusion pump.</td>
                      <td>MAP &ge;65 mmHg ensures adequate autoregulatory capillary perfusion to kidneys and brain.</td>
                    </tr>
                    <tr>
                      <td><strong>Renal Perfusion Surveillance</strong></td>
                      <td>Insert Foley catheter with urometer; measure output strictly hourly.</td>
                      <td>Urine output &lt;0.5 mL/kg/hr indicates renal hypoperfusion and impending acute tubular necrosis.</td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </div>

        <!-- QUESTION 2: FEB 2020 (MAIN) Q.5a [5 MARKS] -->
        <div class="q-block">
          <div class="q-header">
            <span class="q-badge">MPMSU Feb 2020 (Main) — Q.5a [5 Marks]</span>
            <span class="q-weight">Short Note | Target: 2–3 Handwritten Pages</span>
          </div>
          <div class="q-text-prompt">
            <strong>Exam Question:</strong> Short Note: Triage in disaster / emergency (5 Marks).
          </div>
          <div class="q-answer-content">
            <div class="ans-part">
              <div class="ans-part-title">Comprehensive Clinical Answer: Triage in Disaster & Emergency</div>
              <div class="ans-part-body">
                <p><strong>Definition:</strong> Triage (derived from French <em>trier</em>, "to sort") is the rapid categorization of casualties based on the severity of their injuries and likelihood of survival with immediate medical care, aimed at doing the "greatest good for the greatest number of people" when medical resources are overwhelmed.</p>

                <p><strong>1. Four-Color Disaster Triage System (International Standard):</strong></p>
                <table class="clinical-table">
                  <thead>
                    <tr><th>Color Tag</th><th>Priority</th><th>Clinical Category & Criteria</th><th>Examples</th></tr>
                  </thead>
                  <tbody>
                    <tr>
                      <td><strong style="color: #ef4444;">RED (Immediate)</strong></td>
                      <td><strong>Priority I</strong></td>
                      <td>Life-threatening injuries with high probability of survival if treated immediately within 60 minutes ("Golden Hour").</td>
                      <td>Airway obstruction, tension pneumothorax, major burns (20–40%), hypovolemic shock, open chest/abdominal wounds, unstable pelvic fractures.</td>
                    </tr>
                    <tr>
                      <td><strong style="color: #f59e0b;">YELLOW (Delayed)</strong></td>
                      <td><strong>Priority II</strong></td>
                      <td>Serious injuries requiring surgical care, but condition not immediately life-threatening; care can be delayed 1–2 hours without loss of life.</td>
                      <td>Stable large bone fractures (femur/tibia), closed head trauma without GCS deterioration, soft tissue wounds without active bleeding, eye injuries.</td>
                    </tr>
                    <tr>
                      <td><strong style="color: #10b981;">GREEN (Minimal / Ambulatory)</strong></td>
                      <td><strong>Priority III</strong></td>
                      <td>"Walking wounded"; minor injuries; care can be delayed hours to days.</td>
                      <td>Sprains, minor lacerations, abrasions, small superficial burns, psychiatric panic reactions.</td>
                    </tr>
                    <tr>
                      <td><strong style="color: #6b7280;">BLACK (Expectant / Deceased)</strong></td>
                      <td><strong>Priority 0 / IV</strong></td>
                      <td>Dead or with catastrophic fatal injuries where survival is impossible given available resources; provided comfort/palliative care only.</td>
                      <td>Cardiac arrest, decapitation, open brain injury with exposed tissue, massive full-thickness burns &gt;90% in mass casualty setting.</td>
                    </tr>
                  </tbody>
                </table>

                <p><strong>2. Simple Triage and Rapid Treatment (START) Algorithm:</strong></p>
                <ul>
                  <li><strong>Step 1 (Walking?):</strong> Direct all ambulatory casualties to walk to a designated area &rarr; Tagged <strong>GREEN</strong>.</li>
                  <li><strong>Step 2 (Respirations?):</strong> If absent, position airway:
                    <ul>
                      <li>If still not breathing &rarr; Tagged <strong>BLACK</strong>.</li>
                      <li>If starts breathing &rarr; Tagged <strong>RED</strong>.</li>
                      <li>If spontaneous breathing &gt;30 breaths/min &rarr; Tagged <strong>RED</strong>.</li>
                    </ul>
                  </li>
                  <li><strong>Step 3 (Perfusion?):</strong> Assess radial pulse or capillary refill:
                    <ul>
                      <li>Radial pulse absent OR capillary refill &gt;2 seconds &rarr; Tagged <strong>RED</strong>.</li>
                    </ul>
                  </li>
                  <li><strong>Step 4 (Mental Status?):</strong> Assess response to commands:
                    <ul>
                      <li>Cannot follow simple commands (unconscious/altered) &rarr; Tagged <strong>RED</strong>.</li>
                      <li>Can follow simple commands &rarr; Tagged <strong>YELLOW</strong>.</li>
                    </ul>
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </div>

        <!-- QUESTION 3: MAY 2019 (MAIN) Q.5d [5 MARKS] -->
        <div class="q-block">
          <div class="q-header">
            <span class="q-badge">MPMSU May 2019 (Main) — Q.5d [5 Marks]</span>
            <span class="q-weight">Short Note | Target: 2–3 Handwritten Pages</span>
          </div>
          <div class="q-text-prompt">
            <strong>Exam Question:</strong> Short Note: Role of nurse in disaster management (5 Marks).
          </div>
          <div class="q-answer-content">
            <div class="ans-part">
              <div class="ans-part-title">Comprehensive Clinical Answer: Role of Nurse in Disaster Management</div>
              <div class="ans-part-body">
                <p><strong>Overview:</strong> Disaster management encompasses four distinct phases: <em>Mitigation/Prevention, Preparedness, Response, and Recovery</em>. The professional nurse plays a central operational and leadership role across all phases.</p>

                <p><strong>1. Disaster Preparedness Phase (Pre-Disaster):</strong></p>
                <ul>
                  <li>Participate in hospital and community Disaster Management Committee drills (e.g., Code Black / Mass Casualty Drills).</li>
                  <li>Maintain emergency stockpile inventories: IV fluids, trauma dressings, endotracheal tubes, blood products, and emergency medications (Atropine, Adrenaline, Morphine).</li>
                  <li>Educate community members on basic life support (BLS), first aid, family disaster supply kits, and evacuation routes.</li>
                </ul>

                <p><strong>2. Disaster Response Phase (During Disaster):</strong></p>
                <ul>
                  <li><strong>Rapid Primary Triage:</strong> Nurse applies START triage at the incident site or emergency department triage gate, sorting casualties rapidly within 30–60 seconds into Red, Yellow, Green, and Black categories.</li>
                  <li><strong>Direct Clinical Resuscitation:</strong> Establish airways, perform bag-valve-mask ventilation, control external hemorrhages using pressure dressings/tourniquets, establish high-flow IV access, and administer emergency resuscitation fluids.</li>
                  <li><strong>Infection Control & Decontamination:</strong> In Chemical, Biological, Radiological, or Nuclear (CBRN) disasters, ensure casualties undergo decontamination before entering the emergency department to protect hospital infrastructure from secondary contamination.</li>
                  <li><strong>Documentation & Tracking:</strong> Maintain accurate disaster tag documentation (vital signs, administered medications, identifying information) to track patients and prevent duplication.</li>
                </ul>

                <p><strong>3. Disaster Recovery Phase (Post-Disaster):</strong></p>
                <ul>
                  <li><strong>Psychological First Aid (PFA):</strong> Screen survivors and healthcare responders for Acute Stress Reaction and Post-Traumatic Stress Disorder (PTSD); provide crisis counseling.</li>
                  <li><strong>Rehabilitation:</strong> Coordinate long-term physical therapy, wound reconstruction, prosthetics, and social welfare support for disabled victims.</li>
                  <li><strong>Debriefing & Quality Audit:</strong> Participate in post-incident clinical audits to identify workflow bottlenecks and update the institutional disaster manual.</li>
                </ul>
              </div>
            </div>
          </div>
        </div>

      </div>
    </div>

    <!-- ------------------------------------------------------------ -->
    <!-- TOPIC 7: ENT & AUDITORY DISORDERS (REPEATED 3/4)            -->
    <!-- ------------------------------------------------------------ -->`},{id:`grp-ent`,title:`ENT & Auditory Disorders (Hearing Loss, Otitis Media, Epistaxis)`,repeatCount:3,years:[`2019`,`2020`,`2025`],probability:90,priorityTier:`Tier 2 • Very High`,tierClass:`tier-high`,subItems:[{concept:`Hearing loss types, tuning fork tests (Rinne/Weber) & hearing aid rehabilitation`,years:`2019`},{concept:`Otitis media: ASOM vs CSOM, tympanoplasty & post-op nursing care`,years:`2020`},{concept:`Epistaxis: Kiesselbach's plexus, Trotter's method, anterior/posterior nasal packing`,years:`2025`}],questions:[{paperBadge:`MPMSU May 2019 (Main) — Q.1 [15 Marks]`,weight:`Full Long Essay | Target: 5 Handwritten Pages`,questionText:`a. Describe types of Hearing loss (3) | b. Discuss hearing aids and their types, parts, care and maintenance (6) | c. Discuss the role of nurse in speech therapy and auditory rehabilitation (6).`},{paperBadge:`MPMSU Feb 2020 (Main) — Q.5d [5 Marks]`,weight:`Short Note | Target: 2–3 Handwritten Pages`,questionText:`Short Note: Otitis Media - Types, clinical features & nursing management (5 Marks).`},{paperBadge:`MPMSU Feb 2025 (Supp) — Q.5b [5 Marks]`,weight:`Short Note | Target: 2–3 Handwritten Pages`,questionText:`Short Note: Epistaxis (Causes, First-aid management, and prevention) (5 Marks).`}],answerHtml:`<!-- QUESTION 1: MAY 2019 (MAIN) Q.1 [15 MARKS] -->
        <div class="q-block">
          <div class="q-header">
            <span class="q-badge">MPMSU May 2019 (Main) — Q.1 [15 Marks]</span>
            <span class="q-weight">Full Long Essay | Target: 5 Handwritten Pages</span>
          </div>
          <div class="q-text-prompt">
            <strong>Exam Question:</strong> a. Describe types of Hearing loss (3) | b. Discuss hearing aids and their types, parts, care and maintenance (6) | c. Discuss the role of nurse in speech therapy and auditory rehabilitation (6).
          </div>
          <div class="q-answer-content">
            <div class="ans-part">
              <div class="ans-part-title">Part (a): Types of Hearing Loss (3 Marks)</div>
              <div class="ans-part-body">
                <p>Hearing loss is classified into 3 major physiological types based on anatomical site:</p>
                <ul>
                  <li><strong>1. Conductive Hearing Loss:</strong> Sound waves are prevented from reaching the inner ear due to mechanical obstruction or pathology in the external ear canal or middle ear (e.g., impacted cerumen, otitis media with effusion, perforated tympanic membrane, otosclerosis).
                    <br><em>Tuning Fork Tests:</em> <strong>Rinne Test is Negative</strong> (Bone Conduction &gt; Air Conduction: BC &gt; AC); <strong>Weber Test lateralizes to the AFFECTED ear</strong>.</li>
                  <li><strong>2. Sensorineural Hearing Loss (SNHL / Nerve Deafness):</strong> Damage to the delicate hair cells of the organ of Corti in the cochlea (Cranial Nerve VIII) or the central auditory pathway (e.g., presbycusis in elderly, aminoglycoside ototoxicity [Gentamicin], chronic acoustic noise trauma, Meniere's disease).
                    <br><em>Tuning Fork Tests:</em> <strong>Rinne Test is Positive</strong> (AC &gt; BC, but both reduced); <strong>Weber Test lateralizes to the BETTER / UNAFFECTED ear</strong>.</li>
                  <li><strong>3. Mixed Hearing Loss:</strong> Coexistence of conductive and sensorineural pathologies in the same ear (e.g., chronic suppurative otitis media with secondary labyrinthitis).</li>
                </ul>
              </div>
            </div>

            <div class="ans-part">
              <div class="ans-part-title">Part (b): Hearing Aids: Types, Parts, Care and Maintenance (6 Marks)</div>
              <div class="ans-part-body">
                <p><strong>Definition:</strong> An electronic battery-powered electroacoustic device that captures acoustic sound waves, amplifies sound energy, and delivers amplified acoustic signals into the external auditory canal.</p>
                <p><strong>Basic Component Parts:</strong></p>
                <ul>
                  <li><em>Microphone:</em> Converts acoustic sound waves from the environment into electrical audio signals.</li>
                  <li><em>Amplifier:</em> Increases the electrical signal strength / amplitude.</li>
                  <li><em>Receiver (Speaker):</em> Converts the amplified electrical signal back into amplified sound waves directed into the ear.</li>
                  <li><em>Power Source:</em> Zinc-air miniature button battery or rechargeable lithium-ion battery.</li>
                  <li><em>Earmold:</em> Custom-fitted acrylic or silicone mold coupling the receiver to the patient's ear canal.</li>
                </ul>
                <p><strong>Major Types of Hearing Aids:</strong></p>
                <ul>
                  <li><em>Behind-the-Ear (BTE):</em> Electronic components housed in a plastic case behind the pinna; connected via tubing to an earmold. Most versatile; suitable for mild to profound hearing loss across all ages.</li>
                  <li><em>In-the-Ear (ITE):</em> Custom-molded to fit the concha and outer ear canal; easily handled by elderly with arthritis.</li>
                  <li><em>In-the-Canal (ITC) & Completely-in-Canal (CIC):</em> Small, cosmetically discreet devices fitting deeply into ear canal; suitable for mild-to-moderate loss.</li>
                  <li><em>Bone-Anchored Hearing Aid (BAHA):</em> Surgically implanted titanium screw in temporal bone that transmits sound vibrations directly through skull bone to the cochlea, bypassing external/middle ear pathology.</li>
                </ul>
                <p><strong>Nursing Care & Maintenance Guidelines:</strong></p>
                <div class="callout">
                  &bull; <strong>Moisture Protection:</strong> Keep the hearing aid dry. Remove before bathing, showering, swimming, or using hair spray.<br>
                  &bull; <strong>Cleaning:</strong> Clean the earmold daily using a soft dry cloth or specialized small wax brush. Never use alcohol, solvents, or hot water on electronic components.<br>
                  &bull; <strong>Battery Care:</strong> Open the battery compartment door at night when not in use to preserve battery life and allow internal moisture to evaporate.<br>
                  &bull; <strong>Managing Whistling / Acoustic Feedback:</strong> If the aid produces a high-pitched squeal, it indicates sound leakage from the receiver back into the microphone. Check for improper earmold insertion, cracks in tubing, or cerumen impaction in ear canal.
                </div>
              </div>
            </div>

            <div class="ans-part">
              <div class="ans-part-title">Part (c): Role of Nurse in Speech Therapy & Auditory Rehabilitation (6 Marks)</div>
              <div class="ans-part-body">
                <p>Auditory rehabilitation is an interdisciplinary process aimed at restoring communication efficiency and psychosocial integration for hearing-impaired individuals:</p>
                <ul>
                  <li><strong>1. Effective Communication Strategies (Nurse-Patient Interaction):</strong>
                    <ul>
                      <li>Face the patient directly at eye level in a well-lit room (enables lip-reading / speech-reading).</li>
                      <li>Gain the patient's visual attention before speaking (gentle tap on shoulder or hand wave).</li>
                      <li>Speak clearly, distinctly, and at a moderate normal pace. <em>DO NOT SHOUT</em> (shouting distorts sound waves, raises pitch, and overstimulates recruitment in sensorineural loss).</li>
                      <li>Keep hands and objects away from your mouth while speaking.</li>
                      <li>Rephrase sentences rather than simply repeating the same words if misunderstood.</li>
                    </ul>
                  </li>
                  <li><strong>2. Facilitation of Speech Therapy & Auditory Training:</strong>
                    <ul>
                      <li>Collaborate with speech-language pathologists (SLPs) to implement speech-reading (lip-reading), cued speech, and tactile vibration techniques.</li>
                      <li>Assist patient in distinguishing phonetic consonants (e.g., s, sh, f, th) which are high-frequency sounds commonly lost in presbycusis.</li>
                    </ul>
                  </li>
                  <li><strong>3. Environmental Adaptation:</strong>
                    <ul>
                      <li>Install visual alerting devices (flashing doorbells, smoke detectors with strobe lights, vibrating bed alarm clocks).</li>
                      <li>Encourage closed-captioning on television and assistive telecommunication listening systems (FM loop systems).</li>
                    </ul>
                  </li>
                  <li><strong>4. Psychosocial Support:</strong>
                    <ul>
                      <li>Screen for social withdrawal, paranoia, and depression caused by communication isolation; connect patient and family to hearing loss support networks.</li>
                    </ul>
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </div>

        <!-- QUESTION 2: FEB 2020 (MAIN) Q.5d [5 MARKS] -->
        <div class="q-block">
          <div class="q-header">
            <span class="q-badge">MPMSU Feb 2020 (Main) — Q.5d [5 Marks]</span>
            <span class="q-weight">Short Note | Target: 2–3 Handwritten Pages</span>
          </div>
          <div class="q-text-prompt">
            <strong>Exam Question:</strong> Short Note: Otitis Media - Types, clinical features & nursing management (5 Marks).
          </div>
          <div class="q-answer-content">
            <div class="ans-part">
              <div class="ans-part-title">Comprehensive Clinical Answer: Otitis Media</div>
              <div class="ans-part-body">
                <p><strong>Definition:</strong> Inflammation or infection of the mucoperiosteal lining of the middle ear cleft (tympanic cavity, Eustachian tube, and mastoid air cells), predominantly secondary to Eustachian tube dysfunction following upper respiratory tract infections.</p>

                <p><strong>1. Clinical Types:</strong></p>
                <ul>
                  <li><strong>Acute Suppurative Otitis Media (ASOM):</strong> Acute bacterial infection (<em>S. pneumoniae, H. influenzae, Moraxella catarrhalis</em>) characterized by rapid onset of purulent fluid in the middle ear.</li>
                  <li><strong>Otitis Media with Effusion (OME / Serous Otitis Media / "Glue Ear"):</strong> Accumulation of non-purulent, sterile fluid in middle ear without acute inflammatory signs; causes conductive hearing loss in school children.</li>
                  <li><strong>Chronic Suppurative Otitis Media (CSOM):</strong> Chronic persistent or recurrent discharge (otorrhea) through a permanent tympanic membrane perforation lasting &gt;6–12 weeks. Subtypes:
                    <ul>
                      <li><em>Tubotympanic (Safe / Benign):</em> Central perforation; profuse, mucoid, non-foul smelling discharge; low intracranial complication risk.</li>
                      <li><em>Atticoantral (Unsafe / Dangerous):</em> Marginal/attic perforation associated with <strong>Cholesteatoma</strong> (destructive keratinizing squamous epithelium causing bone erosion); foul-smelling, scanty discharge; high risk of meningitis, brain abscess, and facial nerve paralysis.</li>
                    </ul>
                  </li>
                </ul>

                <p><strong>2. Clinical Features of ASOM:</strong></p>
                <ul>
                  <li><em>Otalgia:</em> Throbbing, severe earache that intensifies with swallowing. Sudden relief of pain accompanied by bloody purulent otorrhea indicates spontaneous rupture of the tympanic membrane.</li>
                  <li><em>Otoscopic Findings:</em> Hyperemic, fiery red, bulging tympanic membrane with loss of landmarks and loss of light reflex. "Doughnut" sign or yellowish purulent fluid behind tense drum.</li>
                  <li><em>Systemic Signs:</em> High fever, irritability, conductive hearing loss.</li>
                </ul>

                <p><strong>3. Medical & Surgical Management:</strong></p>
                <ul>
                  <li><em>Antibiotics:</em> Oral Amoxicillin-Clavulanate (Augmentin) 1st line for 7–10 days.</li>
                  <li><em>Decongestants:</em> Xylometazoline nasal drops to open Eustachian tube.</li>
                  <li><em>Myringotomy (Tympanocentesis):</em> Surgical incision in the posteroinferior quadrant of tympanic membrane to release pus and insert ventilation grommet tube.</li>
                  <li><em>Tympanoplasty / Mastoidectomy:</em> Surgical eradication of cholesteatoma and grafting (temporalis fascia graft) for CSOM.</li>
                </ul>

                <p><strong>4. Post-Operative Nursing Care After Middle Ear Surgery:</strong></p>
                <div class="callout">
                  &bull; <strong>Positioning:</strong> Position on the <em>unoperated ear</em> to prevent graft displacement.<br>
                  &bull; <strong>Prevent Middle Ear Pressure Changes:</strong> Instruct patient to cough or sneeze with the <strong>mouth wide open</strong>; avoid nose-blowing, straining, or air travel.<br>
                  &bull; <strong>Water Protection:</strong> Keep ear strictly dry for 6 weeks; place cotton ball soaked in petroleum jelly in outer ear canal during bathing.<br>
                  &bull; <strong>Facial Nerve Monitoring:</strong> Assess Cranial Nerve VII (ask patient to smile, raise eyebrows, whistle, puff cheeks) to detect operative facial nerve injury.
                </div>
              </div>
            </div>
          </div>
        </div>

        <!-- QUESTION 3: FEB 2025 (SUPP) Q.5b [5 MARKS] -->
        <div class="q-block">
          <div class="q-header">
            <span class="q-badge">MPMSU Feb 2025 (Supp) — Q.5b [5 Marks]</span>
            <span class="q-weight">Short Note | Target: 2–3 Handwritten Pages</span>
          </div>
          <div class="q-text-prompt">
            <strong>Exam Question:</strong> Short Note: Epistaxis (Causes, First-aid management, and prevention) (5 Marks).
          </div>
          <div class="q-answer-content">
            <div class="ans-part">
              <div class="ans-part-title">Comprehensive Clinical Answer: Epistaxis</div>
              <div class="ans-part-body">
                <p><strong>Definition:</strong> Epistaxis is hemorrhage from the nasal cavity or nasopharynx. Anatomically categorized into <strong>Anterior Epistaxis (90%)</strong>, predominantly arising from <em>Kiesselbach's Plexus in Little's Area</em> on the anterior nasal septum (anastomosis of 5 arteries), and <strong>Posterior Epistaxis (10%)</strong> arising from the sphenopalatine artery (Woodruff's plexus), common in elderly hypertensives.</p>

                <p><strong>1. Etiological Causes:</strong></p>
                <ul>
                  <li><strong>Local Causes:</strong> Digital trauma (nose picking - most common in children), blunt facial trauma, foreign bodies, dry winter climates, acute rhinitis/sinusitis, deviated nasal septum (DNS), nasal polyps, and juvenile nasopharyngeal angiofibroma.</li>
                  <li><strong>Systemic Causes:</strong> Systemic arterial hypertension, bleeding diatheses (hemophilia, thrombocytopenia, leukemia), anticoagulant therapy (Warfarin, Heparin, Aspirin), liver failure (coagulopathy), and Vitamin K deficiency.</li>
                </ul>

                <p><strong>2. Immediate First-Aid Nursing Management (Trotter's Method):</strong></p>
                <div class="callout">
                  <strong>TROTTER'S PROTOCOL:</strong>
                  <br>1. <strong>Positioning:</strong> Seat the patient upright and <strong>lean forward slightly</strong> over a basin.
                  <br><em>*FATAL MISTAKE TO AVOID:*</em> NEVER tilt the head backward! Tilting backward causes blood to trickle down the posterior pharynx, inducing nausea, vomiting, and pulmonary aspiration.
                  <br>2. <strong>Direct Digital Compression:</strong> Instruct patient to pinch the soft cartilaginous lower portion of the nose firmly between the thumb and forefinger continuously for <strong>10 to 15 minutes</strong> while breathing through the mouth.
                  <br>3. <strong>Cold Application:</strong> Apply ice packs over the bridge of the nose and nape of the neck to induce reflexive vasoconstriction.
                  <br>4. Instruct patient to spit out any blood that collects in the throat rather than swallowing it.
                </div>

                <p><strong>3. Medical & Invasive Interventions:</strong></p>
                <ul>
                  <li><em>Topical Vasoconstrictor & Decongestant:</em> Cotton pledgets soaked in 4% Lidocaine + 1:1000 Epinephrine or Oxymetazoline inserted into nasal cavity.</li>
                  <li><em>Chemical Cautery:</em> Silver Nitrate (75%) stick applied directly to the bleeding bleeding point for 2–3 seconds after local anesthesia.</li>
                  <li><em>Anterior Nasal Packing:</em> Ribbon gauze impregnated with BIPP (Bismuth Iodoform Paraffin Paste) or expandable Merocel sponge left in place for 48–72 hours under antibiotic coverage.</li>
                  <li><em>Posterior Nasal Packing / Foley Catheter:</em> 12–14 Fr Foley catheter inserted through nose into nasopharynx, balloon inflated with 8–10 mL sterile water and pulled anteriorly to tamponade Woodruff's plexus. Requires ICU admission and pulse oximetry monitoring (triggers nasopulmonary reflex causing hypoxia/hypoventilation).</li>
                </ul>

                <p><strong>4. Preventive Patient Education:</strong></p>
                <ul>
                  <li>Apply water-soluble lubricating ointment or petroleum jelly to the anterior nares twice daily.</li>
                  <li>Use a bedside cool-mist room humidifier; avoid forceful nose blowing or picking.</li>
                  <li>Sneeze with mouth open to reduce intranasal pressure; maintain strict blood pressure control.</li>
                </ul>
              </div>
            </div>
          </div>
        </div>

      </div>
    </div>
  </div>

  <!-- ============================================================== -->
  <!-- 2. MENTAL HEALTH NURSING (MHN)                                 -->
  <!-- ============================================================== -->`}]},mhn:{id:`mhn`,name:`Mental Health Nursing`,shortName:`Mental Health`,badge:`Psychiatric Nursing`,code:`NTRUHS / MPMSU 3rd Year`,desc:`Schizophrenia, Antipsychotics, ECT, OCD, Crisis Intervention & MHCA 2017`,icon:`heart`,color:`#A78BFA`,papers:[{year:`2025`,session:`Supplementary Examination`,title:`Mental Health Nursing Feb 2025 (Supp) Question Paper`,file:`/pyqs/mhn/mhn-2025-supp.pdf`,date:`February 2025`,totalMarks:75,duration:`3 Hours`,badge:`Latest Exam Paper`},{year:`2022`,session:`Main & Supplementary`,title:`Mental Health Nursing July 2022 (Main) Question Paper`,file:`/pyqs/mhn/mhn-2022-main.pdf`,date:`July 2022`,totalMarks:75,duration:`3 Hours`,badge:`Core Annual`},{year:`2020`,session:`Main Examination`,title:`Mental Health Nursing Feb 2020 (Main) Question Paper`,file:`/pyqs/mhn/mhn-2020-main.pdf`,date:`February 2020`,totalMarks:75,duration:`3 Hours`,badge:`Core Annual`},{year:`2019`,session:`Main Examination`,title:`Mental Health Nursing May 2019 (Main) Question Paper`,file:`/pyqs/mhn/mhn-2019-main.pdf`,date:`May 2019`,totalMarks:75,duration:`3 Hours`,badge:`Benchmark Paper`}],topics:[{id:`grp-schizo`,title:`Schizophrenia & Comprehensive Nursing Care Plan`,repeatCount:3,years:[`2019`,`2020`,`2022`],probability:90,priorityTier:`Tier 2 • Very High`,tierClass:`tier-high`,subItems:[{concept:`Bleuler's 4 A's, Schneider's First Rank Symptoms & positive vs negative dichotomy`,years:`2019, 2020, 2022`},{concept:`ICD-10 clinical types: Paranoid, Catatonic, Hebephrenic/Disorganized`,years:`2020, 2022`},{concept:`Therapeutic communication & Nursing Care Plan for hallucinations and delusions`,years:`2019, 2020, 2022`}],questions:[{paperBadge:`MPMSU Feb 2020 (Main) — Q.4 [17 Marks]`,weight:`Maximum Weight Long Essay | Target: 5 Handwritten Pages`,questionText:`a. Define Schizophrenia (2) | b. Write types of Schizophrenia in detail (7) | c. Draw nursing care plan of patient with Schizophrenia (8).`},{paperBadge:`MPMSU May 2019 (Main) — Q.1 [15 Marks]`,weight:`Case Scenario Essay | Target: 5 Handwritten Pages`,questionText:`Mr. X is admitted with auditory hallucinations and paranoid delusion: a. What is possible diagnosis (2) | b. Write down etiological factors (5) | c. Make a nursing care plan for Mr. X (8).`}],answerHtml:`<!-- ======================================================== -->
        <!-- CATEGORIZED CLINICAL CONCEPTS & MEDICAL EXPLANATIONS     -->
        <!-- ======================================================== -->
        <div class="concept-category-title">Categorized Clinical Guide & Psychopathology Breakdown</div>

        <!-- 1. DOPAMINERGIC PATHWAYS & NEUROBIOLOGY -->
        <div class="concept-card">
          <div class="concept-title">1. The Four Dopaminergic Pathways in Schizophrenia & Psychopharmacology</div>
          <div class="concept-body">
            <p><strong>The Dopamine Hypothesis of Schizophrenia:</strong> Originating from the observation that dopamine agonists trigger psychosis and D2 antagonists alleviate hallucinations, this neurobiological model establishes that schizophrenia arises from circuit-specific dopaminergic dysregulation:</p>
            
            <img src="/pyqs/images/dopamine_pathways.jpg" class="med-img" alt="Four Dopamine Pathways in Human Brain Sagittal Section">
            
            <div class="img-notes">
              <strong>Neurobiological Pathways & Clinical Implications in Mental Health Nursing:</strong>
              <table class="clinical-table" style="margin-top: 8px;">
                <thead>
                  <tr><th>Dopamine Pathway</th><th>Anatomical Projection</th><th>Pathophysiology in Schizophrenia</th><th>Antipsychotic Drug Impact (D2 Blockade)</th></tr>
                </thead>
                <tbody>
                  <tr>
                    <td><strong>1. Mesolimbic Pathway</strong></td>
                    <td>VTA &rarr; Nucleus Accumbens & Limbic System</td>
                    <td><strong>HYPERACTIVITY:</strong> Mediates <strong>POSITIVE SYMPTOMS:</strong> Auditory hallucinations, persecutory delusions, disorganized speech.</td>
                    <td><strong>Therapeutic Target:</strong> D2 receptor antagonism in this pathway successfully eliminates positive psychotic symptoms.</td>
                  </tr>
                  <tr>
                    <td><strong>2. Mesocortical Pathway</strong></td>
                    <td>VTA &rarr; Prefrontal Cortex (DLPFC / VMPFC)</td>
                    <td><strong>HYPOACTIVITY:</strong> Mediates <strong>NEGATIVE & COGNITIVE SYMPTOMS:</strong> Avolition, flat affect, alogia, anhedonia, social withdrawal.</td>
                    <td>First-generation antipsychotics worsen negative symptoms; Second-generation agents (5-HT2A/D2 antagonists) increase prefrontal dopamine.</td>
                  </tr>
                  <tr>
                    <td><strong>3. Nigrostriatal Pathway</strong></td>
                    <td>Substantia Nigra &rarr; Striatum (Caudate / Putamen)</td>
                    <td>Intact in unmedicated schizophrenia; coordinates extrapyramidal motor movement.</td>
                    <td><strong>ADVERSE EFFECT SITE:</strong> D2 blockade (&gt;75–80%) produces <strong>Extrapyramidal Symptoms (EPS):</strong> Acute dystonia, pseudoparkinsonism, akathisia, tardive dyskinesia. Managed with Anticholinergics (Promethazine).</td>
                  </tr>
                  <tr>
                    <td><strong>4. Tuberoinfundibular Pathway</strong></td>
                    <td>Hypothalamus &rarr; Anterior Pituitary</td>
                    <td>Dopamine normally functions as Prolactin-Inhibiting Factor (PIF).</td>
                    <td><strong>ADVERSE EFFECT SITE:</strong> D2 blockade disinhibits prolactin release &rarr; <strong>Hyperprolactinemia:</strong> Galactorrhea, gynecomastia, amenorrhea.</td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>
        </div>

        <!-- 2. DIAGNOSTIC CRITERIA & BLEULER'S 4 A'S -->
        <div class="concept-card">
          <div class="concept-title">2. Diagnostic Criteria: Bleuler's 4 A's & Schneider's First-Rank Symptoms</div>
          <div class="concept-body">
            <p><strong>Bleuler's Fundamental 4 A's:</strong></p>
            <ul>
              <li><strong>Affective Blunting / Incongruity:</strong> Inappropriate, flat, or severely restricted emotional expression.</li>
              <li><strong>Associative Looseness:</strong> Illogical, disjointed thought flow where ideas derail without logical connection.</li>
              <li><strong>Autism:</strong> Detachment from external reality into an idiosyncratic internal fantasy world.</li>
              <li><strong>Ambivalence:</strong> Simultaneous coexistence of two contradictory feelings or impulses toward the same object/person.</li>
            </ul>

            <p style="margin-top: 10px;"><strong>Schneider's First-Rank Symptoms (Pathognomonic of Schizophrenia):</strong></p>
            <ul>
              <li><strong>Auditory Hallucinations:</strong> Voices heard commenting on one's actions, voices arguing in the third person, or thought echo (gedankenlautwerden).</li>
              <li><strong>Thought Alienation:</strong> Thought insertion, thought withdrawal, and thought broadcasting.</li>
              <li><strong>Delusional Perceptions & Passivity Experiences:</strong> Delusional passivity of somatic sensations, affect, or motor impulses (feeling controlled by an external force).</li>
            </ul>
          </div>
        </div>

        <!-- ======================================================== -->
        <!-- SECTION B: PAST UNIVERSITY EXAM QUESTIONS & ANSWERS      -->
        <!-- ======================================================== -->
        <div class="section-divider-title">Exact University Exam Questions & 2–5 Page Model Answers</div>

        <!-- QUESTION 1: FEB 2020 (MAIN) Q.4 [17 MARKS] -->
        <div class="q-block">
          <div class="q-header">
            <span class="q-badge">MPMSU Feb 2020 (Main) — Q.4 [17 Marks]</span>
            <span class="q-weight">Maximum Weight Long Essay | Target: 5 Handwritten Pages</span>
          </div>
          <div class="q-text-prompt">
            <strong>Exam Question:</strong> a. Define Schizophrenia (2) | b. Write types of Schizophrenia in detail (7) | c. Draw nursing care plan of patient with Schizophrenia (8).
          </div>
          <div class="q-answer-content">
            <div class="ans-part">
              <div class="ans-part-title">Part (a): Definition of Schizophrenia & Fundamental Diagnostic Criteria (2 Marks)</div>
              <div class="ans-part-body">
                <p><strong>Schizophrenia (Eugen Bleuler / ICD-11 / DSM-5):</strong> A chronic, severe, debilitating psychiatric disorder characterized by fundamental distortions in thinking, perception, reality testing, affect, volition, and behavioral integration, persisting for at least 6 months with at least 1 month of active-phase symptoms, leading to profound occupational, social, and interpersonal deterioration.</p>
                <div class="callout">
                  <strong>Bleuler's 4 A's (Primary Pathognomonic Features):</strong>
                  <br>1. <strong>Affective Blunting / Incongruity:</strong> Inappropriate, flat, or blunted emotional expression.
                  <br>2. <strong>Associative Looseness:</strong> Illogical, disjointed thought flow where ideas jump without logical connection (derailment, word salad).
                  <br>3. <strong>Autism:</strong> Detachment from objective reality into an idiosyncratic, internal fantasy world.
                  <br>4. <strong>Ambivalence:</strong> Simultaneous coexistence of two contradictory feelings or impulses toward the same object/person.
                </div>
              </div>
            </div>

            <div class="ans-part">
              <div class="ans-part-title">Part (b): Clinical Types of Schizophrenia in Detail (ICD-10) (7 Marks)</div>
              <div class="ans-part-body">
                <table class="clinical-table">
                  <thead>
                    <tr><th>Subtype</th><th>Diagnostic Criteria & Hallmarks</th><th>Clinical Features & Nursing Implications</th></tr>
                  </thead>
                  <tbody>
                    <tr>
                      <td><strong>1. Paranoid Schizophrenia (F20.0 - Most Common)</strong></td>
                      <td>Dominated by stable, persecutory or grandiose delusions and auditory hallucinations, with relative preservation of affect and cognitive faculties.</td>
                      <td>
                        &bull; <em>Delusions of Persecution:</em> Believes neighbors/police/RAW are poisoning food, spying, or conspiring harm.<br>
                        &bull; <em>Delusions of Reference:</em> Believes TV broadcasts or radio signals contain secret codes about him.<br>
                        &bull; <em>Auditory Hallucinations:</em> Voices commenting on actions (third-person) or commanding actions.<br>
                        &bull; <em>Risk:</em> High potential for violence (defensive hostility) or suicide; best prognosis among subtypes.
                      </td>
                    </tr>
                    <tr>
                      <td><strong>2. Catatonic Schizophrenia (F20.2)</strong></td>
                      <td>Prominent motor disturbances alternating between extreme psychomotor inhibition (stupor) and purposeless agitation (excitement).</td>
                      <td>
                        &bull; <em>Catatonic Stupor:</em> Mutism, akinesia, negativism (resisting all commands), <strong>Waxy Flexibility (Catalepsy)</strong> where limbs remain in awkward positions placed by examiner for hours.<br>
                        &bull; <em>Posturing & Automatic Obedience:</em> Bizarre rigid poses; echolalia (mimicking words); echopraxia (mimicking movements).<br>
                        &bull; <em>Catatonic Excitement:</em> Uncontrolled frenzy, continuous aimless motor activity risking cardiac exhaustion, dehydration, and self-injury.
                      </td>
                    </tr>
                    <tr>
                      <td><strong>3. Hebephrenic / Disorganized Schizophrenia (F20.1)</strong></td>
                      <td>Early insidious onset (puberty / 15–25 yrs); marked affective flattening, silly inappropriate giggling, and severe thought fragmentation.</td>
                      <td>
                        &bull; Incoherent speech (word salad, neologisms); bizarre hypochondriacal delusions.<br>
                        &bull; Regressed, childlike, uninhibited behavior (grimacing, public masturbation, mirror gazing).<br>
                        &bull; Poorest prognosis; rapid progression to negative symptoms.
                      </td>
                    </tr>
                    <tr>
                      <td><strong>4. Undifferentiated Schizophrenia (F20.3)</strong></td>
                      <td>Meets diagnostic criteria for schizophrenia but exhibits mixed symptoms without fitting neatly into paranoid, catatonic, or hebephrenic types.</td>
                      <td>Prominent delusions, hallucinations, and incoherence of mixed presentation.</td>
                    </tr>
                    <tr>
                      <td><strong>5. Residual Schizophrenia (F20.5)</strong></td>
                      <td>Chronic stage following at least one acute psychotic episode where positive symptoms have faded, leaving persistent debilitating negative symptoms.</td>
                      <td>Severe avolition, psychomotor slowing, emotional blunting, social withdrawal, poor self-care, and poverty of speech (alogia).</td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>

            <div class="ans-part">
              <div class="ans-part-title">Part (c): Comprehensive Nursing Care Plan for Patient with Schizophrenia (8 Marks)</div>
              <div class="ans-part-body">
                <table class="clinical-table">
                  <thead>
                    <tr><th>Nursing Diagnosis</th><th>Goal</th><th>Interventions & Therapeutic Rationales</th><th>Evaluation</th></tr>
                  </thead>
                  <tbody>
                    <tr>
                      <td><strong>Disturbed Sensory Perception (Auditory Hallucinations)</strong> r/t neurochemical imbalance (dopamine hyperactivity in mesolimbic tract).</td>
                      <td>Recognize hallucinations as unreal; maintain control; refrain from responding to command voices.</td>
                      <td>
                        &bull; <em>Direct Assessment:</em> Ask directly: "Are you hearing voices right now? What are they saying to you?" Assess for command hallucinations to harm self or others.<br>
                        &bull; <em>Therapeutic Reality-Based Communication:</em> Validate feelings but do NOT validate the hallucination: <strong>"I understand that the voices seem very real to you, but I do not hear any voices speaking."</strong><br>
                        &bull; <em>Voice-Dismissal Techniques:</em> Teach patient to firmly tell the voices: "Go away, I am busy!" or use headphones with music.<br>
                        &bull; Administer prescribed atypical antipsychotic (Olanzapine 10 mg or Risperidone 4 mg).
                      </td>
                      <td>Patient identifies auditory hallucinations; states voices are reduced in frequency; does not act on commands.</td>
                    </tr>
                    <tr>
                      <td><strong>Disturbed Thought Process (Persecutory Delusions)</strong> r/t neurochemical dysfunction and cognitive impairment.</td>
                      <td>Experience reduced suspiciousness; feel safe in the unit environment.</td>
                      <td>
                        &bull; <em>Rule on Delusions:</em> NEVER argue, challenge, or attempt to logically debate a delusion (reinforces defensiveness). Do NOT agree with or reinforce the delusion.<br>
                        &bull; Focus on the underlying emotion: "It must be terrifying to feel like people are trying to poison you. You are safe here."<br>
                        &bull; Food Suspicion Management: Serve factory-sealed foods, canned juices, or let patient choose food from a common buffet table.<br>
                        &bull; Avoid whispering, laughing, or secretive actions in front of paranoid patient.
                      </td>
                      <td>Patient eats unit meals without fear of poison; engages in 1-on-1 therapeutic activities with nurse.</td>
                    </tr>
                    <tr>
                      <td><strong>Risk for Other-Directed Violence</strong> r/t persecutory delusions, perceived threat, and command hallucinations.</td>
                      <td>Maintain impulse control; remain free from violent outbursts during hospitalization.</td>
                      <td>
                        &bull; Maintain a low-stimulus environment (dim lighting, minimal noise, avoid crowding).<br>
                        &bull; Observe for escalating signs of agitation: Clenched fists, pacing, intense glaring, verbal threats.<br>
                        &bull; Maintain safe physical distance (arm's length) and keep an open exit pathway.<br>
                        &bull; If agitation escalates: De-escalate verbally with a calm, firm, monotone voice. Administer PRN chemical restraint (Haloperidol 5 mg + Lorazepam 2 mg IM) as ordered.
                      </td>
                      <td>Zero incidents of physical aggression or injury to staff/peers.</td>
                    </tr>
                    <tr>
                      <td><strong>Self-Care Deficit (Hygiene, Dressing, Grooming)</strong> r/t negative symptoms (avolition, apathy) and cognitive disorganization.</td>
                      <td>Perform basic activities of daily living (bathing, clean clothing) with minimal prompting.</td>
                      <td>
                        &bull; Establish a structured daily routine schedule.<br>
                        &bull; Break complex hygiene tasks into small, concrete, step-by-step instructions ("Pick up the soap. Now wash your hands.").<br>
                        &bull; Provide positive verbal reinforcement for every completed self-care task; avoid doing tasks the patient can perform independently.
                      </td>
                      <td>Patient showers daily, wears clean clothes, and brushes teeth with minimal verbal cues.</td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </div>

        <!-- QUESTION 2: MAY 2019 (MAIN) Q.1 [15 MARKS] -->
        <div class="q-block">
          <div class="q-header">
            <span class="q-badge">MPMSU May 2019 (Main) — Q.1 [15 Marks]</span>
            <span class="q-weight">Case Scenario Essay | Target: 5 Handwritten Pages</span>
          </div>
          <div class="q-text-prompt">
            <strong>Exam Question:</strong> Mr. X is admitted with auditory hallucinations and paranoid delusion: a. What is possible diagnosis (2) | b. Write down etiological factors (5) | c. Make a nursing care plan for Mr. X (8).
          </div>
          <div class="q-answer-content">
            <div class="ans-part">
              <div class="ans-part-title">Part (a): Most Probable Diagnosis (2 Marks)</div>
              <div class="ans-part-body">
                <p><strong>Primary Diagnosis:</strong> <strong>Paranoid Schizophrenia (ICD-10 Code: F20.0)</strong>.</p>
                <p><em>Clinical Justification:</em> Dominated by persecutory/paranoid delusions and auditory hallucinations, which are classic Schneiderian First Rank Symptoms and the hallmark criteria of the paranoid subtype of schizophrenia.</p>
              </div>
            </div>

            <div class="ans-part">
              <div class="ans-part-title">Part (b): Etiological Factors of Schizophrenia (Biopsychosocial Model) (5 Marks)</div>
              <div class="ans-part-body">
                <ul>
                  <li><strong>1. Genetic Factors:</strong>
                    <ul>
                      <li>General population lifetime risk = 1%.</li>
                      <li>First-degree relative (parent or sibling) = 10%.</li>
                      <li>Dizygotic (fraternal) twins = 12–15%.</li>
                      <li>Monozygotic (identical) twins = 47–50% concordance.</li>
                      <li>Both parents schizophrenic = 40–46% child risk. Polygenic transmission with multiple risk alleles (e.g., DISC1, Neuregulin-1).</li>
                    </ul>
                  </li>
                  <li><strong>2. Neurochemical Dysregulation (Dopamine Hypothesis):</strong>
                    <ul>
                      <li><em>Mesolimbic Tract Hyperactivity:</em> Excessive dopamine transmission at D2 receptors causes positive symptoms (hallucinations, delusions).</li>
                      <li><em>Mesocortical Tract Hypoactivity:</em> Dopamine deficit in the prefrontal cortex causes negative symptoms (apathy, avolition) and cognitive deficits.</li>
                      <li><em>Serotonin & Glutamate:</em> Serotonin (5-HT2A) hyperactivity and NMDA receptor hypofunction also play key roles.</li>
                    </ul>
                  </li>
                  <li><strong>3. Neurostructural & Neurodevelopmental Abnormalities:</strong>
                    <ul>
                      <li>CT/MRI reveals ventricular enlargement (lateral and third ventricles) and cortical/prefrontal gray matter volume loss.</li>
                      <li>Prenatal insults: Maternal viral infections during 2nd trimester (Influenza epidemics), maternal malnutrition (folate deficiency), and obstetric birth complications (perinatal hypoxia).</li>
                    </ul>
                  </li>
                  <li><strong>4. Psychosocial & Environmental Triggers (Stress-Diathesis Model):</strong>
                    <ul>
                      <li><em>High Expressed Emotion (EE):</em> Families with high critical comments, hostility, and emotional over-involvement show a 3- to 4-fold increase in relapse rates.</li>
                      <li>Urban upbringing, severe childhood trauma, and cannabis abuse during adolescence.</li>
                    </ul>
                  </li>
                </ul>
              </div>
            </div>

            <div class="ans-part">
              <div class="ans-part-title">Part (c): Targeted Nursing Care Plan for Mr. X (8 Marks)</div>
              <div class="ans-part-body">
                <table class="clinical-table">
                  <thead>
                    <tr><th>Nursing Diagnosis</th><th>Goal</th><th>Interventions & Therapeutic Rationales</th><th>Evaluation</th></tr>
                  </thead>
                  <tbody>
                    <tr>
                      <td><strong>Disturbed Sensory Perception (Auditory Hallucinations)</strong> r/t neurochemical hyperactivity in temporal auditory cortex.</td>
                      <td>Mr. X will verbalize when voices occur and use reality-based coping to ignore them within 7 days.</td>
                      <td>
                        &bull; Assess frequency, triggers, and content of voices. Specifically ask: "Are the voices telling you to do anything harmful?"<br>
                        &bull; Present reality calmly without arguing: "Mr. X, I know the voice sounds loud and clear to you, but I do not hear anyone speaking."<br>
                        &bull; Involve in structured activities (art therapy, table tennis) to divert auditory attention.<br>
                        &bull; Administer prescribed atypical antipsychotic (Risperidone 4 mg PO at bedtime).
                      </td>
                      <td>Mr. X reports voices are softer and no longer commands him; engages in ward activities.</td>
                    </tr>
                    <tr>
                      <td><strong>Defensive Coping & Paranoia</strong> r/t feelings of insecurity and persecutory delusions.</td>
                      <td>Mr. X will interact with assigned primary nurse without signs of hostility or fear.</td>
                      <td>
                        &bull; Assign the same primary nurse daily to build consistency and trust.<br>
                        &bull; Be honest, keep all promises, and avoid overly friendly or patronizing behaviors (viewed with suspicion).<br>
                        &bull; Allow Mr. X to observe medications being opened from factory unit-dose packaging.<br>
                        &bull; Give Mr. X choices where possible (e.g., "Do you prefer your bath before breakfast or after?").
                      </td>
                      <td>Mr. X accepts medications without resistance; expresses feelings of safety on the unit.</td>
                    </tr>
                    <tr>
                      <td><strong>Impaired Social Interaction</strong> r/t mistrust of others and delusional ideation.</td>
                      <td>Participate in 1-on-1 interaction with nurse for 20 minutes daily without withdrawing.</td>
                      <td>
                        &bull; Begin with brief, frequent, non-threatening 1-on-1 visits.<br>
                        &bull; Gradually introduce to small, low-stress group settings (2–3 patients).<br>
                        &bull; Provide social skills training (eye contact, active listening, conversational turn-taking).
                      </td>
                      <td>Mr. X sits in the dayroom and converses with nurse; joins one small recreational group.</td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </div>

      </div>
    </div>

    <!-- ------------------------------------------------------------ -->
    <!-- TOPIC 2: ANTIPSYCHOTICS & EXTRAPYRAMIDAL SYMPTOMS (3/4)      -->
    <!-- ------------------------------------------------------------ -->`},{id:`grp-antipsych`,title:`Antipsychotics & Extrapyramidal Symptoms (EPS)`,repeatCount:3,years:[`2019`,`2020`,`2022`],probability:90,priorityTier:`Tier 2 • Very High`,tierClass:`tier-high`,subItems:[{concept:`Classification: Typical (FGA) vs Atypical (SGA), mechanisms & receptor binding`,years:`2022`},{concept:`Extrapyramidal Symptoms (EPS): Acute dystonia, akathisia, parkinsonism, tardive dyskinesia`,years:`2020, 2022`},{concept:`Neuroleptic Malignant Syndrome (NMS) vs Serotonin Syndrome & nursing protocols`,years:`2019, 2022`}],questions:[{paperBadge:`MPMSU July 2022 (Main & Supp) — Q.2 [10 Marks]`,weight:`Essay Question | Target: 4 Handwritten Pages`,questionText:`a. Classify Antipsychotic drugs (Typical vs Atypical) (3) | b. Explain Extrapyramidal Symptoms (EPS) and their management (4) | c. Role of nurse in administration of Psychotropic drugs (3).`}],answerHtml:`<!-- QUESTION 1: JULY 2022 (MAIN) Q.2 [10 MARKS] -->
        <div class="q-block">
          <div class="q-header">
            <span class="q-badge">MPMSU July 2022 (Main & Supp) — Q.2 [10 Marks]</span>
            <span class="q-weight">Essay Question | Target: 4 Handwritten Pages</span>
          </div>
          <div class="q-text-prompt">
            <strong>Exam Question:</strong> a. Classify Antipsychotic drugs (Typical vs Atypical) (3) | b. Explain Extrapyramidal Symptoms (EPS) and their management (4) | c. Role of nurse in administration of Psychotropic drugs (3).
          </div>
          <div class="q-answer-content">
            <div class="ans-part">
              <div class="ans-part-title">Part (a): Classification of Antipsychotics (3 Marks)</div>
              <div class="ans-part-body">
                <table class="clinical-table">
                  <thead>
                    <tr><th>Class</th><th>Mechanism of Action</th><th>Generations & Examples</th><th>Key Clinical Profiles</th></tr>
                  </thead>
                  <tbody>
                    <tr>
                      <td><strong>Typical / First-Generation (FGAs / Neuroleptics)</strong></td>
                      <td>Potent, non-selective blockade of Dopamine D2 receptors across all cerebral pathways (mesolimbic, mesocortical, nigrostriatal, tuberoinfundibular).</td>
                      <td>
                        &bull; <em>High-Potency:</em> Haloperidol (5–20 mg/day), Fluphenazine, Trifluoperazine.<br>
                        &bull; <em>Low-Potency:</em> Chlorpromazine (Thorazine - 200–800 mg/day), Thioridazine.
                      </td>
                      <td>Highly effective against positive symptoms. <strong>Major Risk: High incidence of EPS</strong>, hyperprolactinemia (galactorrhea, amenorrhea), sedation, postural hypotension, anticholinergic effects.</td>
                    </tr>
                    <tr>
                      <td><strong>Atypical / Second-Generation (SGAs)</strong></td>
                      <td>Dual Serotonin-Dopamine Antagonism: Blocks Serotonin 5-HT2A receptors &gt; Dopamine D2 receptors. Rapid dissociation from D2 receptors.</td>
                      <td>
                        &bull; Clozapine (200–600 mg/day)<br>
                        &bull; Olanzapine (5–20 mg/day)<br>
                        &bull; Risperidone (2–6 mg/day)<br>
                        &bull; Quetiapine (150–750 mg/day)<br>
                        &bull; Aripiprazole (D2 partial agonist)
                      </td>
                      <td>Treats BOTH positive and negative symptoms; minimal EPS and tardive dyskinesia. <strong>Major Risk: Metabolic Syndrome</strong> (massive weight gain, dyslipidemia, new-onset diabetes mellitus).</td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>

            <div class="ans-part">
              <div class="ans-part-title">Part (b): Extrapyramidal Symptoms (EPS) & Their Management (4 Marks)</div>
              <div class="ans-part-body">
                <p>EPS results from potent D2 receptor blockade in the <em>Nigrostriatal pathway</em>, disrupting the dopamine-acetylcholine balance (excessive relative cholinergic tone):</p>
                <table class="clinical-table">
                  <thead>
                    <tr><th>EPS Manifestation</th><th>Onset Time</th><th>Clinical Presentation</th><th>Medical & Nursing Management</th></tr>
                  </thead>
                  <tbody>
                    <tr>
                      <td><strong>1. Acute Dystonic Reaction</strong></td>
                      <td>Within 4–48 hours (Early!)</td>
                      <td>Sudden, painful, involuntary muscle spasms:
                        <br>&bull; <em>Oculogyric Crisis:</em> Involuntary upward gaze deviation.
                        <br>&bull; <em>Torticollis:</em> Painful spasmodic neck twisting.
                        <br>&bull; <em>Opisthotonos:</em> Severe hyperextension of back.
                        <br>&bull; <em>Laryngeal Dystonia:</em> Stridor, acute airway threat.
                      </td>
                      <td><strong>Medical Emergency!</strong><br>Administer <strong>IV/IM Promethazine 25–50 mg</strong> OR <strong>IV/IM Diphenhydramine 50 mg</strong> OR <strong>IM Benztropine 1–2 mg</strong>. Dramatic resolution within 10–15 minutes. Stay with patient; reassure.</td>
                    </tr>
                    <tr>
                      <td><strong>2. Akathisia (Most Common & Distressing)</strong></td>
                      <td>Within 2–6 weeks</td>
                      <td>Subjective feeling of unbearable inner motor restlessness; inability to sit still; continuous pacing, rocking, foot-tapping. (Often misdiagnosed as worsening psychotic agitation!).</td>
                      <td>First choice: <strong>Beta-blocker (Propranolol 20–40 mg PO BID)</strong>. Add Benzodiazepines (Lorazepam 1–2 mg) or reduce antipsychotic dosage.</td>
                    </tr>
                    <tr>
                      <td><strong>3. Pseudoparkinsonism</strong></td>
                      <td>Within 1–4 weeks</td>
                      <td>Triad: Tremor (resting "pill-rolling"), Rigidity ("cogwheel" or "lead-pipe"), and Akinesia/Bradykinesia (shuffling gait, mask-like facies, drooling, stooped posture).</td>
                      <td>Administer oral central anticholinergics: <strong>Trihexyphenidyl (Artane / Pacitane) 2–4 mg PO daily</strong> or Benztropine.</td>
                    </tr>
                    <tr>
                      <td><strong>4. Tardive Dyskinesia (TD - Irreversible!)</strong></td>
                      <td>Months to years (Late!)</td>
                      <td>Involuntary, repetitive choreoathetoid movements of tongue, lips, and face (tongue protrusion / "fly-catcher tongue", lip smacking, chewing, pelvic thrusting). Due to D2 receptor supersensitivity.</td>
                      <td>Prevent via regular AIMS (Abnormal Involuntary Movement Scale) screening. Switch immediately to <strong>Clozapine</strong>. Administer VMAT2 inhibitors (Valbenazine, Deutetrabenazine). <em>Anticholinergics worsen TD!</em></td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>

            <div class="ans-part">
              <div class="ans-part-title">Part (c): Role of Nurse in Administration of Psychotropic Drugs (3 Marks)</div>
              <div class="ans-part-body">
                <ul>
                  <li><strong>1. "Cheeking" Surveillance:</strong> Psychotic patients frequently conceal tablets in the buccal pouch ("cheeking") to spit out later. <em>Nurse's Protocol:</em> Inspect oral cavity, tongue, and cheeks after administration; converse with patient for 2 minutes or use liquid/orally disintegrating formulations.</li>
                  <li><strong>2. Strict Clozapine Safety Protocol:</strong> Clozapine carries a 1–2% risk of fatal <strong>Agranulocytosis</strong> (severe bone marrow suppression).
                    <ul>
                      <li>Nurse must ensure mandatory Absolute Neutrophil Count (ANC) monitoring: Weekly for the first 6 months, biweekly for next 6 months, then monthly.</li>
                      <li>Withhold drug immediately and notify physician if ANC &lt;1,500/mm3 or if patient develops fever, sore throat, or stomatitis.</li>
                    </ul>
                  </li>
                  <li><strong>3. Neuroleptic Malignant Syndrome (NMS) Vigilance:</strong> A life-threatening idiosyncratic reaction. Nurse monitors for the classic tetrad: <strong>Hyperpyrexia (&gt;40°C), "Lead-pipe" muscle rigidity, Autonomic instability (tachycardia, labile BP, diaphoresis), and Altered consciousness</strong>.
                    <br><em>Nurse's Action:</em> STOP all antipsychotics immediately; initiate rapid active cooling; transfer to ICU; administer IV Dantrolene (muscle relaxant) and Bromocriptine (dopamine agonist).</li>
                  <li><strong>4. Metabolic & Orthostatic Monitoring:</strong> Record baseline and regular waist circumference, fasting lipid panel, and fasting blood glucose; measure lying and standing blood pressure to prevent falls from orthostatic hypotension.</li>
                </ul>
              </div>
            </div>
          </div>
        </div>

      </div>
    </div>

    <!-- ------------------------------------------------------------ -->
    <!-- TOPIC 3: ELECTROCONVULSIVE THERAPY (ECT) (REPEATED 3/4)      -->
    <!-- ------------------------------------------------------------ -->`},{id:`grp-ect`,title:`Electroconvulsive Therapy (ECT)`,repeatCount:3,years:[`2019`,`2020`,`2022`],probability:90,priorityTier:`Tier 2 • Very High`,tierClass:`tier-high`,subItems:[{concept:`Indications, absolute/relative contraindications & parameters (70–130V, 0.1–0.5 sec)`,years:`2020, 2022`},{concept:`Direct vs Modified ECT (Anesthesia: Methohexital / Propofol + Succinylcholine)`,years:`2022`},{concept:`Pre-procedure, intra-procedure & post-procedure nursing care protocols`,years:`2019, 2020, 2022`}],questions:[{paperBadge:`MPMSU July 2022 (Main) Q.3 & Feb 2020 Q.2 [10 Marks]`,weight:`Essay Question | Target: 4 Handwritten Pages`,questionText:`a. Define ECT (2) | b. Enlist indications, contraindications and side effects of ECT (3) | c. Describe the pre-procedure, intra-procedure and post-procedure nursing management of a patient receiving ECT (5).`}],answerHtml:`<!-- QUESTION 1: JULY 2022 (MAIN) Q.3 & FEB 2020 Q.2 [10 MARKS] -->
        <div class="q-block">
          <div class="q-header">
            <span class="q-badge">MPMSU July 2022 (Main) Q.3 & Feb 2020 Q.2 [10 Marks]</span>
            <span class="q-weight">Essay Question | Target: 4 Handwritten Pages</span>
          </div>
          <div class="q-text-prompt">
            <strong>Exam Question:</strong> a. Define ECT (2) | b. Enlist indications, contraindications and side effects of ECT (3) | c. Describe the pre-procedure, intra-procedure and post-procedure nursing management of a patient receiving ECT (5).
          </div>
          <div class="q-answer-content">
            <div class="ans-part">
              <div class="ans-part-title">Part (a): Definition & Parameters of ECT (2 Marks)</div>
              <div class="ans-part-body">
                <p><strong>Electroconvulsive Therapy (ECT):</strong> A safe, effective somatic psychiatric treatment in which a small, precisely controlled electrical current (typically 70–130 volts for 0.1 to 0.5 seconds) is passed through electrodes applied to the scalp to artificially induce a therapeutic generalized grand mal (tonic-clonic) seizure lasting at least 25–30 seconds on EEG. In modern psychiatric practice, it is strictly performed as <strong>Modified ECT</strong> under short-acting general anesthesia and muscle relaxation.</p>
              </div>
            </div>

            <div class="ans-part">
              <div class="ans-part-title">Part (b): Indications, Contraindications & Side Effects (3 Marks)</div>
              <div class="ans-part-body">
                <p><strong>Indications:</strong></p>
                <ul>
                  <li><em>Severe Major Depressive Disorder (MDD) with High Suicide Risk:</em> The single most effective and rapid treatment for acute life-threatening suicidality or depression with psychotic features/stupor.</li>
                  <li><em>Catatonia (Lethal Catatonia / Stupor):</em> Catatonic schizophrenia or depressive stupor refusing food/fluids.</li>
                  <li><em>Treatment-Resistant Mania (Bipolar Disorder):</em> Severe manic exhaustion unresponsive to lithium and antipsychotics.</li>
                  <li><em>Neuroleptic Malignant Syndrome (Refractory cases).</em></li>
                </ul>

                <p><strong>Contraindications:</strong></p>
                <ul>
                  <li><em>Absolute Contraindication:</em> <strong>Increased Intracranial Pressure (ICP)</strong> (space-occupying brain lesions, acute cerebral hemorrhage, intracranial aneurysm rupture risk).</li>
                  <li><em>High-Risk Relative Contraindications:</em> Recent myocardial infarction (&lt;3 months), severe cardiac arrhythmias, aortic aneurysm, retinal detachment, uncontrolled hypertension.</li>
                </ul>

                <p><strong>Side Effects:</strong></p>
                <ul>
                  <li><em>Transient Retrograde and Anterograde Amnesia:</em> Resolves within a few weeks to months (bilateral ECT causes more memory impairment than unilateral ECT).</li>
                  <li>Transient post-ictal confusion, headache, muscle soreness, nausea, and mild jaw pain.</li>
                </ul>
              </div>
            </div>

            <div class="ans-part">
              <div class="ans-part-title">Part (c): Comprehensive Nursing Management (Pre, Intra, and Post-Procedure) (5 Marks)</div>
              <div class="ans-part-body">
                <table class="clinical-table">
                  <thead>
                    <tr><th>Phase</th><th>Nursing Protocol & Actions</th><th>Medical Rationale</th></tr>
                  </thead>
                  <tbody>
                    <tr>
                      <td><strong>1. Pre-Procedure Nursing Care</strong></td>
                      <td>
                        &bull; Verify written informed consent (from patient or legal guardian per Mental Healthcare Act 2017).<br>
                        &bull; Strict NPO status for at least 6–8 hours prior to ECT.<br>
                        &bull; Check baseline investigation reports: Complete Blood Count, ECG, Chest X-ray, serum electrolytes.<br>
                        &bull; Empty bladder and bowel immediately before transfer.<br>
                        &bull; Remove dentures, spectacles, contact lenses, jewelry, hairpins, and tight garments.<br>
                        &bull; Pre-medication: Administer <strong>Atropine Sulfate 0.6 mg IM/IV</strong> 30 minutes prior.<br>
                        <em>Rationale:</em> Atropine reduces bronchial secretions (prevents aspiration) and counteracts reflexive vagal bradycardia/asystole during electrical stimulation.
                      </td>
                      <td>Prevents aspiration pneumonia, physical trauma, and life-threatening parasympathetic cardiac arrest.</td>
                    </tr>
                    <tr>
                      <td><strong>2. Intra-Procedure Nursing Care</strong></td>
                      <td>
                        &bull; Position patient supine on a firm, padded ECT couch.<br>
                        &bull; Assist anesthesiologist: Administer short-acting IV anesthetic (Methohexital 0.75–1.0 mg/kg or Propofol 1.5–2.0 mg/kg) followed by muscle relaxant (<strong>Succinylcholine / Suxamethonium 0.5–1.0 mg/kg IV</strong>).<br>
                        &bull; Ventilate patient with 100% oxygen via bag-valve-mask until muscle fasciculations cease.<br>
                        &bull; Insert a soft padded bite-block (mouth gag) between teeth before electrical stimulation.<br>
                        &bull; Clean electrode sites with normal saline to reduce skin impedance. Hold electrodes firmly in place (Bilateral: bitemporal; Unilateral: non-dominant hemisphere).<br>
                        &bull; Observe seizure progression: Tonic phase (10–15 sec) &rarr; Clonic phase (25–40 sec). (Isolate one arm with a BP cuff inflated above systolic BP to observe motor seizure while rest of body is paralyzed).
                      </td>
                      <td>Succinylcholine prevents violent motor contractions that cause long-bone fractures and spinal compression fractures. Mouth gag protects teeth and tongue.</td>
                    </tr>
                    <tr>
                      <td><strong>3. Post-Procedure Nursing Care</strong></td>
                      <td>
                        &bull; Position patient in <strong>Lateral Recovery Position</strong> (prevents airway obstruction and aspiration of secretions).<br>
                        &bull; Maintain 100% oxygen until spontaneous respiration resumes; suction oropharynx gently as needed.<br>
                        &bull; Monitor vital signs (BP, HR, SpO2) every 15 minutes for 1 hour.<br>
                        &bull; Orient patient to time, place, and person upon waking: Reassure calmly, "You are safe in the hospital. The procedure is finished."<br>
                        &bull; Manage post-ECT headache with Paracetamol 500–1000 mg PO; offer fluids only after gag reflex has fully returned.
                      </td>
                      <td>Ensures airway patency; relieves acute post-ictal confusion and anxiety.</td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </div>

      </div>
    </div>

    <!-- ------------------------------------------------------------ -->
    <!-- TOPIC 4: OBSESSIVE-COMPULSIVE DISORDER (OCD) (REPEATED 3/4)  -->
    <!-- ------------------------------------------------------------ -->`},{id:`grp-ocd`,title:`Obsessive-Compulsive Disorder (OCD)`,repeatCount:3,years:[`2020`,`2022`,`2025`],probability:90,priorityTier:`Tier 2 • Very High`,tierClass:`tier-high`,subItems:[{concept:`Obsessions vs Compulsions, ego-dystonic nature & cortical-striatal circuitry`,years:`2022, 2025`},{concept:`Exposure and Response Prevention (ERP) behavioral therapy & SSRI pharmacotherapy`,years:`2025`},{concept:`Nursing Care Plan for severe compulsive hand-washing & ritual scheduling`,years:`2020, 2025`}],questions:[{paperBadge:`MPMSU Feb 2025 (Supp) Q.3 & Feb 2020 Q.4 [15 Marks]`,weight:`Full Long Essay | Target: 5 Handwritten Pages`,questionText:`a. Define Obsessive Compulsive Disorder (OCD) (2) | b. Explain the psychopathology and clinical features of OCD (5) | c. Discuss the behavioral, cognitive and pharmacological management of OCD (4) | d. Develop a Nursing Care Plan for a patient with hand-washing compulsion (4).`}],answerHtml:`<!-- QUESTION 1: FEB 2025 (SUPP) Q.3 & FEB 2020 Q.4 [15 MARKS] -->
        <div class="q-block">
          <div class="q-header">
            <span class="q-badge">MPMSU Feb 2025 (Supp) Q.3 & Feb 2020 Q.4 [15 Marks]</span>
            <span class="q-weight">Full Long Essay | Target: 5 Handwritten Pages</span>
          </div>
          <div class="q-text-prompt">
            <strong>Exam Question:</strong> a. Define Obsessive Compulsive Disorder (OCD) (2) | b. Explain the psychopathology and clinical features of OCD (5) | c. Discuss the behavioral, cognitive and pharmacological management of OCD (4) | d. Develop a Nursing Care Plan for a patient with hand-washing compulsion (4).
          </div>
          <div class="q-answer-content">
            <div class="ans-part">
              <div class="ans-part-title">Part (a): Definition of OCD (2 Marks)</div>
              <div class="ans-part-body">
                <p><strong>Obsessive-Compulsive Disorder (OCD):</strong> A chronic psychiatric disorder characterized by recurrent, persistent, intrusive, distressing thoughts, images, or urges (<strong>Obsessions</strong>) that trigger severe anxiety, driving the individual to perform repetitive, purposeful, rigid mental or physical behaviors (<strong>Compulsions</strong>) aimed at reducing the anxiety or preventing a dreaded catastrophe. Crucially, the disorder is <strong>Ego-Dystonic</strong> (the patient recognizes the thoughts and rituals as irrational, senseless, and originating from their own mind, yet feels powerless to resist).</p>
              </div>
            </div>

            <div class="ans-part">
              <div class="ans-part-title">Part (b): Psychopathology & Clinical Features (5 Marks)</div>
              <div class="ans-part-body">
                <p><strong>Neurobiological Psychopathology:</strong> Functional hyperactivity in the <em>Cortico-Striato-Thalamo-Cortical (CSTC) loop</em> (orbitofrontal cortex, anterior cingulate gyrus, and caudate nucleus) coupled with central serotonin (5-HT) neurotransmitter dysregulation.</p>

                <p><strong>Differentiating Obsessions and Compulsions:</strong></p>
                <table class="clinical-table">
                  <thead>
                    <tr><th style="width: 50%;">Obsessions (Intrusive Cognitive Phenomena)</th><th style="width: 50%;">Compulsions (Motor / Mental Acts)</th></tr>
                  </thead>
                  <tbody>
                    <tr>
                      <td>&bull; <strong>Contamination:</strong> Fear of dirt, germs, bodily secretions, toxic chemicals.<br>&bull; <strong>Pathological Doubt:</strong> Unbearable uncertainty whether doors are locked, stove turned off, iron unplugged.<br>&bull; <strong>Symmetry & Precision:</strong> Need for items to be arranged in exact mathematical alignment.<br>&bull; <strong>Aggressive / Sexual Intrusions:</strong> Terrifying taboo thoughts of stabbing child or shouting profanities in temple.</td>
                      <td>&bull; <strong>Cleaning / Washing:</strong> Repetitive hand-washing (50–100 times daily until skin bleeds), prolonged 3-hour showers.<br>&bull; <strong>Checking:</strong> Returning 20 times to re-check locks, electrical switches, gas valves.<br>&bull; <strong>Ordering / Arranging:</strong> Rearranging books or cutlery obsessively for hours.<br>&bull; <strong>Counting / Repeating:</strong> Repeating a prayer, word, or counting to 10 before crossing a threshold.</td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>

            <div class="ans-part">
              <div class="ans-part-title">Part (c): Behavioral, Cognitive & Pharmacological Management (4 Marks)</div>
              <div class="ans-part-body">
                <ul>
                  <li><strong>1. Behavioral Therapy (Gold Standard): Exposure and Response Prevention (ERP):</strong>
                    <ul>
                      <li>The patient is systematically exposed in a graded hierarchy to the anxiety-provoking feared stimulus (e.g., touching a public doorknob) and strictly instructed and supported to <em>resist performing the compulsive ritual</em> (e.g., delaying and refraining from washing hands).</li>
                      <li>Over 60–90 minutes, anxiety naturally peaks and then undergoes physiological extinction (habituation). Breaks the conditioning cycle between ritual and anxiety relief.</li>
                    </ul>
                  </li>
                  <li><strong>2. Cognitive Therapy:</strong> Cognitive restructuring to challenge inflated responsibility ("If I don't wash my hands, my mother will die of sepsis") and catastrophic misinterpretations. Thought-stopping techniques.</li>
                  <li><strong>3. Pharmacotherapy:</strong>
                    <ul>
                      <li><em>Selective Serotonin Reuptake Inhibitors (SSRIs - 1st Line):</em> High doses required (Fluoxetine 60–80 mg/day, Sertraline 200 mg/day, Fluvoxamine 200–300 mg/day). Therapeutic response takes 8–12 weeks.</li>
                      <li><em>Tricyclic Antidepressant:</em> Clomipramine (Anafranil - 150–250 mg/day), a potent serotonin reuptake inhibitor.</li>
                    </ul>
                  </li>
                </ul>
              </div>
            </div>

            <div class="ans-part">
              <div class="ans-part-title">Part (d): Nursing Care Plan for Patient with Hand-Washing Compulsion (4 Marks)</div>
              <div class="ans-part-body">
                <table class="clinical-table">
                  <thead>
                    <tr><th>Nursing Diagnosis</th><th>Goal</th><th>Interventions & Therapeutic Rationales</th><th>Evaluation</th></tr>
                  </thead>
                  <tbody>
                    <tr>
                      <td><strong>Ineffective Coping & Anxiety</strong> r/t inability to resist hand-washing rituals.</td>
                      <td>Gradually reduce hand-washing ritual frequency without panic attacks.</td>
                      <td>
                        &bull; <em>INITIAL PHASE RULE:</em> Initially, <strong>allow time for the ritual</strong>. Do NOT abruptly prohibit or interrupt hand-washing at admission.<br>
                        <em>Rationale:</em> Abrupt cessation of rituals causes severe panic and potential suicidal crisis.<br>
                        &bull; <em>CONTRACTING & STRUCTURING:</em> Negotiate a written ritual reduction schedule with the patient: Limit hand-washing to 5 minutes instead of 20 minutes, 5 times daily instead of 20 times.<br>
                        &bull; Schedule unit activities and meals around the ritual schedule to prevent secondary anxiety.<br>
                        &bull; Teach deep diaphragmatic breathing and progressive muscle relaxation when urge arises.
                      </td>
                      <td>Patient reduces hand-washing to 5-minute sessions 4 times daily; reports tolerable anxiety.</td>
                    </tr>
                    <tr>
                      <td><strong>Impaired Skin Integrity</strong> r/t constant hand-washing with harsh soaps and hot water.</td>
                      <td>Heal excoriated, cracked hand skin and maintain intact epidermis.</td>
                      <td>
                        &bull; Inspect hands daily for cracking, fissures, and secondary bacterial infection.<br>
                        &bull; Substitute harsh hospital antiseptic soaps with mild, non-drying moisturizing skin cleansers.<br>
                        &bull; Apply soothing emollient barrier creams (petroleum jelly, ceramide lotion) after washing.
                      </td>
                      <td>Skin on hands healed; erythema and fissures resolved; zero secondary infection.</td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </div>

      </div>
    </div>

    <!-- ------------------------------------------------------------ -->
    <!-- TOPIC 5: CRISIS INTERVENTION & PSYCHIATRIC EMERGENCIES (3/4) -->
    <!-- ------------------------------------------------------------ -->`},{id:`grp-crisis`,title:`Crisis Intervention & Psychiatric Emergencies`,repeatCount:3,years:[`2019`,`2022`,`2025`],probability:90,priorityTier:`Tier 2 • Very High`,tierClass:`tier-high`,subItems:[{concept:`Crisis: Caplan's 4 phases, maturational vs situational vs adventitious`,years:`2025`},{concept:`Techniques of crisis intervention (Aguilera balancing factors & 6-step model)`,years:`2019, 2025`},{concept:`Psychiatric emergencies: Suicide risk assessment (SAD PERSONS) & nursing care`,years:`2022`}],questions:[{paperBadge:`MPMSU Feb 2025 (Supp) — Q.4 [10 Marks]`,weight:`Essay Question | Target: 4 Handwritten Pages`,questionText:`a. Define Crisis (2) | b. Enumerate types and phases of Crisis (3) | c. Discuss the techniques of Crisis Intervention and nurse's role (5).`},{paperBadge:`MPMSU July 2022 (Main & Supp) — Q.4 [10 Marks]`,weight:`Essay Question | Target: 4 Handwritten Pages`,questionText:`a. Define Psychiatric Emergency (2) | b. Enlist common psychiatric emergencies (3) | c. Discuss the crisis intervention and nursing management of a suicidal patient (5).`}],answerHtml:`<!-- QUESTION 1: FEB 2025 (SUPP) Q.4 [10 MARKS] -->
        <div class="q-block">
          <div class="q-header">
            <span class="q-badge">MPMSU Feb 2025 (Supp) — Q.4 [10 Marks]</span>
            <span class="q-weight">Essay Question | Target: 4 Handwritten Pages</span>
          </div>
          <div class="q-text-prompt">
            <strong>Exam Question:</strong> a. Define Crisis (2) | b. Enumerate types and phases of Crisis (3) | c. Discuss the techniques of Crisis Intervention and nurse's role (5).
          </div>
          <div class="q-answer-content">
            <div class="ans-part">
              <div class="ans-part-title">Part (a): Definition of Crisis (2 Marks)</div>
              <div class="ans-part-body">
                <p><strong>Crisis (Gerald Caplan / Donna Aguilera):</strong> An acute, self-limiting state of severe psychological disequilibrium, emotional turmoil, and behavioral disorganization resulting from a hazardous precipitating life event that poses an insurmountable obstacle to the individual's customary coping mechanisms, lasting typically <strong>4 to 6 weeks</strong>.</p>
              </div>
            </div>

            <div class="ans-part">
              <div class="ans-part-title">Part (b): Types and Phases of Crisis (3 Marks)</div>
              <div class="ans-part-body">
                <p><strong>1. Types of Crisis:</strong></p>
                <ul>
                  <li><em>Maturational / Developmental Crisis:</em> Transition through normal predictable developmental stages (Erikson's stages: adolescence, leaving home, marriage, parenthood, mid-life transition, retirement).</li>
                  <li><em>Situational / Anticipated Crisis:</em> Unexpected, external, traumatic life events (sudden death of spouse, job loss, acute severe illness, divorce, sudden financial ruin).</li>
                  <li><em>Adventitious / Social Crisis:</em> Rare, devastating, unexpected disasters affecting entire communities (earthquakes, floods, terrorist attacks, wars, mass shootings, violent assault/rape).</li>
                </ul>

                <p><strong>2. Caplan's 4 Phases of Crisis:</strong></p>
                <ol>
                  <li><strong>Phase 1: Initial Stressor Exposure:</strong> Precipitating event triggers high anxiety. Individual mobilizes familiar customary problem-solving coping mechanisms.</li>
                  <li><strong>Phase 2: Coping Failure & Rising Tension:</strong> Customary mechanisms fail. Discomfort escalates; trial-and-error behaviors attempted without relief.</li>
                  <li><strong>Phase 3: Severe Tension & Novel Resources:</strong> All internal and external resources mobilized. Resolution may occur through redefined goals, compromise, or temporary defense mechanisms.</li>
                  <li><strong>Phase 4: Major Mental Breakdown / Disequilibrium:</strong> If resolution fails, tension surpasses psychological threshold; severe cognitive disorganization, emotional distress, severe depression, psychotic break, or suicide occurs.</li>
                </ol>
              </div>
            </div>

            <div class="ans-part">
              <div class="ans-part-title">Part (c): Techniques of Crisis Intervention & Nurse's Role (5 Marks)</div>
              <div class="ans-part-body">
                <p><strong>Core Goal of Crisis Intervention:</strong> To restore the individual to at least their <em>pre-crisis level of functioning</em> (or ideally a higher level of adaptive resilience) within 4–6 weeks.</p>
                <p><strong>Specific Intervention Techniques:</strong></p>
                <ul>
                  <li><strong>1. Catharsis:</strong> Encouraging open verbal release of suppressed feelings (grief, anger, terror). Provide a calm, supportive, non-judgmental presence.</li>
                  <li><strong>2. Clarification:</strong> Assisting the patient to identify the exact connection between the precipitating event and their current feelings of despair ("What happened right before you felt you could not go on?").</li>
                  <li><strong>3. Suggestion:</strong> Offering constructive, adaptive alternatives and gently reframing distorted perceptions.</li>
                  <li><strong>4. Reinforcement of Adaptive Behavior:</strong> Praising adaptive choices and healthy coping actions taken by the patient.</li>
                  <li><strong>5. Support of Defense Mechanisms:</strong> Strengthening healthy defense mechanisms (sublimation, suppression) while gently discouraging maladaptive ones (denial, projection).</li>
                  <li><strong>6. Mobilization of Social & Community Resources:</strong> Connecting with family, trusted spiritual leaders, self-help groups, and financial/social welfare agencies.</li>
                </ul>
                <p><strong>Nurse's Operational Roles:</strong></p>
                <div class="callout">
                  &bull; <strong>Active, Direct, and Problem-Solving Stance:</strong> Unlike traditional psychotherapy, the crisis nurse is active, direct, and focuses strictly on the <strong>"here and now"</strong> problem.
                  <br>&bull; <strong>Immediate Safety First:</strong> Assess suicide risk immediately; remove lethal means.
                  <br>&bull; <strong>Realistic Short-Term Action Plan:</strong> Formulate concrete daily tasks with the patient rather than dwelling on childhood or long-term history.
                </div>
              </div>
            </div>
          </div>
        </div>

        <!-- QUESTION 2: JULY 2022 (MAIN) Q.4 [10 MARKS] -->
        <div class="q-block">
          <div class="q-header">
            <span class="q-badge">MPMSU July 2022 (Main & Supp) — Q.4 [10 Marks]</span>
            <span class="q-weight">Essay Question | Target: 4 Handwritten Pages</span>
          </div>
          <div class="q-text-prompt">
            <strong>Exam Question:</strong> a. Define Psychiatric Emergency (2) | b. Enlist common psychiatric emergencies (3) | c. Discuss the crisis intervention and nursing management of a suicidal patient (5).
          </div>
          <div class="q-answer-content">
            <div class="ans-part">
              <div class="ans-part-title">Part (a): Definition of Psychiatric Emergency (2 Marks)</div>
              <div class="ans-part-body">
                <p><strong>Psychiatric Emergency:</strong> An acute disturbance in behavior, mood, thought process, or social functioning that renders the individual an immediate, severe danger to themselves or others, or makes them utterly incapable of basic self-care, demanding immediate psychiatric assessment and life-saving clinical intervention.</p>
              </div>
            </div>

            <div class="ans-part">
              <div class="ans-part-title">Part (b): Common Psychiatric Emergencies (3 Marks)</div>
              <div class="ans-part-body">
                <ol>
                  <li><strong>Suicidal Behavior & Intent:</strong> Imminent risk of self-harm or suicide attempt.</li>
                  <li><strong>Violent / Aggressive Behavior (Excited Delirium / Psychotic Agitation):</strong> Acute danger to staff and peers.</li>
                  <li><strong>Acute Panic Attack & Hyperventilation:</strong> Overwhelming terror with autonomic storm.</li>
                  <li><strong>Stupor & Catatonia:</strong> Complete mutism, akinesia, dehydration risk.</li>
                  <li><strong>Substance Withdrawal Delirium (Delirium Tremens):</strong> Alcohol withdrawal with visual hallucinations, tremors, seizures, autonomic collapse.</li>
                  <li><strong>Neuroleptic Malignant Syndrome (NMS):</strong> Idiosyncratic hyperpyrexia and rigidity.</li>
                  <li><strong>Lithium Toxicity:</strong> Serum level &gt;1.5–2.0 mEq/L causing ataxia, convulsions, renal failure.</li>
                </ol>
              </div>
            </div>

            <div class="ans-part">
              <div class="ans-part-title">Part (c): Nursing Management of Suicidal Patient (5 Marks)</div>
              <div class="ans-part-body">
                <p><strong>1. Suicide Risk Assessment (SAD PERSONS Scale):</strong></p>
                <ul>
                  <li><strong>S:</strong> Sex (male higher completed suicide rate).</li>
                  <li><strong>A:</strong> Age (&lt;19 or &gt;45 years).</li>
                  <li><strong>D:</strong> Depression or psychiatric illness.</li>
                  <li><strong>P:</strong> Previous suicide attempt (Single strongest predictor!).</li>
                  <li><strong>E:</strong> Ethanol / substance abuse.</li>
                  <li><strong>R:</strong> Rational thinking loss (psychosis, command hallucinations).</li>
                  <li><strong>S:</strong> Social support lacking (widowed, divorced, living alone).</li>
                  <li><strong>O:</strong> Organized plan with lethal means (firearm, jumping, hanging).</li>
                  <li><strong>N:</strong> No spouse / partner.</li>
                  <li><strong>S:</strong> Sickness (chronic debilitating painful illness).</li>
                </ul>

                <p><strong>2. Direct Suicide Nursing Protocols:</strong></p>
                <table class="clinical-table">
                  <thead>
                    <tr><th>Intervention Domain</th><th>Specific Nursing Actions</th><th>Medical Rationale</th></tr>
                  </thead>
                  <tbody>
                    <tr>
                      <td><strong>Direct Inquiry</strong></td>
                      <td>Ask directly and openly: <strong>"Are you thinking about suicide or killing yourself? Do you have a specific plan?"</strong></td>
                      <td>Asking directly does NOT plant the idea; it provides immense relief that feelings can be spoken about safely.</td>
                    </tr>
                    <tr>
                      <td><strong>Observation Level</strong></td>
                      <td>Initiate <strong>1-on-1 Continuous Close Observation (Arms-Length Constant Visual Contact 24/7)</strong>, including in the bathroom and while sleeping.</td>
                      <td>Ensures immediate physical intervention before any self-harm act can occur.</td>
                    </tr>
                    <tr>
                      <td><strong>Environmental Safety</strong></td>
                      <td>Remove all potentially lethal objects from patient's room: Belts, shoe laces, drawstrings, bed cords, glassware, mirrors, razors, plastic bags, medications, cutlery. Ensure window restrictors are locked.</td>
                      <td>Eliminates physical means for hanging, exsanguination, or asphyxiation.</td>
                    </tr>
                    <tr>
                      <td><strong>"No-Suicide" Safety Contract</strong></td>
                      <td>Establish a written safety plan: Patient agrees that if suicidal urges occur, they will immediately notify the primary nurse before acting.</td>
                      <td>Fosters therapeutic alliance, shared responsibility, and buys critical time to intervene.</td>
                    </tr>
                    <tr>
                      <td><strong>Pharmacotherapy & Somatic Care</strong></td>
                      <td>Administer Lithium (has proven anti-suicidal properties in BPAD) or Ketamine/Esketamine infusion; prepare for emergency bilateral ECT for refractory acute suicidality.</td>
                      <td>Rapid pharmacological/somatic resolution of suicidal impulse.</td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </div>

      </div>
    </div>

    <!-- ------------------------------------------------------------ -->
    <!-- TOPIC 6: PRINCIPLES & MENTAL HEALTHCARE ACT (REPEATED 3/4)  -->
    <!-- ------------------------------------------------------------ -->`},{id:`grp-principles`,title:`Principles of Mental Health Nursing & Mental Healthcare Act`,repeatCount:3,years:[`2019`,`2020`,`2025`],probability:90,priorityTier:`Tier 2 • Very High`,tierClass:`tier-high`,subItems:[{concept:`Fundamental principles of psychiatric nursing (Acceptance, reality testing, non-judgment)`,years:`2019, 2025`},{concept:`Mental Healthcare Act 2017: Advance directives, nominated representative & decriminalization of suicide`,years:`2020, 2025`},{concept:`Peplau's therapeutic nurse-patient relationship phases (Orientation, Working, Termination)`,years:`2019`}],questions:[{paperBadge:`MPMSU Feb 2025 (Supp) — Q.1 [15 Marks]`,weight:`Full Long Essay | Target: 5 Handwritten Pages`,questionText:`a. Define Mental Health and Mental Illness (2) | b. Discuss the general principles of Mental Health Nursing (6) | c. Explain the salient features and rights of mentally ill persons under the Mental Healthcare Act 2017 (7).`},{paperBadge:`MPMSU May 2019 (Main) — Q.2 [10 Marks]`,weight:`Essay Question | Target: 4 Handwritten Pages`,questionText:`a. State the principles of Psychiatric Nursing (4) | b. Discuss therapeutic nurse-patient relationship and its phases (6).`}],answerHtml:`<!-- QUESTION 1: FEB 2025 (SUPP) Q.1 [15 MARKS] -->
        <div class="q-block">
          <div class="q-header">
            <span class="q-badge">MPMSU Feb 2025 (Supp) — Q.1 [15 Marks]</span>
            <span class="q-weight">Full Long Essay | Target: 5 Handwritten Pages</span>
          </div>
          <div class="q-text-prompt">
            <strong>Exam Question:</strong> a. Define Mental Health and Mental Illness (2) | b. Discuss the general principles of Mental Health Nursing (6) | c. Explain the salient features and rights of mentally ill persons under the Mental Healthcare Act 2017 (7).
          </div>
          <div class="q-answer-content">
            <div class="ans-part">
              <div class="ans-part-title">Part (a): Definitions of Mental Health & Mental Illness (2 Marks)</div>
              <div class="ans-part-body">
                <p><strong>Mental Health (WHO):</strong> A state of well-being in which an individual realizes their own abilities, can cope effectively with the normal stresses of life, can work productively and fruitfully, and is able to make a meaningful contribution to their community.</p>
                <p><strong>Mental Illness:</strong> A clinically significant behavioral or psychological syndrome or pattern that occurs in an individual and that is associated with present distress (a painful symptom) or disability (impairment in one or more important areas of functioning) or with a significantly increased risk of suffering death, pain, disability, or an important loss of freedom (DSM-5 / ICD-11).</p>
              </div>
            </div>

            <div class="ans-part">
              <div class="ans-part-title">Part (b): General Principles of Mental Health Nursing (6 Marks)</div>
              <div class="ans-part-body">
                <p>Formulated by standard psychiatric nursing authorities to guide ethical and therapeutic nurse-patient interactions:</p>
                <ol>
                  <li><strong>1. Accept the Patient Exactly as They Are:</strong> Unconditional positive regard. Accept the human being while setting limits on unacceptable destructive behavior. Do not reject, judge, or moralize.</li>
                  <li><strong>2. Use Self-Understanding as a Therapeutic Tool (Self-Awareness):</strong> The nurse must understand their own unconscious biases, values, prejudices, anxieties, and defense mechanisms to prevent negative countertransference.</li>
                  <li><strong>3. Maintain Objective Observation:</strong> Focus on objective behavioral descriptions rather than interpreting or labeling motives (e.g., write "patient paced hallway for 45 minutes shouting" instead of "patient was rude and aggressive").</li>
                  <li><strong>4. Provide Emotional Security & Reassurance:</strong> Give realistic reassurance based on facts. Never offer false clichés (e.g., never say "Don't worry, everything will be fine").</li>
                  <li><strong>5. Modify the Environment According to Patient Needs:</strong> Provide low-stimulus environments for manic patients; safe, ligature-free environments for suicidal patients.</li>
                  <li><strong>6. Maintain Verbal and Non-Verbal Consistency:</strong> Body language, facial expressions, and vocal tone must align authentically with verbal messages.</li>
                  <li><strong>7. Avoid Physical and Emotional Restraint Where Possible:</strong> Restraints should be an intervention of absolute last resort when less restrictive de-escalation methods have failed.</li>
                </ol>
              </div>
            </div>

            <div class="ans-part">
              <div class="ans-part-title">Part (c): Salient Features & Rights Under Mental Healthcare Act 2017 (India) (7 Marks)</div>
              <div class="ans-part-body">
                <p>The <strong>Mental Healthcare Act 2017 (MHCA 2017)</strong> came into force in May 2018, repealing the outdated Mental Health Act 1987, adopting a rights-based framework aligned with the UN Convention on the Rights of Persons with Disabilities (UNCRPD):</p>
                <ul>
                  <li><strong>1. Decriminalization of Suicide (Section 115):</strong> Presumes that any person who attempts suicide is under severe stress and shall NOT be prosecuted under Section 309 of the Indian Penal Code (IPC). The government is legally mandated to provide medical treatment and rehabilitation.</li>
                  <li><strong>2. Advance Directives (Section 5):</strong> Every adult person with mental capacity has the legal right to write an advance directive specifying:
                    <ul>
                      <li>How they wish to be treated or not treated for mental illness in future episodes.</li>
                      <li>Who their legally appointed Nominated Representative shall be.</li>
                    </ul>
                  </li>
                  <li><strong>3. Nominated Representative (NR):</strong> Every person has the right to nominate an individual to make healthcare decisions on their behalf if they lose capacity.</li>
                  <li><strong>4. Strict Prohibition of Inhumane Treatments:</strong>
                    <ul>
                      <li><strong>Prohibition of Direct ECT:</strong> ECT can ONLY be administered as Modified ECT under general anesthesia and muscle relaxants.</li>
                      <li><strong>Prohibition of ECT in Minors:</strong> Forbidden in children/adolescents &lt;18 years unless explicit approval is granted by the Mental Health Review Board.</li>
                      <li>Prohibition of chaining, tying, or keeping mentally ill persons in solitary confinement.</li>
                    </ul>
                  </li>
                  <li><strong>5. Fundamental Rights of Mentally Ill Persons:</strong>
                    <ul>
                      <li>Right to affordable, accessible mental health care from government services.</li>
                      <li>Right to live with dignity and protection from cruel, inhuman, or degrading treatment.</li>
                      <li>Right to confidentiality and privacy regarding psychiatric medical records.</li>
                      <li>Right to free legal aid to defend against involuntary admissions.</li>
                    </ul>
                  </li>
                  <li><strong>6. Mental Health Review Boards (MHRB):</strong> Quasi-judicial bodies established in every district to register advance directives, monitor psychiatric institutions, and hear patient grievances.</li>
                </ul>
              </div>
            </div>
          </div>
        </div>

        <!-- QUESTION 2: MAY 2019 (MAIN) Q.2 [10 MARKS] -->
        <div class="q-block">
          <div class="q-header">
            <span class="q-badge">MPMSU May 2019 (Main) — Q.2 [10 Marks]</span>
            <span class="q-weight">Essay Question | Target: 4 Handwritten Pages</span>
          </div>
          <div class="q-text-prompt">
            <strong>Exam Question:</strong> a. State the principles of Psychiatric Nursing (4) | b. Discuss therapeutic nurse-patient relationship and its phases (6).
          </div>
          <div class="q-answer-content">
            <div class="ans-part">
              <div class="ans-part-title">Part (a): Principles of Psychiatric Nursing (4 Marks)</div>
              <div class="ans-part-body">
                <p>The core principles include: Patient acceptance without conditions; therapeutic communication focused on reality; emotional neutrality without countertransference; setting clear consistent limits; providing a physically and psychologically safe environment; and using reassurance realistically and cautiously.</p>
              </div>
            </div>

            <div class="ans-part">
              <div class="ans-part-title">Part (b): Hildegard Peplau's Therapeutic Nurse-Patient Relationship (6 Marks)</div>
              <div class="ans-part-body">
                <p>A goal-directed, time-limited, mutually established interpersonal process between nurse and patient aimed at promoting patient growth, insight, and behavioral change, structured into <strong>4 Distinct Phases</strong>:</p>
                <table class="clinical-table">
                  <thead>
                    <tr><th>Phase</th><th>Nurse's Tasks & Clinical Focus</th><th>Potential Pitfalls & Management</th></tr>
                  </thead>
                  <tbody>
                    <tr>
                      <td><strong>1. Pre-Interaction Phase</strong></td>
                      <td>
                        &bull; Review patient's clinical chart, medical history, psychiatric evaluation.<br>
                        &bull; Examine own feelings, biases, fears, and preconceptions regarding the patient.<br>
                        &bull; Plan first meeting setting (quiet, safe, non-threatening).
                      </td>
                      <td>Anxiety or prejudice regarding violent or stigmatized patients. Requires conscious self-reflection.</td>
                    </tr>
                    <tr>
                      <td><strong>2. Orientation / Introductory Phase</strong></td>
                      <td>
                        &bull; Introduce self, define roles, and establish professional boundaries.<br>
                        &bull; Formulate the <strong>Therapeutic Nurse-Patient Contract</strong>: State the meeting time, frequency, location, duration, and the explicit end-date (termination).<br>
                        &bull; Discuss confidentiality limits (explain that self-harm or threats of violence must be reported to the treatment team).<br>
                        &bull; Establish trust and rapport; identify patient's initial problems and goals.
                      </td>
                      <td>Patient testing the nurse's commitment by showing up late or acting out. Nurse responds with consistency.</td>
                    </tr>
                    <tr>
                      <td><strong>3. Working Phase</strong></td>
                      <td>
                        &bull; Maintain mutual trust and explore stressful issues deeply.<br>
                        &bull; Facilitate behavioral change, problem-solving skills, and coping strategies.<br>
                        &bull; Identify and overcome defense mechanisms, resistance, and denial.<br>
                        &bull; <strong>Manage Transference:</strong> Patient unconsciously displaces feelings from past figures (parent) onto the nurse.<br>
                        &bull; <strong>Manage Countertransference:</strong> Nurse displaces unconscious feelings onto the patient.
                      </td>
                      <td>Resistance to change; dependency on nurse. Handled through therapeutic feedback and encouraging autonomy.</td>
                    </tr>
                    <tr>
                      <td><strong>4. Termination Phase</strong></td>
                      <td>
                        &bull; Begins during the orientation phase when contract is made.<br>
                        &bull; Review progress made toward therapeutic goals.<br>
                        &bull; Acknowledge and validate shared feelings of sadness or loss associated with ending the relationship.<br>
                        &bull; Formulate future coping plans and community referral networks.<br>
                        &bull; <em>STRICT BOUNDARY RULE:</em> Never maintain personal contact (social media, phone calls, personal visits) after termination.
                      </td>
                      <td>Regressive behavior or symptom recurrence by patient to prolong hospitalization. Validated firmly and resolved.</td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </div>

      </div>
    </div>

    <!-- ------------------------------------------------------------ -->
    <!-- TOPIC 7: MOOD DISORDERS: MANIA & BPAD (REPEATED IN '19 & '25)-->
    <!-- ------------------------------------------------------------ -->`},{id:`grp-mania`,title:`Mood Disorders (Mania & Bipolar Affective Disorder)`,repeatCount:2,years:[`2019`,`2025`],probability:80,priorityTier:`Tier 3 • High Yield`,tierClass:`tier-moderate`,subItems:[{concept:`Mania definition, DIG FAST mnemonic & stages (Hypomania, Acute, Delirious)`,years:`2019, 2025`},{concept:`Pharmacotherapy: Lithium Carbonate (therapeutic window 0.6–1.2 mEq/L, toxicity & monitoring)`,years:`2019, 2025`},{concept:`Comprehensive Nursing Care Plan: High-calorie finger foods, low stimulus & limit setting`,years:`2019, 2025`}],questions:[{paperBadge:`MPMSU Feb 2025 (Supp) Q.2 & May 2019 Q.3 [15 Marks]`,weight:`Identical Verbatim Essay | Target: 5 Handwritten Pages`,questionText:`a. Define Mania (2) | b. Enlist the etiology and clinical manifestations of Mania (stages of mania) (5) | c. Discuss the pharmacological management (Lithium toxicity monitoring) and nursing care plan for a manic patient (8).`}],answerHtml:`<!-- QUESTION 1: FEB 2025 (SUPP) Q.2 & MAY 2019 Q.3 [15 MARKS - IDENTICAL ESSAY] -->
        <div class="q-block">
          <div class="q-header">
            <span class="q-badge">MPMSU Feb 2025 (Supp) Q.2 & May 2019 Q.3 [15 Marks]</span>
            <span class="q-weight">Identical Verbatim Essay | Target: 5 Handwritten Pages</span>
          </div>
          <div class="q-text-prompt">
            <strong>Exam Question:</strong> a. Define Mania (2) | b. Enlist the etiology and clinical manifestations of Mania (stages of mania) (5) | c. Discuss the pharmacological management (Lithium toxicity monitoring) and nursing care plan for a manic patient (8).
          </div>
          <div class="q-answer-content">
            <div class="ans-part">
              <div class="ans-part-title">Part (a): Definition of Mania (2 Marks)</div>
              <div class="ans-part-body">
                <p><strong>Mania (ICD-10 / DSM-5):</strong> An acute severe mood disorder characterized by a sustained, pathologically elevated, euphoric, expansive, or irritable mood accompanied by increased psychomotor activity, flight of ideas, pressured speech, inflated self-esteem (grandiosity), and severely decreased need for sleep, lasting at least 1 week and causing marked impairment in occupational and social functioning.</p>
              </div>
            </div>

            <div class="ans-part">
              <div class="ans-part-title">Part (b): Etiology & Clinical Stages of Mania (5 Marks)</div>
              <div class="ans-part-body">
                <p><strong>Etiology (Biochemical & Genetic):</strong></p>
                <ul>
                  <li><em>Biogenic Amine Hypothesis:</em> Excessive functional transmission of Norepinephrine and Dopamine; deficient Serotonin (permissive serotonin hypothesis).</li>
                  <li><em>Genetic Concordance:</em> First-degree relatives have a 10–15% lifetime risk; monozygotic twins show 65–70% concordance.</li>
                </ul>
                <p><strong>Diagnostic Mnemonic (DIG FAST):</strong></p>
                <ul>
                  <li><strong>D</strong> - Distractibility (cannot filter extraneous stimuli).</li>
                  <li><strong>I</strong> - Indiscretion / Impulsive reckless behavior (hypersexual, reckless driving, foolish investments).</li>
                  <li><strong>G</strong> - Grandiosity / Inflated self-esteem (believes they are God, royalty, billionaire).</li>
                  <li><strong>F</strong> - Flight of ideas / Racing thoughts.</li>
                  <li><strong>A</strong> - Activity increased / Psychomotor agitation.</li>
                  <li><strong>S</strong> - Sleep deficit (feels fully rested after 1–2 hours of sleep).</li>
                  <li><strong>T</strong> - Talkativeness / Pressured speech (loud, rapid, impossible to interrupt).</li>
                </ul>

                <p><strong>3 Progressive Clinical Stages:</strong></p>
                <ol>
                  <li><em>Stage 1: Hypomania:</em> Cheerful, high energy, increased productivity, witty, mild grandiosity; no psychotic symptoms; does not require hospitalization.</li>
                  <li><em>Stage 2: Acute Mania:</em> Marked euphoria or intense irritability, flight of ideas, clang associations, grandiosity, total insomnia, bizarre gaudy attire, neglect of eating/hygiene; requires inpatient hospitalization.</li>
                  <li><em>Stage 3: Delirious Mania:</em> Severe clouding of consciousness, frenzy, disorientation, auditory/visual hallucinations, continuous aimless motor excitement; life-threatening risk of cardiovascular exhaustion and fatal dehydration.</li>
                </ol>
              </div>
            </div>

            <div class="ans-part">
              <div class="ans-part-title">Part (c): Pharmacological Management (Lithium Protocol) & Nursing Care Plan (8 Marks)</div>
              <div class="ans-part-body">
                <p><strong>1. Lithium Carbonate Protocol & Toxicity Monitoring:</strong></p>
                <div class="calc-box">
                  <strong>SERUM LITHIUM REFERENCE RANGES (Blood drawn 12 hrs post-evening dose):</strong><br>
                  &bull; <strong>Acute Therapeutic Range:</strong> 0.8 to 1.2 mEq/L<br>
                  &bull; <strong>Maintenance Range:</strong> 0.6 to 0.8 mEq/L<br>
                  &bull; <strong>Toxic Threshold:</strong> &gt; 1.5 mEq/L (Potentially fatal &gt; 2.5 mEq/L)
                </div>
                <ul>
                  <li><strong>Pre-Lithium Workup:</strong> Renal Function Tests (BUN, Creatinine), Thyroid Function Tests (TSH - risk of lithium-induced hypothyroidism), ECG, pregnancy test (Ebstein's cardiac anomaly in fetus).</li>
                  <li><strong>Clinical Stages of Lithium Toxicity:</strong>
                    <ul>
                      <li><em>Mild (1.5–2.0 mEq/L):</em> Coarse hand tremors, persistent nausea, vomiting, watery diarrhea, lethargy, muscle weakness.</li>
                      <li><em>Moderate (2.0–2.5 mEq/L):</em> Ataxia, giddiness, tinnitus, blurred vision, dysarthria, hyperreflexia, clonic muscle twitches.</li>
                      <li><em>Severe (&gt;2.5 mEq/L):</em> Oliguria/anuria, generalized seizures, arrhythmias, coma, cardiovascular collapse, death. (Requires emergency Hemodialysis!).</li>
                    </ul>
                  </li>
                  <li><strong>Critical Patient & Nurse Dietary Education:</strong> Lithium is a monovalent cation handled by kidneys like sodium. <strong>Patients must maintain a consistent dietary sodium intake and drink 2.5 to 3 liters of fluid daily.</strong> Sodium depletion (dehydration, sweating, low-salt diet, diuretic use) causes kidneys to reabsorb lithium avidly, precipitating acute toxicity!</li>
                </ul>

                <p><strong>2. Comprehensive Nursing Care Plan for Manic Patient:</strong></p>
                <table class="clinical-table">
                  <thead>
                    <tr><th>Nursing Diagnosis</th><th>Goal</th><th>Interventions & Rationales</th><th>Evaluation</th></tr>
                  </thead>
                  <tbody>
                    <tr>
                      <td><strong>Imbalanced Nutrition: Less than Body Requirements</strong> r/t extreme hyperactivity and inability to sit for meals.</td>
                      <td>Maintain baseline weight and electrolyte balance during hospitalization.</td>
                      <td>
                        &bull; Provide <strong>High-Calorie, High-Protein "Finger Foods"</strong> (sandwiches, chicken wraps, fruit cutlets, cheese cubes) that can be eaten while pacing.<br>
                        &bull; Offer frequent high-protein liquid supplements and fresh juices throughout the day.<br>
                        &bull; Weigh patient daily at the same time.<br>
                        <em>Rationale:</em> Manic patients burn thousands of calories pacing and will not sit down to finish a traditional tray.
                      </td>
                      <td>Weight remains stable; fluid intake &gt;2500 mL/24h; normal skin turgor and electrolytes.</td>
                    </tr>
                    <tr>
                      <td><strong>Risk for Injury / Exhaustion</strong> r/t continuous motor hyperactivity and severe insomnia.</td>
                      <td>Experience 6–8 hours of uninterrupted rest per 24 hours without exhaustion.</td>
                      <td>
                        &bull; Maintain a low-stimulus environment: Private room, dimmed lighting, muted television, simple neutral walls.<br>
                        &bull; Avoid competitive group games (triggers intense arguments); provide non-competitive physical activities (walking, exercise bike).<br>
                        &bull; Establish a warm, relaxing bedtime routine; administer prescribed mood stabilizer and bedtime sedative (Lorazepam 2 mg or Olanzapine 10 mg).
                      </td>
                      <td>Sleeps 6–7 hours at night; vital signs within normal limits; absence of physical exhaustion.</td>
                    </tr>
                    <tr>
                      <td><strong>Impaired Social Interaction & Boundary Violations</strong> r/t grandiosity and disinhibited behavior.</td>
                      <td>Respect personal boundaries and communicate without hostility or manipulation.</td>
                      <td>
                        &bull; Set firm, calm, clear, and consistent behavioral limits: "You may not touch other patients. If you cannot keep your hands to yourself, you must return to your room."<br>
                        &bull; Do NOT laugh at jokes or bizarre behaviors (reinforces grandiosity).<br>
                        &bull; Protect patient's dignity: Guide them away from public view if wearing provocative or bizarre clothing.
                      </td>
                      <td>Interacts respectfully; accepts staff limits without aggressive outbursts; dresses appropriately.</td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </div>

      </div>
    </div>

    <!-- ------------------------------------------------------------ -->
    <!-- TOPIC 8: MENTAL STATUS EXAMINATION (MSE) (REPEATED IN '20 & '25) -->
    <!-- ------------------------------------------------------------ -->`},{id:`grp-mse`,title:`Mental Status Examination (MSE)`,repeatCount:2,years:[`2020`,`2025`],probability:80,priorityTier:`Tier 3 • High Yield`,tierClass:`tier-moderate`,subItems:[{concept:`Standard components: General appearance, motor behavior, speech & mood`,years:`2020, 2025`},{concept:`Thought process/content, perceptual disturbances & cognitive faculties`,years:`2020, 2025`},{concept:`6 grades of insight and clinical documentation protocols`,years:`2020, 2025`}],questions:[{paperBadge:`MPMSU Feb 2025 (Supp) Q.5a & Feb 2020 Q.3 [10 Marks]`,weight:`Repeated Examination | Target: 4 Handwritten Pages`,questionText:`a. Define Mental Status Examination (2) | b. Explain the detailed components of MSE with nursing documentation (8).`}],answerHtml:`<!-- QUESTION 1: FEB 2025 (SUPP) Q.5a & FEB 2020 Q.3 [10 MARKS] -->
        <div class="q-block">
          <div class="q-header">
            <span class="q-badge">MPMSU Feb 2025 (Supp) Q.5a & Feb 2020 Q.3 [10 Marks]</span>
            <span class="q-weight">Repeated Examination | Target: 4 Handwritten Pages</span>
          </div>
          <div class="q-text-prompt">
            <strong>Exam Question:</strong> a. Define Mental Status Examination (2) | b. Explain the detailed components of MSE with nursing documentation (8).
          </div>
          <div class="q-answer-content">
            <div class="ans-part">
              <div class="ans-part-title">Part (a): Definition of Mental Status Examination (MSE) (2 Marks)</div>
              <div class="ans-part-body">
                <p><strong>Mental Status Examination (MSE):</strong> The systematic, structured clinical assessment of an individual's current mental state, cognitive capacity, emotional functioning, and behavioral manifestations at the precise time of the clinical interview. Analogous to the physical examination in general medicine, it serves as the foundational objective diagnostic tool in psychiatric nursing and clinical psychiatry.</p>
              </div>
            </div>

            <div class="ans-part">
              <div class="ans-part-title">Part (b): Detailed Components of MSE with Clinical Nursing Documentation (8 Marks)</div>
              <div class="ans-part-body">
                <table class="clinical-table">
                  <thead>
                    <tr><th style="width: 25%;">MSE Component</th><th style="width: 45%;">Clinical Assessment Areas & Terminology</th><th style="width: 30%;">Sample Objective Nursing Documentation</th></tr>
                  </thead>
                  <tbody>
                    <tr>
                      <td><strong>1. General Appearance & Behavior</strong></td>
                      <td>Dress, grooming, hygiene, facial expression, posture, eye contact, gait, motor activity (retarded, agitated, catatonic, tremors, tics), attitude toward interviewer (cooperative, hostile, guarded, seductive).</td>
                      <td><em>"Patient is a 32-year-old male, disheveled, unkempt with body odor. Eye contact poor; seated with hunched shoulders. Cooperative but suspicious."</em></td>
                    </tr>
                    <tr>
                      <td><strong>2. Speech</strong></td>
                      <td>Rate (rapid/slow), volume (loud/soft), tone, pitch, coherence, spontaneity, pressure of speech (uninterruptible in mania), poverty of speech (alogia).</td>
                      <td><em>"Speech is rapid, pressured, and loud; difficult to interrupt. Rhyming and punning noted."</em></td>
                    </tr>
                    <tr>
                      <td><strong>3. Mood & Affect</strong></td>
                      <td>
                        &bull; <em>Mood (Sustained internal subjective state):</em> Depressed, euphoric, irritable, anxious, euthymic.<br>
                        &bull; <em>Affect (Objective observable emotional display):</em> Flat, blunted, constricted, labile, incongruent (smiling while describing murder).
                      </td>
                      <td><em>"Patient reports mood as 'terrific and powerful'. Affect is expansively euphoric and labile, incongruent with current hospitalization."</em></td>
                    </tr>
                    <tr>
                      <td><strong>4. Thought</strong></td>
                      <td>
                        &bull; <em>Stream / Form:</em> Flight of ideas, circumstantiality (reaches point after endless trivial details), tangentiality (never reaches point), loose associations, word salad, neologisms.<br>
                        &bull; <em>Content:</em> Delusions (persecutory, grandiose, somatic, erotomanic), obsessions, phobias, suicidal/homicidal ideation, ideas of reference.
                      </td>
                      <td><em>"Thought flow demonstrates marked circumstantiality. Thought content reveals persecutory delusions: believes intelligence agencies monitor cell phone."</em></td>
                    </tr>
                    <tr>
                      <td><strong>5. Perception</strong></td>
                      <td>
                        &bull; <em>Hallucinations (Sensory perception without external stimulus):</em> Auditory (most common in psychosis), visual (delirium), olfactory, gustatory, tactile (formication / cocaine bugs).<br>
                        &bull; <em>Illusions:</em> Misinterpretation of actual external stimulus (mistaking a rope for a snake).
                      </td>
                      <td><em>"Reports continuous second-person auditory hallucinations: 'The voice tells me to stay awake because enemies are coming'."</em></td>
                    </tr>
                    <tr>
                      <td><strong>6. Cognitive Functions</strong></td>
                      <td>
                        &bull; <em>Orientation:</em> Time, place, person.<br>
                        &bull; <em>Attention & Concentration:</em> Serial 7s subtraction or spelling "WORLD" backward.<br>
                        &bull; <em>Memory:</em> Immediate (repeat 3 digits), Recent (what did you eat for breakfast?), Remote (birth date, childhood events).<br>
                        &bull; <em>Abstract Thinking:</em> Proverb interpretation ("Don't cry over spilled milk") and similarities/differences (apple vs orange).
                      </td>
                      <td><em>"Oriented &times; 3. Concentration intact (completed serial 7s to 65). Abstract thinking impaired; gave concrete interpretation to proverbs."</em></td>
                    </tr>
                    <tr>
                      <td><strong>7. Judgment</strong></td>
                      <td>Ability to assess situation correctly and choose appropriate action.
                        <br>&bull; <em>Social Judgment:</em> Observation during interview.<br>&bull; <em>Test Judgment:</em> "What would you do if you saw smoke in a crowded cinema?"
                      </td>
                      <td><em>"Social judgment impaired; undressed in dayroom. Test judgment intact: stated would pull fire alarm and evacuate."</em></td>
                    </tr>
                    <tr>
                      <td><strong>8. Insight (6 Grades of Insight)</strong></td>
                      <td>Patient's awareness of having a psychiatric illness:
                        <br><strong>Grade 1:</strong> Complete denial of illness.
                        <br><strong>Grade 2:</strong> Slight awareness of being sick and needing help, but denies it at the same time.
                        <br><strong>Grade 3:</strong> Aware of illness, but blames external factors or organic causes.
                        <br><strong>Grade 4:</strong> Aware of illness and due to something unknown in self.
                        <br><strong>Grade 5 (Intellectual Insight):</strong> Admits illness and recognizes mental dysfunction, yet fails to apply knowledge to future lifestyle.
                        <br><strong>Grade 6 (True Emotional Insight):</strong> Full emotional awareness of illness; actively complies with treatment and changes behavior.
                      </td>
                      <td><em>"Insight is Grade 1: Patient vehemently denies psychiatric illness; states 'My family trapped me here because they want my property'."</em></td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </div>

      </div>
    </div>
  </div>

  <!-- ============================================================== -->
  <!-- 3. NURSING RESEARCH & STATISTICS                               -->
  <!-- ============================================================== -->`}]},chn:{id:`chn`,name:`Child Health Nursing`,shortName:`Child Health`,badge:`Pediatric Nursing`,code:`NTRUHS / MPMSU 3rd Year`,desc:`High-Risk Newborn & LBW, Nephrotic Syndrome, Growth Milestones, NIS & IMNCI`,icon:`user`,color:`#C084FC`,papers:[{year:`2025`,session:`Supplementary Examination`,title:`Child Health Nursing Feb 2025 (Supp) Question Paper`,file:`/pyqs/chn/chn-2025-supp.pdf`,date:`February 2025`,totalMarks:75,duration:`3 Hours`,badge:`Latest Exam Paper`},{year:`2022`,session:`Main & Supplementary`,title:`Child Health Nursing July 2022 (Main) Question Paper`,file:`/pyqs/chn/chn-2022-main.pdf`,date:`July 2022`,totalMarks:75,duration:`3 Hours`,badge:`Core Annual`},{year:`2020`,session:`Main Examination`,title:`Child Health Nursing Feb 2020 (Main) Question Paper`,file:`/pyqs/chn/chn-2020-main.pdf`,date:`February 2020`,totalMarks:75,duration:`3 Hours`,badge:`Core Annual`},{year:`2019`,session:`Main Examination`,title:`Child Health Nursing May 2019 (Main) Question Paper`,file:`/pyqs/chn/chn-2019-main.pdf`,date:`May 2019`,totalMarks:75,duration:`3 Hours`,badge:`Benchmark Paper`}],topics:[{id:`grp-lbw`,title:`High-Risk Newborn, Low Birth Weight (LBW) & Kangaroo Mother Care (KMC)`,repeatCount:4,years:[`2019`,`2020`,`2022`,`2025`],probability:98,priorityTier:`Tier 1 • Guaranteed`,tierClass:`tier-guaranteed`,subItems:[{concept:`Definitions: LBW (&lt;2500g), VLBW (&lt;1500g), ELBW (&lt;1000g), preterm vs SGA`,years:`2022, 2025`},{concept:`Physiological handicaps: Thermal instability, RDS/surfactant, IVH & NEC`,years:`2020, 2025`},{concept:`Kangaroo Mother Care (KMC): Skin-to-skin positioning, benefits & discharge criteria`,years:`2019, 2022, 2025`}],questions:[{paperBadge:`MPMSU Feb 2025 (Supp) — Q.1 [15 Marks]`,weight:`Full Long Essay | Target: 5 Handwritten Pages`,questionText:`a. Define Low Birth Weight (LBW) and Very Low Birth Weight (VLBW) infant (2) | b. Enlist the causes, physiological handicaps and risk factors of LBW neonates (5) | c. Discuss the management of LBW baby in NICU with emphasis on thermal control, feeding, infection prevention (4) | d. Explain Kangaroo Mother Care (KMC) - components, eligibility, benefits, and nurse's role (4).`}],answerHtml:`<!-- ======================================================== -->
        <!-- CATEGORIZED CLINICAL CONCEPTS & MEDICAL EXPLANATIONS     -->
        <!-- ======================================================== -->
        <div class="concept-category-title">Categorized Clinical Guide & Neonatology Breakdown</div>

        <!-- 1. NEONATAL THERMOREGULATION & PHYSIOLOGICAL HANDICAPS -->
        <div class="concept-card">
          <div class="concept-title">1. Neonatal Thermoregulation & Physiological Handicaps of LBW Infants</div>
          <div class="concept-body">
            <p><strong>Why Preterm / LBW Neonates Suffer Rapid Hypothermia:</strong> Neonates do not possess the physiological shivering mechanism. Thermal homeostasis relies exclusively on <em>Non-Shivering Thermogenesis</em> via sympathetic beta-3 receptor stimulation metabolizing Brown Adipose Tissue (BAT - situated in interscapular, perirenal, and mediastinal spaces). Preterm neonates possess minimal brown fat stores, lack insulating subcutaneous white fat, and have a massive surface-area-to-weight ratio. Hypothermia triggers pulmonary vasoconstriction, hypoxia, lactic acidosis, and lethal kernicterus.</p>
            <p><strong>Respiratory Distress Syndrome (RDS):</strong> Preterm infants delivered prior to 34 weeks suffer from severe deficiency of pulmonary surfactant (synthesized by type II alveolar pneumocytes). High surface tension leads to progressive end-expiratory alveolar collapse (atelectasis), severe ventilation-perfusion mismatch, intrapulmonary shunting, and formation of proteinaceous hyaline membranes.</p>
          </div>
        </div>

        <!-- 2. KMC CLINICAL PROTOCOL -->
        <div class="concept-card">
          <div class="concept-title">2. Kangaroo Mother Care (KMC) Clinical Protocol & Nursing Implementation</div>
          <div class="concept-body">
            <p>Kangaroo Mother Care is an evidence-based, low-cost, high-impact intervention for low birth weight (&lt;2500g) and preterm neonates that stabilizes vitals, maintains normothermia, and cuts neonatal sepsis by 50%:</p>
            
            <img src="/pyqs/images/kmc_clinical.jpg" class="med-img" alt="Kangaroo Mother Care (KMC) Clinical Positioning Protocol">
            
            <div class="img-notes">
              <strong>Core Components of Kangaroo Mother Care (WHO Standards):</strong>
              <br>&bull; <strong>1. KMC Positioning:</strong> Neonate is held upright vertically between maternal breasts in direct skin-to-skin contact. The infant's head is turned to one side with the neck slightly extended (sniffing position) to maintain a fully patent airway and facilitate face-to-face maternal-infant eye contact. The hips and knees are held in a flexed, abducted "frog-like" position; the arms are gently flexed over the chest. The neonate wears only a cap, socks, and a diaper to maximize skin contact area. A secure, supportive elasticized or cotton cloth binder wraps around the mother's torso, firmly supporting the baby's body without impeding chest wall excursion.
              <br>&bull; <strong>2. KMC Nutrition:</strong> Continuous exclusive breastfeeding. The mother is assisted with direct on-demand breastfeeding every 2 hours or expression of colostrum/breast milk fed via paladai, cup, or spoon if suck-swallow coordination is immature.
              <br>&bull; <strong>3. Clinical Benefits:</strong> Prevents neonatal hypothermia via conduction from mother's maternal thermoregulatory core; stabilizes heart rate and oxygen saturation (SpO2); reduces apnea of prematurity; fosters deep quiet sleep stages; stimulates neurodevelopment; accelerates daily weight gain (&gt;15–20 g/kg/day); and reduces hospital-acquired neonatal sepsis by 50% and mortality by 40%.
            </div>
          </div>
        </div>

        <!-- ======================================================== -->
        <!-- SECTION B: PAST UNIVERSITY EXAM QUESTIONS & ANSWERS      -->
        <!-- ======================================================== -->
        <div class="section-divider-title">Exact University Exam Questions & 2–5 Page Model Answers</div>

        <!-- QUESTION 1: FEB 2025 (SUPP) Q.1 [15 MARKS] -->
        <div class="q-block">
          <div class="q-header">
            <span class="q-badge">MPMSU Feb 2025 (Supp) — Q.1 [15 Marks]</span>
            <span class="q-weight">Full Long Essay | Target: 5 Handwritten Pages</span>
          </div>
          <div class="q-text-prompt">
            <strong>Exam Question:</strong> a. Define Low Birth Weight (LBW) and Very Low Birth Weight (VLBW) infant (2) | b. Enlist the causes, physiological handicaps and risk factors of LBW neonates (5) | c. Discuss the management of LBW baby in NICU with emphasis on thermal control, feeding, infection prevention (4) | d. Explain Kangaroo Mother Care (KMC) - components, eligibility, benefits, and nurse's role (4).
          </div>
          <div class="q-answer-content">
            <div class="ans-part">
              <div class="ans-part-title">Part (a): Definitions of LBW, VLBW, and ELBW (2 Marks)</div>
              <div class="ans-part-body">
                <p>Standard World Health Organization (WHO) neonatal weight classifications:</p>
                <ul>
                  <li><strong>Low Birth Weight (LBW):</strong> A neonate whose birth weight is <strong>less than 2,500 grams (&lt;2.5 kg)</strong>, measured within the first hour of life, regardless of gestational age.</li>
                  <li><strong>Very Low Birth Weight (VLBW):</strong> A birth weight <strong>less than 1,500 grams (&lt;1.5 kg)</strong>.</li>
                  <li><strong>Extremely Low Birth Weight (ELBW):</strong> A birth weight <strong>less than 1,000 grams (&lt;1.0 kg)</strong>.</li>
                </ul>
              </div>
            </div>

            <div class="ans-part">
              <div class="ans-part-title">Part (b): Causes, Risk Factors & Physiological Handicaps (5 Marks)</div>
              <div class="ans-part-body">
                <p><strong>Causes & Maternal Risk Factors:</strong></p>
                <ul>
                  <li><em>Maternal Factors:</em> Severe anemia (Hb &lt;7 g/dL), pre-eclampsia / eclampsia, gestational hypertension, maternal malnutrition, adolescent pregnancy (&lt;18 yrs) or grand multiparity, chronic intrauterine infections (TORCH).</li>
                  <li><em>Fetal & Placental Factors:</em> Multiple gestation (twins, triplets), congenital chromosomal anomalies, placental abruption, placenta previa, placental insufficiency.</li>
                </ul>

                <p><strong>Physiological Handicaps of the LBW / Preterm Neonate:</strong></p>
                <table class="clinical-table">
                  <thead>
                    <tr><th>Organ System</th><th>Immature Anatomical Feature</th><th>Clinical Pathological Hazard</th></tr>
                  </thead>
                  <tbody>
                    <tr>
                      <td><strong>Thermoregulation</strong></td>
                      <td>Deficient brown adipose tissue (BAT); high surface-area-to-body-mass ratio; thin permeable skin; lack of subcutaneous insulating fat; inability to shiver.</td>
                      <td><strong>Rapid Hypothermia ("Cold Stress")</strong>, leading to pulmonary vasoconstriction, hypoxia, metabolic acidosis, and hypoglycemia.</td>
                    </tr>
                    <tr>
                      <td><strong>Respiratory System</strong></td>
                      <td>Deficiency of pulmonary surfactant (dipalmitoylphosphatidylcholine) synthesized by Type II pneumocytes; weak thoracic cage ribs.</td>
                      <td><strong>Respiratory Distress Syndrome (RDS / Hyaline Membrane Disease)</strong>, alveolar atelectasis, apnea of prematurity (cessation of breathing &gt;20 sec with bradycardia).</td>
                    </tr>
                    <tr>
                      <td><strong>Gastrointestinal & Metabolic</strong></td>
                      <td>Uncoordinated suck-swallow-breathing reflex (matures at 34 weeks); low gastric capacity; diminished lactase/lipase enzymes; minimal hepatic glycogen stores.</td>
                      <td>Aspiration pneumonia, <strong>Necrotizing Enterocolitis (NEC)</strong>, acute severe <strong>Hypoglycemia (blood glucose &lt;40 mg/dL)</strong>.</td>
                    </tr>
                    <tr>
                      <td><strong>Neurological & Vascular</strong></td>
                      <td>Fragile, highly vascularized subependymal germinal matrix with poor capillary basement membrane support.</td>
                      <td><strong>Intraventricular Hemorrhage (IVH)</strong> precipitated by rapid BP fluctuations or rapid hypertonic saline flushes.</td>
                    </tr>
                    <tr>
                      <td><strong>Immunological</strong></td>
                      <td>Deficient transplacental IgG transfer (occurs mainly after 32–34 weeks); low complement levels; impaired neutrophil phagocytosis.</td>
                      <td>Extreme vulnerability to fulminant <strong>Neonatal Sepsis</strong> and bacterial meningitis.</td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>

            <div class="ans-part">
              <div class="ans-part-title">Part (c): NICU Clinical Management (Thermal, Feeding, Infection Control) (4 Marks)</div>
              <div class="ans-part-body">
                <ul>
                  <li><strong>1. Thermal Control (Warm Chain):</strong>
                    <ul>
                      <li>Place neonate under a Servo-controlled Radiant Warmer or double-walled Incubator with a skin probe attached to the right hypochondrium (target abdominal skin temperature: <strong>36.5°C to 37.5°C</strong>).</li>
                      <li>Dress in cap, woolen socks, and mitten cuffs (head accounts for 25% of heat loss). Maintain delivery room temperature at 25–28°C.</li>
                    </ul>
                  </li>
                  <li><strong>2. Enteral & Parenteral Nutrition:</strong>
                    <ul>
                      <li><em>Neonate &lt;32–34 weeks:</em> Absent/uncoordinated suck-swallow reflex &rarr; Feed via <strong>Orogastric (OG) Tube</strong> using expressed breast milk (EBM). (Orogastric is preferred over nasogastric because neonates are obligate nose breathers).</li>
                      <li><em>Neonate &ge;34 weeks:</em> Feed using sterile Paladai / cup and spoon or direct breastfeeding.</li>
                      <li>Initiate minimal enteral nutrition (trophic feeding) with maternal colostrum (rich in secretory IgA, protects against NEC).</li>
                    </ul>
                  </li>
                  <li><strong>3. Infection Control & Sepsis Prevention:</strong>
                    <ul>
                      <li>Strict 2-minute surgical handwashing with chlorhexidine before touching any neonate.</li>
                      <li>Strict "Aseptic Non-Touch Technique" (ANTT) for all vascular lines and procedures; dedicated stethoscopes and thermometers per incubator.</li>
                    </ul>
                  </li>
                </ul>
              </div>
            </div>

            <div class="ans-part">
              <div class="ans-part-title">Part (d): Kangaroo Mother Care (KMC) in Detail (4 Marks)</div>
              <div class="ans-part-body">
                <p><strong>Definition:</strong> A low-cost, high-impact evidence-based method of care for LBW and preterm infants based on continuous skin-to-skin contact between mother and baby, coupled with exclusive breastfeeding.</p>
                <p><strong>2 Core Components of KMC:</strong></p>
                <ol>
                  <li><strong>Kangaroo Position (Skin-to-Skin):</strong> Neonate is placed naked (except for diaper, cap, and warm socks) upright in a vertical "frog-like" position between the mother's bare breasts, chest-to-chest. The baby's head is turned sideways in a slightly extended position to keep the airway patent. Secured with a KMC binder / wrapper.</li>
                  <li><strong>Kangaroo Nutrition:</strong> Exclusive and frequent on-demand breastfeeding or cup-feeding with expressed breast milk.</li>
                </ol>
                <p><strong>Eligibility & Benefits:</strong></p>
                <ul>
                  <li><em>Eligibility:</em> All stable LBW babies (&lt;2.5 kg). Hemodynamically stable babies can receive KMC even while on oxygen or IV fluids.</li>
                  <li><em>Benefits:</em> Prevents hypothermia (maternal chest acts as natural thermal incubator); stabilizes heart rate and respirations; promotes neurodevelopment and deep quiet sleep; increases maternal milk output; shortens NICU stay.</li>
                  <li><em>Duration:</em> Minimum duration of a single KMC session should be <strong>at least 1 hour</strong> (avoids frequent handling disturbances); can be practiced up to 24 hours daily.</li>
                </ul>
              </div>
            </div>
          </div>
        </div>

      </div>
    </div>

    <!-- ------------------------------------------------------------ -->
    <!-- TOPIC 2: NEPHROTIC SYNDROME IN CHILDREN (REPEATED 3/4)       -->
    <!-- ------------------------------------------------------------ -->`},{id:`grp-nephrotic`,title:`Nephrotic Syndrome in Children`,repeatCount:3,years:[`2020`,`2022`,`2025`],probability:90,priorityTier:`Tier 2 • Very High`,tierClass:`tier-high`,subItems:[{concept:`Minimal Change Nephrotic Syndrome (MCNS), classic clinical triad & anasarca`,years:`2022, 2025`},{concept:`Steroid therapy: Prednisolone protocols, steroid dependence & complications`,years:`2022, 2025`},{concept:`Comprehensive Nursing Care Plan: Fluid restriction, low sodium diet & daily dipstick`,years:`2020, 2022, 2025`}],questions:[{paperBadge:`MPMSU Feb 2025 (Supp) Q.2 & July 2022 Q.2 [15 Marks]`,weight:`Full Long Essay | Target: 5 Handwritten Pages`,questionText:`a. Define Nephrotic Syndrome (2) | b. Explain the pathophysiology and classic clinical triad (5) | c. Discuss medical management (Corticosteroid therapy) and complications (3) | d. Draw a comprehensive Nursing Care Plan for a child with Nephrotic Syndrome (5).`}],answerHtml:`<!-- QUESTION 1: FEB 2025 (SUPP) Q.2 & JULY 2022 Q.2 [15 MARKS - IDENTICAL ESSAY] -->
        <div class="q-block">
          <div class="q-header">
            <span class="q-badge">MPMSU Feb 2025 (Supp) Q.2 & July 2022 Q.2 [15 Marks]</span>
            <span class="q-weight">Full Long Essay | Target: 5 Handwritten Pages</span>
          </div>
          <div class="q-text-prompt">
            <strong>Exam Question:</strong> a. Define Nephrotic Syndrome (2) | b. Explain the pathophysiology and classic clinical triad (5) | c. Discuss medical management (Corticosteroid therapy) and complications (3) | d. Draw a comprehensive Nursing Care Plan for a child with Nephrotic Syndrome (5).
          </div>
          <div class="q-answer-content">
            <div class="ans-part">
              <div class="ans-part-title">Part (a): Definition of Nephrotic Syndrome (2 Marks)</div>
              <div class="ans-part-body">
                <p><strong>Nephrotic Syndrome (Minimal Change Disease - MCNS):</strong> A clinical syndrome resulting from increased glomerular basement membrane (GBM) permeability to plasma proteins, characterized by the <strong>Classic Clinical Tetrad: Massive Proteinuria (&gt;40 mg/m2/hr or urine protein-to-creatinine ratio &gt;2), Hypoalbuminemia (&lt;2.5 g/dL), Generalized Edema (Anasarca), and Hyperlipidemia (Serum cholesterol &gt;200 mg/dL)</strong>, occurring predominantly in children aged 2 to 6 years.</p>
              </div>
            </div>

            <div class="ans-part">
              <div class="ans-part-title">Part (b): Pathophysiology & Clinical Manifestations (5 Marks)</div>
              <div class="ans-part-body">
                <p><strong>Pathophysiological Mechanism:</strong></p>
                <div class="callout">
                  T-cell immune dysfunction &rarr; Release of circulating permeability factors &rarr; Loss of negatively charged heparan sulfate proteoglycans on the Glomerular Basement Membrane (GBM) &rarr; Massive leakage of albumin into urine (<strong>Selective Albuminuria / Proteinuria 3+ to 4+</strong>) &rarr; Profound decline in serum albumin (<strong>Hypoalbuminemia</strong>) &rarr; Drop in plasma colloid oncotic pressure &rarr; Extravasation of fluid into interstitial spaces &rarr; <strong>Generalized Edema / Anasarca</strong>.<br><br>
                  <em>Secondary Cascade:</em> Intravascular volume depletion stimulates renal baroreceptors &rarr; Activation of RAAS and ADH &rarr; Avid renal sodium and water reabsorption &rarr; Worsening edema. Compensatory hepatic lipid synthesis causes <strong>Hypercholesterolemia</strong>.
                </div>

                <p><strong>Clinical Manifestations:</strong></p>
                <ul>
                  <li><strong>Insidious Edema:</strong> Initially noted as morning <em>Periorbital Puffiness / Facial Edema</em>; progresses during the day to dependent pitting edema of lower limbs, swollen scrotum/labia, ascites, and pleural effusion (generalized anasarca).</li>
                  <li><strong>Urinary Changes:</strong> Scanty, dark, frothy/foamy urine (froth caused by high protein content).</li>
                  <li><strong>Gastrointestinal:</strong> Anorexia, abdominal pain (due to mesenteric ascites or peritonitis), diarrhea (intestinal wall edema).</li>
                  <li><strong>Skin:</strong> Pallor, prominent abdominal veins, striae, shiny stretched skin.</li>
                </ul>
              </div>
            </div>

            <div class="ans-part">
              <div class="ans-part-title">Part (c): Medical Management (Corticosteroid Protocol) & Complications (3 Marks)</div>
              <div class="ans-part-body">
                <p><strong>1. First-Line Corticosteroid Therapy (ISPN Protocol):</strong></p>
                <ul>
                  <li><strong>Prednisolone:</strong> <strong>2 mg/kg/day (or 60 mg/m2/day, max 60 mg/day)</strong> as a single morning dose for <strong>6 weeks</strong> continuously.</li>
                  <li>Followed by: <strong>1.5 mg/kg (or 40 mg/m2) on Alternate Days</strong> for another <strong>6 weeks</strong>, then tapered gradually over 4–8 weeks.</li>
                  <li><em>Response Criteria:</em> Complete remission defined as urine protein trace or nil for 3 consecutive days on dipstick.</li>
                </ul>

                <p><strong>2. Major Clinical Complications:</strong></p>
                <ul>
                  <li><strong>Life-Threatening Infections (Primary Sepsis / Spontaneous Bacterial Peritonitis):</strong> Loss of urinary immunoglobulins (IgG) and complement factor B; <em>Streptococcus pneumoniae</em> is the chief pathogen.</li>
                  <li><strong>Thromboembolism (DVT, Renal Vein Thrombosis, Pulmonary Embolism):</strong> Urinary loss of Antithrombin III and Protein C/S combined with hemoconcentration and hepatic synthesis of fibrinogen.</li>
                  <li><strong>Hypovolemic Shock:</strong> Sudden fluid shifting into third spaces during severe disease or overzealous diuretic administration.</li>
                  <li><strong>Cushingoid Steroid Side Effects:</strong> Moon facies, buffalo hump, stunted linear growth, osteoporosis, cataracts, hypertension.</li>
                </ul>
              </div>
            </div>

            <div class="ans-part">
              <div class="ans-part-title">Part (d): Comprehensive Nursing Care Plan for Child with Nephrotic Syndrome (5 Marks)</div>
              <div class="ans-part-body">
                <table class="clinical-table">
                  <thead>
                    <tr><th>Nursing Diagnosis</th><th>Goal</th><th>Interventions & Therapeutic Rationales</th><th>Evaluation</th></tr>
                  </thead>
                  <tbody>
                    <tr>
                      <td><strong>Excess Fluid Volume</strong> r/t hypoalbuminemia, decreased oncotic pressure, and sodium retention.</td>
                      <td>Show reduction in edema and maintain stable fluid balance without intravascular depletion.</td>
                      <td>
                        &bull; Weigh child daily at the same time (morning, after voiding, wearing identical clothing) on a calibrated scale.<br>
                        &bull; Measure abdominal girth daily at the level of the umbilicus.<br>
                        &bull; Record strict intake and output (I&O) balance.<br>
                        &bull; Diet: <strong>Low Sodium Diet (No added salt)</strong> during active edematous phase; normal protein intake (high protein diets are contraindicated as they accelerate glomerular damage).<br>
                        &bull; Test first-voided morning urine daily using Albustix / dipstick for protein and record results (0, Trace, 1+, 2+, 3+, 4+).
                      </td>
                      <td>Abdominal girth reduced by 4 cm; weight decreased by 1.2 kg; urine protein drops to Trace/Nil.</td>
                    </tr>
                    <tr>
                      <td><strong>High Risk for Infection</strong> r/t loss of gamma globulins and immunosuppressive corticosteroid therapy.</td>
                      <td>Remain free from bacterial peritonitis, cellulitis, and respiratory infections.</td>
                      <td>
                        &bull; Protect from infectious contacts: Nurse in single room or place away from infected children; restrict visitors with URI.<br>
                        &bull; Monitor temperature q4h; observe for subtle signs of peritonitis (fever, diffuse abdominal tenderness, guarding).<br>
                        &bull; Strict hand hygiene before all patient care.<br>
                        &bull; Administer Pneumococcal conjugate and polysaccharide vaccines during remission.<br>
                        <em>STRICT VACCINE RULE:</em> <strong>AVOID LIVE VACCINES (MMR, Varicella, OPV)</strong> while receiving high-dose steroid therapy.
                      </td>
                      <td>Afebrile; abdomen soft and non-tender; WBC within normal pediatric limits; absence of infection.</td>
                    </tr>
                    <tr>
                      <td><strong>Risk for Impaired Skin Integrity</strong> r/t massive dependent edema and poor tissue perfusion.</td>
                      <td>Maintain intact skin over edematous areas (scrotum, sacrum, eyelids).</td>
                      <td>
                        &bull; Support edematous scrotum with a rolled towel or scrotal support sling.<br>
                        &bull; Turn and reposition the child every 2 hours; use pressure-relieving mattress.<br>
                        &bull; Cleanse skin folds gently; avoid adhesive tapes on fragile edematous skin.
                      </td>
                      <td>Skin intact throughout; absence of redness, breakdown, or skin fissures.</td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </div>

      </div>
    </div>

    <!-- ------------------------------------------------------------ -->
    <!-- TOPIC 3: GROWTH & DEVELOPMENT & MILESTONES (REPEATED 3/4)   -->
    <!-- ------------------------------------------------------------ -->`},{id:`grp-growth`,title:`Growth & Development (Principles, Factors & Milestones)`,repeatCount:3,years:[`2019`,`2020`,`2022`],probability:90,priorityTier:`Tier 2 • Very High`,tierClass:`tier-high`,subItems:[{concept:`Definitions, cephalocaudal/proximodistal directions & principles`,years:`2020, 2022`},{concept:`Infant developmental milestones across motor, sensory, language & social domains`,years:`2020`},{concept:`Piaget's stages of cognitive development & pediatric nursing implications`,years:`2019`}],questions:[{paperBadge:`MPMSU Feb 2020 (Main) — Q.2 [15 Marks]`,weight:`Full Long Essay | Target: 5 Handwritten Pages`,questionText:`a. Define Growth and Development (2) | b. Explain the principles of growth and development (5) | c. Describe the developmental milestones of an infant (0-1 year) in motor, sensory, social and language domains (8).`}],answerHtml:`<!-- QUESTION 1: FEB 2020 (MAIN) Q.2 [15 MARKS] -->
        <div class="q-block">
          <div class="q-header">
            <span class="q-badge">MPMSU Feb 2020 (Main) — Q.2 [15 Marks]</span>
            <span class="q-weight">Full Long Essay | Target: 5 Handwritten Pages</span>
          </div>
          <div class="q-text-prompt">
            <strong>Exam Question:</strong> a. Define Growth and Development (2) | b. Explain the principles of growth and development (5) | c. Describe the developmental milestones of an infant (0-1 year) in motor, sensory, social and language domains (8).
          </div>
          <div class="q-answer-content">
            <div class="ans-part">
              <div class="ans-part-title">Part (a): Definitions of Growth & Development (2 Marks)</div>
              <div class="ans-part-body">
                <p><strong>Growth:</strong> An increase in the physical size, mass, and dimension of the body or its constituent organs, resulting from cellular multiplication (hyperplasia) and cellular enlargement (hypertrophy). It is quantitative and objectively measurable in centimeters, kilograms, and percentiles.</p>
                <p><strong>Development:</strong> A progressive, orderly maturation of physiological, neuromuscular, cognitive, and psychosocial functions and skills. It is qualitative, reflecting increased complexity of behavioral capacity and neurodevelopmental integration.</p>
              </div>
            </div>

            <div class="ans-part">
              <div class="ans-part-title">Part (b): Principles of Growth and Development (5 Marks)</div>
              <div class="ans-part-body">
                <ol>
                  <li><strong>1. Directional Trends:</strong>
                    <ul>
                      <li><em>Cephalocaudal (Head-to-Tail):</em> Neuromuscular control develops from the head downward (head control achieved at 3 months, sitting at 6–8 months, walking at 12–15 months).</li>
                      <li><em>Proximodistal (Near-to-Far):</em> Development proceeds from the central axis outward toward extremities (shoulder control precedes hand grasps; whole arm swiping precedes fine pincer grasp).</li>
                      <li><em>Differentiation:</em> Progression from simple, generalized gross responses to complex, refined, specific motor acts.</li>
                    </ul>
                  </li>
                  <li><strong>2. Continuous but Non-Linear Process:</strong> Growth is continuous from conception to maturity, but proceeds at varying speeds (infancy and adolescence are periods of rapid "growth spurts", whereas preschool and school-age are periods of steady slow growth).</li>
                  <li><strong>3. Individualized Rates:</strong> Every child grows at their own unique biological pace; wide normal developmental ranges exist.</li>
                  <li><strong>4. Predictable & Sequential Order:</strong> The sequence of developmental stages is universal and invariant (e.g., sitting always precedes crawling; crawling precedes walking).</li>
                  <li><strong>5. Interrelated Domains:</strong> Physical, motor, cognitive, social, and emotional domains mutually influence each other.</li>
                </ol>
              </div>
            </div>

            <div class="ans-part">
              <div class="ans-part-title">Part (c): Developmental Milestones of Infant (0 to 1 Year) (8 Marks)</div>
              <div class="ans-part-body">
                <table class="clinical-table">
                  <thead>
                    <tr><th>Age</th><th>Gross Motor Domain</th><th>Fine Motor Domain</th><th>Language & Social Domains</th></tr>
                  </thead>
                  <tbody>
                    <tr>
                      <td><strong>3 Months</strong></td>
                      <td><strong>Complete Head Holding / Control</strong> when pulled to sit; lifts head and chest 90° in prone position.</td>
                      <td>Hands open loosely; holds rattle momentarily when placed in hand.</td>
                      <td>Coos, laughs aloud, chuckles; <strong>Social Smile</strong> appears in response to mother's voice.</td>
                    </tr>
                    <tr>
                      <td><strong>6 Months</strong></td>
                      <td><strong>Rolls over from prone to supine</strong> and supine to prone; sits with pelvic support (tripod fashion).</td>
                      <td>Palmar grasp of objects; transfers objects from hand to hand; reaches for dangling toy.</td>
                      <td>Monosyllabic babbling ("ba-ba", "da-da"); smiles at own mirror image; recognizes mother.</td>
                    </tr>
                    <tr>
                      <td><strong>9 Months</strong></td>
                      <td><strong>Sits steadily without any support</strong>; pulls self up to a standing position holding furniture.</td>
                      <td>Immature / Crude Pincer Grasp (between thumb and index finger pad); drops objects voluntarily.</td>
                      <td>Bisyllabic babbling; waves "bye-bye"; plays "peek-a-boo"; shows <strong>Stranger Anxiety</strong>.</td>
                    </tr>
                    <tr>
                      <td><strong>12 Months (1 Year)</strong></td>
                      <td><strong>Walks with one hand held</strong> or takes first independent steps; stands alone briefly.</td>
                      <td><strong>Mature / Fine Pincer Grasp</strong> (picks up small raisin/pellet neatly between tips of thumb and index finger).</td>
                      <td>Says 1–2 words with meaning ("Mama", "Dada"); understands simple verbal commands ("Come here").</td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </div>

      </div>
    </div>

    <!-- ------------------------------------------------------------ -->
    <!-- TOPIC 4: NATIONAL IMMUNIZATION SCHEDULE & COLD CHAIN (3/4)  -->
    <!-- ------------------------------------------------------------ -->`},{id:`grp-nis`,title:`National Immunization Schedule (NIS) & Cold Chain System`,repeatCount:3,years:[`2019`,`2022`,`2025`],probability:90,priorityTier:`Tier 2 • Very High`,tierClass:`tier-high`,subItems:[{concept:`Complete National Immunization Schedule of India from birth to 16 years`,years:`2022, 2025`},{concept:`Cold chain system: Temperature maintenance (+2°C to +8°C), ILR, deep freezer`,years:`2019, 2025`},{concept:`Vaccine Vial Monitor (VVM) stages, Shake Test & AEFI surveillance`,years:`2022, 2025`}],questions:[{paperBadge:`MPMSU Feb 2025 (Supp) — Q.4 [10 Marks]`,weight:`Full Essay | Target: 4–5 Handwritten Pages`,questionText:`a. Write the latest National Immunization Schedule (NIS) of India from birth to 16 years with dose, route, site and age (6) | b. Discuss the Cold Chain equipment, temperature maintenance (+2°C to +8°C), and vaccine vial monitor (VVM) stages (4).`}],answerHtml:`<!-- QUESTION 1: FEB 2025 (SUPP) Q.4 [10 MARKS] -->
        <div class="q-block">
          <div class="q-header">
            <span class="q-badge">MPMSU Feb 2025 (Supp) — Q.4 [10 Marks]</span>
            <span class="q-weight">Full Essay | Target: 4–5 Handwritten Pages</span>
          </div>
          <div class="q-text-prompt">
            <strong>Exam Question:</strong> a. Write the latest National Immunization Schedule (NIS) of India from birth to 16 years with dose, route, site and age (6) | b. Discuss the Cold Chain equipment, temperature maintenance (+2°C to +8°C), and vaccine vial monitor (VVM) stages (4).
          </div>
          <div class="q-answer-content">
            <div class="ans-part">
              <div class="ans-part-title">Part (a): Complete National Immunization Schedule (NIS - India) (6 Marks)</div>
              <div class="ans-part-body">
                <table class="clinical-table">
                  <thead>
                    <tr><th>Age</th><th>Vaccine</th><th>Dose</th><th>Route</th><th>Anatomical Site</th></tr>
                  </thead>
                  <tbody>
                    <tr>
                      <td rowspan="3"><strong>At Birth</strong></td>
                      <td><strong>BCG</strong></td>
                      <td>0.05 mL (0.1 mL after 1 mo)</td>
                      <td>Intradermal (ID)</td>
                      <td>Left Upper Arm (deltoid insertion)</td>
                    </tr>
                    <tr><td><strong>OPV (Zero Dose)</strong></td><td>2 drops</td><td>Oral (PO)</td><td>Mouth</td></tr>
                    <tr><td><strong>Hepatitis B (Birth dose)</strong></td><td>0.5 mL</td><td>Intramuscular (IM)</td><td>Anterolateral aspect of mid-thigh (Left)</td></tr>
                    <tr>
                      <td rowspan="5"><strong>6 Weeks</strong></td>
                      <td><strong>Pentavalent-1 (DPT+HepB+Hib)</strong></td>
                      <td>0.5 mL</td>
                      <td>Intramuscular (IM)</td>
                      <td>Anterolateral aspect of mid-thigh (Left)</td>
                    </tr>
                    <tr><td><strong>OPV-1</strong></td><td>2 drops</td><td>Oral (PO)</td><td>Mouth</td></tr>
                    <tr><td><strong>Rotavirus-1 (RVV)</strong></td><td>5 drops (or 2.5 mL per brand)</td><td>Oral (PO)</td><td>Mouth</td></tr>
                    <tr><td><strong>fIPV-1 (Fractional IPV)</strong></td><td>0.1 mL</td><td>Intradermal (ID)</td><td>Right Upper Arm (deltoid)</td></tr>
                    <tr><td><strong>PCV-1 (Pneumococcal)</strong></td><td>0.5 mL</td><td>Intramuscular (IM)</td><td>Anterolateral mid-thigh (Right)</td></tr>
                    <tr>
                      <td rowspan="3"><strong>10 Weeks</strong></td>
                      <td><strong>Pentavalent-2</strong></td><td>0.5 mL</td><td>Intramuscular (IM)</td><td>Anterolateral mid-thigh (Left)</td></tr>
                    <tr><td><strong>OPV-2</strong></td><td>2 drops</td><td>Oral (PO)</td><td>Mouth</td></tr>
                    <tr><td><strong>Rotavirus-2</strong></td><td>5 drops</td><td>Oral (PO)</td><td>Mouth</td></tr>
                    <tr>
                      <td rowspan="5"><strong>14 Weeks</strong></td>
                      <td><strong>Pentavalent-3</strong></td><td>0.5 mL</td><td>Intramuscular (IM)</td><td>Anterolateral mid-thigh (Left)</td></tr>
                    <tr><td><strong>OPV-3</strong></td><td>2 drops</td><td>Oral (PO)</td><td>Mouth</td></tr>
                    <tr><td><strong>Rotavirus-3</strong></td><td>5 drops</td><td>Oral (PO)</td><td>Mouth</td></tr>
                    <tr><td><strong>fIPV-2</strong></td><td>0.1 mL</td><td>Intradermal (ID)</td><td>Right Upper Arm</td></tr>
                    <tr><td><strong>PCV-2</strong></td><td>0.5 mL</td><td>Intramuscular (IM)</td><td>Anterolateral mid-thigh (Right)</td></tr>
                    <tr>
                      <td rowspan="4"><strong>9–12 Months</strong></td>
                      <td><strong>MR-1 (Measles-Rubella)</strong></td><td>0.5 mL</td><td>Subcutaneous (SC)</td><td>Right Upper Arm</td></tr>
                    <tr><td><strong>JE-1 (Japanese Encephalitis)*</strong></td><td>0.5 mL</td><td>Subcutaneous (SC)</td><td>Left Upper Arm (*in endemic districts)</td></tr>
                    <tr><td><strong>PCV-Booster</strong></td><td>0.5 mL</td><td>Intramuscular (IM)</td><td>Anterolateral mid-thigh (Right)</td></tr>
                    <tr><td><strong>Vitamin A (1st Dose)</strong></td><td>1 mL (1 Lakh IU)</td><td>Oral (PO)</td><td>Mouth (with spoon)</td></tr>
                    <tr>
                      <td rowspan="4"><strong>16–24 Months</strong></td>
                      <td><strong>MR-2</strong></td><td>0.5 mL</td><td>Subcutaneous (SC)</td><td>Right Upper Arm</td></tr>
                    <tr><td><strong>JE-2*</strong></td><td>0.5 mL</td><td>Subcutaneous (SC)</td><td>Left Upper Arm</td></tr>
                    <tr><td><strong>DPT Booster-1</strong></td><td>0.5 mL</td><td>Intramuscular (IM)</td><td>Anterolateral mid-thigh (Left)</td></tr>
                    <tr><td><strong>OPV Booster</strong></td><td>2 drops</td><td>Oral (PO)</td><td>Mouth</td></tr>
                    <tr><td><strong>5–6 Years</strong></td><td><strong>DPT Booster-2</strong></td><td>0.5 mL</td><td>Intramuscular (IM)</td><td>Upper Arm (deltoid)</td></tr>
                    <tr><td><strong>10 & 16 Years</strong></td><td><strong>Td (Tetanus & adult Diphtheria)</strong></td><td>0.5 mL</td><td>Intramuscular (IM)</td><td>Upper Arm (deltoid)</td></tr>
                  </tbody>
                </table>
              </div>
            </div>

            <div class="ans-part">
              <div class="ans-part-title">Part (b): Cold Chain System, Temperature & VVM Stages (4 Marks)</div>
              <div class="ans-part-body">
                <p><strong>Definition:</strong> The Cold Chain is a system of transporting and storing vaccines at recommended temperatures from the point of manufacture to the point of administration to preserve immunological potency.</p>

                <p><strong>1. Temperature Standards & Equipment:</strong></p>
                <ul>
                  <li><strong>Standard Storage Temperature:</strong> <strong>+2°C to +8°C</strong> for all non-freezable vaccines.</li>
                  <li><strong>Ice-Lined Refrigerator (ILR):</strong> The backbone of cold chain at PHC/CHC level. Can maintain safe temperature for 24–48 hours during power cuts.
                    <br><em>Vaccine Arrangement in ILR:</em> Heat-sensitive vaccines (OPV, Rotavirus, MR) stored in the lower bottom basket; Freeze-sensitive vaccines (Pentavalent, DPT, TT, Hepatitis B) stored in upper sections away from walls.</li>
                  <li><strong>Deep Freezer (-15°C to -25°C):</strong> Used strictly for freezing water packs and storing OPV at district stores. <em>Never put Pentavalent, Hep B, or DPT in deep freezer!</em> (Freezing permanently denatures alum adjuvant).</li>
                </ul>

                <p><strong>2. Vaccine Vial Monitor (VVM) Stages:</strong></p>
                <div class="callout">
                  A heat-sensitive chemical label on the vaccine vial consisting of an outer circle and an inner square:
                  <br>&bull; <strong>Stage 1 (Usable):</strong> Inner square is significantly LIGHTER than outer circle. &rarr; <em>USE VACCINE.</em>
                  <br>&bull; <strong>Stage 2 (Usable):</strong> Inner square is still LIGHTER than outer circle, but slightly darker than stage 1. &rarr; <em>USE VACCINE FIRST.</em>
                  <br>&bull; <strong>Stage 3 (Discard!):</strong> Inner square matches the color of the outer circle. &rarr; <em>DO NOT USE! DISCARD IMMEDIATELY!</em>
                  <br>&bull; <strong>Stage 4 (Discard!):</strong> Inner square is DARKER than the outer circle. &rarr; <em>DO NOT USE! DISCARD IMMEDIATELY!</em>
                </div>

                <p><strong>3. The Shake Test:</strong></p>
                <p>Used to verify if freeze-sensitive vaccines (DPT, Pentavalent, Hep B) have been damaged by accidental sub-zero freezing. Vigorously shake a suspected frozen vial and a known non-frozen control vial simultaneously. If the suspected vial sediments rapidly (&lt;15–30 min) leaving clear fluid at top while the control remains cloudy, the test is POSITIVE (vaccine was frozen) &rarr; Discard immediately!</p>
              </div>
            </div>
          </div>
        </div>

      </div>
    </div>

    <!-- ------------------------------------------------------------ -->
    <!-- TOPIC 5: IMNCI PROTOCOL (REPEATED 3/4)                      -->
    <!-- ------------------------------------------------------------ -->`},{id:`grp-imnci`,title:`Integrated Management of Neonatal & Childhood Illness (IMNCI)`,repeatCount:3,years:[`2019`,`2020`,`2025`],probability:90,priorityTier:`Tier 2 • Very High`,tierClass:`tier-high`,subItems:[{concept:`IMNCI definition, case management process (Assess, Classify, Identify, Treat, Counsel)`,years:`2019, 2020`},{concept:`Color-coded triage: Pink (urgent referral), Yellow (OPD treatment), Green (home care)`,years:`2020, 2025`},{concept:`Management of ARI / Pneumonia and Acute Diarrhea (Plans A, B, C)`,years:`2020, 2025`}],questions:[{paperBadge:`MPMSU Feb 2025 (Supp) Q.3 & Feb 2020 Q.4 [10 Marks]`,weight:`Essay Question | Target: 4 Handwritten Pages`,questionText:`a. Define IMNCI (2) | b. Explain the principles and color-coded triage / management strategy (Pink, Yellow, Green) of IMNCI (4) | c. Discuss the assessment and management of a child presenting with Cough/Difficulty breathing or Acute Diarrhea (4).`}],answerHtml:`<!-- QUESTION 1: FEB 2025 (SUPP) Q.3 & FEB 2020 Q.4 [10 MARKS] -->
        <div class="q-block">
          <div class="q-header">
            <span class="q-badge">MPMSU Feb 2025 (Supp) Q.3 & Feb 2020 Q.4 [10 Marks]</span>
            <span class="q-weight">Essay Question | Target: 4 Handwritten Pages</span>
          </div>
          <div class="q-text-prompt">
            <strong>Exam Question:</strong> a. Define IMNCI (2) | b. Explain the principles and color-coded triage / management strategy (Pink, Yellow, Green) of IMNCI (4) | c. Discuss the assessment and management of a child presenting with Cough/Difficulty breathing or Acute Diarrhea (4).
          </div>
          <div class="q-answer-content">
            <div class="ans-part">
              <div class="ans-part-title">Part (a): Definition of IMNCI (2 Marks)</div>
              <div class="ans-part-body">
                <p><strong>Integrated Management of Neonatal and Childhood Illness (IMNCI):</strong> An integrated, holistic, evidence-based syndromic strategy developed by WHO and UNICEF (adapted in India to include young infants 0–2 months) aimed at reducing under-five mortality, morbidity, and malnutrition by combining preventive, promotive, and curative care for the major killer childhood conditions (Pneumonia, Diarrhea, Malaria, Measles, Malnutrition, and Neonatal Sepsis).</p>
              </div>
            </div>

            <div class="ans-part">
              <div class="ans-part-title">Part (b): IMNCI Color-Coded Triage & Case Management Process (4 Marks)</div>
              <div class="ans-part-body">
                <p><strong>IMNCI Color-Coded Categorization System:</strong></p>
                <table class="clinical-table">
                  <thead>
                    <tr><th>Color Band</th><th>Classification & Severity</th><th>Action Required by Healthcare Worker</th></tr>
                  </thead>
                  <tbody>
                    <tr>
                      <td><strong style="color: #ec4899;">PINK</strong></td>
                      <td><strong>Severe Condition</strong> (e.g., Severe Pneumonia, Severe Dehydration, Very Severe Disease).</td>
                      <td><strong>Urgent Pre-referral Treatment & Immediate Hospital Referral.</strong> Give first dose of parenteral/oral antibiotic, prevent hypothermia, treat hypoglycemia, and refer urgently.</td>
                    </tr>
                    <tr>
                      <td><strong style="color: #eab308;">YELLOW</strong></td>
                      <td><strong>Moderate Condition</strong> (e.g., Pneumonia, Some Dehydration, Acute Otitis Media).</td>
                      <td><strong>Specific Medical Treatment at Primary Health Center / OPD.</strong> Prescribe oral antibiotic/antimalarial, teach mother how to administer at home, and advise on 2-day follow-up.</td>
                    </tr>
                    <tr>
                      <td><strong style="color: #22c55e;">GREEN</strong></td>
                      <td><strong>Mild Condition</strong> (e.g., Cough/Cold, No Dehydration).</td>
                      <td><strong>Home Management & Mother Counseling.</strong> Advise mother on fluids, continued feeding, soothing home remedies (honey for cough &gt;1 yr), and teach signs of when to return immediately.</td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>

            <div class="ans-part">
              <div class="ans-part-title">Part (c): Assessment & Management of Cough / Difficulty Breathing (4 Marks)</div>
              <div class="ans-part-body">
                <p><strong>Assessment (Count Respirations for 1 Full Minute):</strong></p>
                <ul>
                  <li><em>Cut-offs for Fast Breathing:</em>
                    <ul>
                      <li>Age &lt; 2 months: <strong>&ge; 60 breaths/min</strong></li>
                      <li>Age 2 to 11 months: <strong>&ge; 50 breaths/min</strong></li>
                      <li>Age 12 months to 5 years: <strong>&ge; 40 breaths/min</strong></li>
                    </ul>
                  </li>
                  <li>Check for <strong>Chest Indrawing</strong> (lower chest wall moves inward on inspiration) and <strong>Stridor in a calm child</strong>.</li>
                </ul>

                <p><strong>Classification & Treatment:</strong></p>
                <table class="clinical-table">
                  <thead>
                    <tr><th>Signs</th><th>Classification (Color)</th><th>Treatment Protocol</th></tr>
                  </thead>
                  <tbody>
                    <tr>
                      <td>Any General Danger Sign (vomits everything, convulsions, lethargy/unconscious, unable to drink) OR Chest Indrawing OR Stridor in calm child.</td>
                      <td><strong style="color: #ec4899;">SEVERE PNEUMONIA (PINK)</strong></td>
                      <td>Give first dose of IV/IM Ampicillin + Gentamicin; administer oxygen if available; keep child warm; <strong>Refer URGENTLY to hospital</strong>.</td>
                    </tr>
                    <tr>
                      <td>Fast Breathing only (no chest indrawing, no danger signs).</td>
                      <td><strong style="color: #eab308;">PNEUMONIA (YELLOW)</strong></td>
                      <td>Give oral <strong>Amoxicillin (40 mg/kg/dose BID &times; 5 days)</strong>; soothe throat with warm water; advise mother to return in 2 days for reassessment.</td>
                    </tr>
                    <tr>
                      <td>No fast breathing; no chest indrawing; no danger signs.</td>
                      <td><strong style="color: #22c55e;">NO PNEUMONIA: COUGH OR COLD (GREEN)</strong></td>
                      <td>No antibiotics needed; home remedies (warm water, breast milk); counsel on signs to return immediately.</td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </div>

      </div>
    </div>

    <!-- ------------------------------------------------------------ -->
    <!-- TOPIC 6: PROTEIN ENERGY MALNUTRITION (PEM) (REPEATED 3/4)   -->
    <!-- ------------------------------------------------------------ -->`},{id:`grp-pem`,title:`Protein Energy Malnutrition (PEM: Kwashiorkor vs Marasmus)`,repeatCount:3,years:[`2019`,`2020`,`2022`],probability:90,priorityTier:`Tier 2 • Very High`,tierClass:`tier-high`,subItems:[{concept:`WHO & Gomez classifications of malnutrition, SAM criteria (MUAC &lt;11.5 cm)`,years:`2022`},{concept:`Comparative clinical differentiation: Kwashiorkor vs Nutritional Marasmus`,years:`2019, 2020, 2022`},{concept:`NRC inpatient protocol: F-75 stabilization, F-100 catch-up growth & refeeding syndrome`,years:`2022`}],questions:[{paperBadge:`MPMSU July 2022 (Main) Q.3 & Feb 2020 Q.3 [10 Marks]`,weight:`Essay Question | Target: 4 Handwritten Pages`,questionText:`a. Define Protein Energy Malnutrition (PEM) (2) | b. Differentiate between Kwashiorkor and Marasmus with clinical features (4) | c. Discuss the nutritional and nursing management of severe acute malnutrition (SAM) (4).`}],answerHtml:`<!-- QUESTION 1: JULY 2022 (MAIN) Q.3 & FEB 2020 Q.3 [10 MARKS] -->
        <div class="q-block">
          <div class="q-header">
            <span class="q-badge">MPMSU July 2022 (Main) Q.3 & Feb 2020 Q.3 [10 Marks]</span>
            <span class="q-weight">Essay Question | Target: 4 Handwritten Pages</span>
          </div>
          <div class="q-text-prompt">
            <strong>Exam Question:</strong> a. Define Protein Energy Malnutrition (PEM) (2) | b. Differentiate between Kwashiorkor and Marasmus with clinical features (4) | c. Discuss the nutritional and nursing management of severe acute malnutrition (SAM) (4).
          </div>
          <div class="q-answer-content">
            <div class="ans-part">
              <div class="ans-part-title">Part (a): Definition of PEM & Severe Acute Malnutrition (SAM) (2 Marks)</div>
              <div class="ans-part-body">
                <p><strong>Protein Energy Malnutrition (PEM):</strong> A spectrum of pathological conditions arising from a disproportionate or absolute dietary deficiency of proteins and calories (energy), commonly precipitated by infections, leading to growth faltering, tissue wasting, and cellular dysfunction in infants and young children.</p>
                <p><strong>WHO Diagnostic Criteria for Severe Acute Malnutrition (SAM in 6–59 months):</strong></p>
                <ul>
                  <li><strong>Mid-Upper Arm Circumference (MUAC) &lt; 115 mm (11.5 cm)</strong> (Red zone of Shakir's tape).</li>
                  <li><strong>Weight-for-Height Z-score &lt; -3 SD</strong> of WHO growth standards.</li>
                  <li>Presence of <strong>Bilateral Pitting Edema</strong> of nutritional origin.</li>
                </ul>
              </div>
            </div>

            <div class="ans-part">
              <div class="ans-part-title">Part (b): Detailed Differentiation: Kwashiorkor vs. Marasmus (4 Marks)</div>
              <div class="ans-part-body">
                <img src="/pyqs/images/kwashiorkor_marasmus.jpg" class="med-img" alt="Clinical Comparison: Kwashiorkor vs Marasmus (WHO Pediatrics)">
                <table class="clinical-table">
                  <thead>
                    <tr><th>Feature</th><th>Kwashiorkor</th><th>Nutritional Marasmus</th></tr>
                  </thead>
                  <tbody>
                    <tr><td><strong>Etiology</strong></td><td>Severe, predominant <strong>Protein Deficiency</strong> with adequate or excess carbohydrate intake ("Sugar baby").</td><td>Severe, generalized <strong>Deficiency of BOTH Calories and Protein</strong> (Total Starvation).</td></tr>
                    <tr><td><strong>Peak Age</strong></td><td>1 to 4 years (often after weaning when child displaced by newborn sibling).</td><td>&lt; 1 year of age (infancy).</td></tr>
                    <tr><td><strong>Edema</strong></td><td><strong>Present (Essential Hallmark!)</strong>; begins in lower extremities, progresses to generalized.</td><td><strong>Completely Absent.</strong></td></tr>
                    <tr><td><strong>Subcutaneous Fat</strong></td><td>Preserved or reduced mildly; masked by generalized edema.</td><td>Completely lost; severe generalized muscle wasting ("Skin and bone" appearance).</td></tr>
                    <tr><td><strong>Facial Appearance</strong></td><td><strong>"Moon Facies"</strong> (rounded, edematous, puffy cheeks).</td><td><strong>"Old Man Facies" / "Monkey Face"</strong> (sunken eyes, hollow cheeks due to loss of Bichat buccal fat pads).</td></tr>
                    <tr><td><strong>Mental State</strong></td><td>Miserable, severe apathy, lethargy, irritable when disturbed.</td><td>Alert, ravenously hungry, fretful.</td></tr>
                    <tr><td><strong>Hair Changes</strong></td><td>Dry, lusterless, hypopigmented (reddish-blonde), brittle; <strong>"Flag Sign"</strong> (alternating light/dark bands).</td><td>Normal hair or sparse and dry, but no flag sign.</td></tr>
                    <tr><td><strong>Skin Changes</strong></td><td><strong>"Flaky Paint Dermatosis" / "Crazy Pavement Dermatosis"</strong> (hyperpigmented peeling scales).</td><td>Dry, wrinkled, loose, bag-like skin (hanging folds over buttocks).</td></tr>
                    <tr><td><strong>Hepatomegaly</strong></td><td>Present (Fatty infiltration of liver due to impaired apolipoprotein synthesis).</td><td>Absent (liver normal or small).</td></tr>
                  </tbody>
                </table>
              </div>
            </div>

            <div class="ans-part">
              <div class="ans-part-title">Part (c): Nutritional & Nursing Management of SAM (NRC Protocol) (4 Marks)</div>
              <div class="ans-part-body">
                <p>Managed in a specialized Nutrition Rehabilitation Center (NRC) following WHO's <strong>10 Steps Protocol across 2 Phases</strong>:</p>
                <ol>
                  <li><strong>Phase 1: Stabilization Phase (Days 1–7):</strong>
                    <ul>
                      <li><em>Prevent Hypoglycemia:</em> Give 10% dextrose 50 mL PO or starter formula immediately upon admission.</li>
                      <li><em>Prevent Hypothermia:</em> Keep child warm (kangaroo care, room temp 28–30°C).</li>
                      <li><em>Treat Dehydration:</em> Give <strong>ReSoMaL (Rehydration Solution for Malnutrition)</strong> 5 mL/kg q30min for first 2 hrs. <em>NEVER give standard WHO-ORS or rapid IV fluids</em> (precipitates acute heart failure!).</li>
                      <li><em>Correct Electrolytes:</em> Add Potassium (3–4 mmol/kg/day) and Magnesium; <strong>NO SODIUM</strong>.</li>
                      <li><em>Treat Infection:</em> Broad-spectrum antibiotics (Amoxicillin or Ampicillin + Gentamicin) routinely given to all SAM cases (fever and leukocytosis are absent due to anergy).</li>
                      <li><em>Starter Feeding:</em> Feed <strong>F-75 Therapeutic Milk (75 kcal & 0.9 g protein / 100 mL)</strong> in small frequent feeds (q2h day and night, 130 mL/kg/day). Prevents Refeeding Syndrome!</li>
                    </ul>
                  </li>
                  <li><strong>Phase 2: Rehabilitation / Catch-Up Growth Phase (Weeks 2–6):</strong>
                    <ul>
                      <li>Transition to <strong>F-100 Milk (100 kcal & 2.9 g protein / 100 mL)</strong> or Ready-to-Use Therapeutic Food (RUTF). Increase volume gradually to achieve rapid catch-up growth (&gt;10 g/kg/day).</li>
                      <li>Administer Vitamin A, Folic acid, and Iron (start iron ONLY in Phase 2 after infection controlled; giving iron in Phase 1 promotes bacterial growth).</li>
                    </ul>
                  </li>
                </ol>
              </div>
            </div>
          </div>
        </div>

      </div>
    </div>

    <!-- ------------------------------------------------------------ -->
    <!-- TOPIC 7: CHILD GUIDANCE CLINIC & BEHAVIORAL PROBLEMS (3/4)   -->
    <!-- ------------------------------------------------------------ -->`},{id:`grp-cgc`,title:`Child Guidance Clinic (CGC) & Behavioral Problems`,repeatCount:3,years:[`2019`,`2022`,`2025`],probability:90,priorityTier:`Tier 2 • Very High`,tierClass:`tier-high`,subItems:[{concept:`Child Guidance Clinic (CGC): Objectives, multidisciplinary team & services`,years:`2022, 2025`},{concept:`Common childhood behavioral problems: Enuresis, temper tantrums, thumb sucking, ADHD`,years:`2019`},{concept:`Behavior modification therapies, play therapy & parent counseling`,years:`2019, 2025`}],questions:[{paperBadge:`MPMSU Feb 2025 (Supp) Q.5c & July 2022 Q.5d [5 Marks]`,weight:`Repeated Short Note | Target: 2–3 Handwritten Pages`,questionText:`Short Note: Child Guidance Clinic (CGC) - Objectives, team members and role in behavioral problems (5 Marks).`}],answerHtml:`<!-- QUESTION 1: FEB 2025 (SUPP) Q.5c & JULY 2022 Q.5d [5 MARKS] -->
        <div class="q-block">
          <div class="q-header">
            <span class="q-badge">MPMSU Feb 2025 (Supp) Q.5c & July 2022 Q.5d [5 Marks]</span>
            <span class="q-weight">Repeated Short Note | Target: 2–3 Handwritten Pages</span>
          </div>
          <div class="q-text-prompt">
            <strong>Exam Question:</strong> Short Note: Child Guidance Clinic (CGC) - Objectives, team members and role in behavioral problems (5 Marks).
          </div>
          <div class="q-answer-content">
            <div class="ans-part">
              <div class="ans-part-title">Comprehensive Clinical Answer: Child Guidance Clinic (CGC)</div>
              <div class="ans-part-body">
                <p><strong>Definition:</strong> A specialized medico-social psychiatric facility that provides diagnostic assessment, psychotherapeutic treatment, and preventive guidance for children suffering from emotional, behavioral, developmental, psychological, and scholastic maladjustments.</p>

                <p><strong>1. Primary Objectives of CGC:</strong></p>
                <ul>
                  <li>Early detection, diagnosis, and management of emotional, behavioral, and conduct disorders in children.</li>
                  <li>Prevention of juvenile delinquency, school dropouts, and serious adult psychopathology.</li>
                  <li>Guidance and counseling for parents and teachers regarding optimal child-rearing and disciplinary practices.</li>
                  <li>Assessment and rehabilitation of children with learning disabilities (Dyslexia), Intellectual Disability, ADHD, and Autism.</li>
                </ul>

                <p><strong>2. Multidisciplinary Team Composition:</strong></p>
                <ul>
                  <li><strong>Child Psychiatrist:</strong> Team leader; conducts medical/psychiatric evaluation, orders investigations, prescribes pharmacotherapy when needed.</li>
                  <li><strong>Clinical Psychologist:</strong> Conducts psychometric testing (IQ assessment via Binet-Kamat / WISC tests, behavioral rating scales, personality tests); administers cognitive-behavioral and play therapy.</li>
                  <li><strong>Psychiatric Social Worker (PSW):</strong> Takes detailed family social history, conducts home and school visits, evaluates parental dynamics and socio-economic stressors.</li>
                  <li><strong>Psychiatric Nurse / Pediatric Nurse:</strong> Assesses physical growth, administers medications, monitors side effects, conducts behavioral modification charts, educates parents on developmental needs.</li>
                  <li><strong>Speech-Language Pathologist & Special Educator:</strong> Evaluates speech delays, stuttering, and provides tailored remedial education for scholastic backwardness.</li>
                </ul>

                <p><strong>3. Nursing Role in Common Behavioral Problems:</strong></p>
                <ul>
                  <li><em>Enuresis (Bed-Wetting):</em> Educate parents never to punish, humiliate, or scold child. Implement behavioral therapy: Fluid restriction after 6 PM, bladder training, reward star charts for dry nights, and use of conditioning enuresis moisture alarm bells.</li>
                  <li><em>Temper Tantrums:</em> Instruct parents to maintain calm indifference (extinction), ensure physical safety without giving in to unreasonable demands (avoid reinforcing tantrums), and praise calm communication.</li>
                </ul>
              </div>
            </div>
          </div>
        </div>

      </div>
    </div>

    <!-- ------------------------------------------------------------ -->
    <!-- TOPIC 8: CONGENITAL ANOMALIES: HYDROCEPHALUS (REPEATED 2/4) -->
    <!-- ------------------------------------------------------------ -->`},{id:`grp-hydro`,title:`Congenital Anomalies (Hydrocephalus & VP Shunt)`,repeatCount:2,years:[`2020`,`2025`],probability:80,priorityTier:`Tier 3 • High Yield`,tierClass:`tier-moderate`,subItems:[{concept:`Hydrocephalus: Communicating vs non-communicating (Aqueductal stenosis)`,years:`2020, 2025`},{concept:`Clinical features in infants: Bulging fontanelle, "Sun-setting" eyes & Macewen's sign`,years:`2020, 2025`},{concept:`Ventriculoperitoneal (VP) Shunt surgery & comprehensive post-operative nursing care`,years:`2025`}],questions:[{paperBadge:`MPMSU Feb 2025 (Supp) Q.5d & Feb 2020 Q.5c [5 Marks]`,weight:`Repeated Short Note | Target: 2–3 Handwritten Pages`,questionText:`Short Note: Hydrocephalus - Causes, clinical features (Sun-setting sign, Macewen's sign) and VP Shunt nursing care (5 Marks).`}],answerHtml:`<!-- QUESTION 1: FEB 2025 (SUPP) Q.5d & FEB 2020 Q.5c [5 MARKS] -->
        <div class="q-block">
          <div class="q-header">
            <span class="q-badge">MPMSU Feb 2025 (Supp) Q.5d & Feb 2020 Q.5c [5 Marks]</span>
            <span class="q-weight">Repeated Short Note | Target: 2–3 Handwritten Pages</span>
          </div>
          <div class="q-text-prompt">
            <strong>Exam Question:</strong> Short Note: Hydrocephalus - Causes, clinical features (Sun-setting sign, Macewen's sign) and VP Shunt nursing care (5 Marks).
          </div>
          <div class="q-answer-content">
            <div class="ans-part">
              <div class="ans-part-title">Comprehensive Clinical Answer: Hydrocephalus</div>
              <div class="ans-part-body">
                <p><strong>Definition:</strong> An abnormal accumulation of cerebrospinal fluid (CSF) within the intracranial ventricular system, resulting from an imbalance between CSF production and absorption, causing progressive ventricular dilation and elevated intracranial pressure.</p>

                <p><strong>1. Classification & Causes:</strong></p>
                <ul>
                  <li><strong>Non-Communicating (Obstructive - Most Common in Infants):</strong> Physical obstruction of CSF flow along ventricular pathways:
                    <ul>
                      <li>Aqueductal Stenosis (narrowing of Aqueduct of Sylvius - most common congenital cause).</li>
                      <li>Chiari Malformation Type II (associated with Spina Bifida / Meningomyelocele).</li>
                      <li>Dandy-Walker Malformation (atresia of foramina of Luschka and Magendie).</li>
                    </ul>
                  </li>
                  <li><strong>Communicating (Non-Obstructive):</strong> Impaired CSF absorption at arachnoid villi (secondary to post-meningitic subarachnoid fibrosis or post-intraventricular hemorrhage) or rare choroid plexus papilloma (hypersecretion).</li>
                </ul>

                <p><strong>2. Pathognomonic Clinical Features in Infants:</strong></p>
                <ul>
                  <li><strong>Rapidly Increasing Head Circumference:</strong> Crosses percentiles on growth chart; disproportionately large head compared to face ("Craniofacial disproportion").</li>
                  <li><strong>Tense, Bulging, Non-Pulsatile Anterior Fontanelle</strong> (assessed while infant is sitting quietly, not crying).</li>
                  <li><strong>Widened, Separated Cranial Sutures</strong> and dilated, tortuous scalp veins (scalp skin is thin, shiny).</li>
                  <li><strong>"Sun-Setting" Eyes Sign:</strong> Downward deviation of the eyeballs with sclera visible above the iris, caused by elevated ICP compressing the midbrain tectum.</li>
                  <li><strong>Macewen's Sign ("Cracked-Pot" Sign):</strong> A resonant, cracked-pot sound elicited by percussion over the skull at junction of frontal, parietal, and temporal bones due to separated sutures.</li>
                  <li>High-pitched, piercing "cerebral cry", irritability, projectile vomiting, and lower extremity spasticity.</li>
                </ul>

                <p><strong>3. Surgical Management: Ventriculoperitoneal (VP) Shunt:</strong></p>
                <p>Placement of a silastic catheter connecting the lateral ventricle via a subcutaneous one-way pressure valve to the peritoneal cavity, allowing excess CSF to be reabsorbed by the peritoneum.</p>
                <img src="/pyqs/images/vp_shunt.jpg" class="med-img" alt="Ventriculoperitoneal VP Shunt for Pediatric Hydrocephalus">

                <p><strong>4. Post-Operative Nursing Care Plan (VP Shunt):</strong></p>
                <div class="callout">
                  &bull; <strong>Positioning:</strong> Position child <strong>FLAT (supine or semi-recumbent 15°)</strong> on the <em>unoperated side</em> for the first 24–48 hours.<br>
                  <em>*CRITICAL SAFETY RATIONALE:*</em> Placing the head flat prevents rapid CSF drainage through the shunt. Rapid overdrainage can cause bridging cortical veins to tear, precipitating catastrophic <strong>Subdural Hematoma</strong>.<br>
                  &bull; <strong>Monitor for Shunt Malfunction / Obstruction:</strong> Monitor for recurrence of elevated ICP (irritability, vomiting, tense fontanelle, lethargy).<br>
                  &bull; <strong>Monitor for Shunt Infection:</strong> Most common between 1–2 months post-op (<em>Staphylococcus epidermidis</em>). Check temperature q4h; inspect subcutaneous shunt tract on neck and chest for erythema, warmth, or tenderness.<br>
                  &bull; <strong>Abdominal Assessment:</strong> Auscultate bowel sounds; check for abdominal distension or CSF peritonitis / pseudocyst.
                </div>
              </div>
            </div>
          </div>
        </div>

      </div>
    </div>
  </div>

</div> <!-- /container -->

<script>
  // Tab switching
  function showTab(tabId, btn) {
    const tabs = document.querySelectorAll('.content');
    tabs.forEach(t => t.classList.remove('active'));
    
    const btns = document.querySelectorAll('.tab-btn');
    btns.forEach(b => b.classList.remove('active'));
    
    const target = document.getElementById(tabId);
    if (target) target.classList.add('active');
    if (btn) btn.classList.add('active');
  }

  // Topic Accordion Toggle
  function toggleAnswer(id) {
    const el = document.getElementById(id);
    if (!el) return;
    el.classList.toggle('open');
  }

  // Theme Toggle: Clean Icon-Only
  function toggleTheme() {
    const body = document.body;
    const icon = document.getElementById('themeIcon');
    const currentTheme = body.getAttribute('data-theme');
    
    if (currentTheme === 'dark') {
      body.setAttribute('data-theme', 'light');
      if (icon) icon.textContent = '🌙';
      localStorage.setItem('theme', 'light');
    } else {
      body.setAttribute('data-theme', 'dark');
      if (icon) icon.textContent = '☀️';
      localStorage.setItem('theme', 'dark');
    }
  }

  // Initial Theme Setup
  (function initTheme() {
    const saved = localStorage.getItem('theme');
    const icon = document.getElementById('themeIcon');
    if (saved === 'light') {
      document.body.setAttribute('data-theme', 'light');
      if (icon) icon.textContent = '🌙';
    } else {
      document.body.setAttribute('data-theme', 'dark');
      if (icon) icon.textContent = '☀️';
    }
  })();
<\/script>
</body>
</html>`}]},stats:{id:`stats`,name:`Nursing Research & Statistics`,shortName:`Research & Stats`,badge:`Evidence-Based Practice`,code:`NTRUHS / MPMSU 3rd Year`,desc:`Scientific Method, Pilot Study, Literature Review, Sampling & Central Tendency`,icon:`bar-chart-2`,color:`#818CF8`,papers:[{year:`2025`,session:`Supplementary Examination`,title:`Nursing Research & Stats Feb 2025 (Supp) Question Paper`,file:`/pyqs/stats/stats-2025-supp.pdf`,date:`February 2025`,totalMarks:75,duration:`3 Hours`,badge:`Latest Exam Paper`},{year:`2022`,session:`Main & Supplementary`,title:`Nursing Research & Stats July 2022 (Main) Question Paper`,file:`/pyqs/stats/stats-2022-main.pdf`,date:`July 2022`,totalMarks:75,duration:`3 Hours`,badge:`Core Annual`},{year:`2020`,session:`Main Examination`,title:`Nursing Research & Stats Feb 2020 (Main) Question Paper`,file:`/pyqs/stats/stats-2020-main.pdf`,date:`February 2020`,totalMarks:75,duration:`3 Hours`,badge:`Core Annual`},{year:`2019`,session:`Main Examination`,title:`Nursing Research & Stats May 2019 (Main) Question Paper`,file:`/pyqs/stats/stats-2019-main.pdf`,date:`May 2019`,totalMarks:75,duration:`3 Hours`,badge:`Benchmark Paper`}],topics:[{id:`grp-research`,title:`Nursing Research & Scientific Research Process`,repeatCount:4,years:[`2019`,`2020`,`2022`,`2025`],probability:98,priorityTier:`Tier 1 • Guaranteed`,tierClass:`tier-guaranteed`,subItems:[{concept:`Definition, need, scope & characteristics of good nursing research`,years:`2019, 2020, 2022, 2025`},{concept:`Complete 5 phases & 18 steps of scientific research process`,years:`2019, 2022, 2025`},{concept:`Criteria of a good research problem (FINER criteria) & variables`,years:`2020`}],questions:[{paperBadge:`MPMSU Feb 2025 (Supp) — Q.1 [15 Marks]`,weight:`Full Long Essay | Target: 5 Handwritten Pages`,questionText:`a. Define Nursing Research (2) | b. Explain the need, scope and purpose of research in nursing (5) | c. Discuss the steps of scientific nursing research process in detail (8).`},{paperBadge:`MPMSU Feb 2020 (Main) — Q.1 [15 Marks]`,weight:`Full Long Essay | Target: 5 Handwritten Pages`,questionText:`a. Define Research and Nursing Research (2) | b. Describe the scope and significance of nursing research (5) | c. Discuss the criteria of a good research problem (8).`}],answerHtml:`<!-- QUESTION 1: FEB 2025 (SUPP) Q.1 [15 MARKS] -->
        <div class="q-block">
          <div class="q-header">
            <span class="q-badge">MPMSU Feb 2025 (Supp) — Q.1 [15 Marks]</span>
            <span class="q-weight">Full Long Essay | Target: 5 Handwritten Pages</span>
          </div>
          <div class="q-text-prompt">
            <strong>Exam Question:</strong> a. Define Nursing Research (2) | b. Explain the need, scope and purpose of research in nursing (5) | c. Discuss the steps of scientific nursing research process in detail (8).
          </div>
          <div class="q-answer-content">
            <div class="ans-part">
              <div class="ans-part-title">Part (a): Definition of Nursing Research (2 Marks)</div>
              <div class="ans-part-body">
                <p><strong>Nursing Research (Polit & Beck / International Council of Nurses):</strong> A systematic, rigorous, scientific inquiry designed to develop, refine, and expand trustworthy knowledge about issues of importance to the nursing profession, including nursing practice, education, administration, and informatics, aimed at validating existing practices and generating new evidence to optimize patient care outcomes.</p>
              </div>
            </div>

            <div class="ans-part">
              <div class="ans-part-title">Part (b): Need, Scope & Purpose of Research in Nursing (5 Marks)</div>
              <div class="ans-part-body">
                <p><strong>1. Need for Nursing Research:</strong></p>
                <ul>
                  <li><em>Transition to Evidence-Based Practice (EBP):</em> Replaces traditional, ritualistic, unverified practices (e.g., routine unverified bladder irrigations) with scientifically proven, cost-effective clinical protocols.</li>
                  <li><em>Professional Autonomy & Accountability:</em> Establishes a unique, specialized scientific body of knowledge distinct from general medicine, solidifying nursing as an independent profession.</li>
                  <li><em>Improved Quality of Patient Care & Safety:</em> Reduces hospital-acquired complications (falls, pressure injuries, catheter-associated UTIs, surgical site infections).</li>
                  <li><em>Health Policy Formulation:</em> Provides empirical data to health ministries and hospital boards for staffing ratios and resource distribution.</li>
                </ul>

                <p><strong>2. Scope of Nursing Research:</strong></p>
                <ul>
                  <li><em>Clinical Nursing Practice:</em> Pain management, wound healing, critical care monitoring, infection control, palliative care.</li>
                  <li><em>Nursing Education:</em> Curriculum development, simulation-based learning efficacy, clinical evaluation methods.</li>
                  <li><em>Nursing Administration:</em> Nurse-to-patient staffing models, retention strategies, burnout reduction, hospital ergonomics.</li>
                  <li><em>Community & Public Health:</em> Maternal and child health programs, immunization coverage, disease surveillance.</li>
                </ul>

                <p><strong>3. Purposes of Nursing Research (4 Universal Goals):</strong></p>
                <ol>
                  <li><em>Identification:</em> Recognizing unexplored clinical phenomena (e.g., identifying moral distress in ICU nurses).</li>
                  <li><em>Description:</em> Delineating the prevalence, dimensions, and manifestations of clinical issues.</li>
                  <li><em>Exploration:</em> Investigating underlying mechanisms and risk factors of diseases or behaviors.</li>
                  <li><em>Explanation & Prediction/Control:</em> Testing causal relationships and interventions (e.g., testing whether chlorhexidine mouthwash prevents ventilator-associated pneumonia).</li>
                </ol>
              </div>
            </div>

            <div class="ans-part">
              <div class="ans-part-title">Part (c): Steps of the Scientific Nursing Research Process in Detail (8 Marks)</div>
              <div class="ans-part-body">
                <p>The research process consists of <strong>5 Major Phases containing 18 Sequential Steps</strong> (Polit & Beck):</p>
                <table class="clinical-table">
                  <thead>
                    <tr><th>Phase</th><th>Sequential Steps</th><th>Key Research Activities & Nursing Examples</th></tr>
                  </thead>
                  <tbody>
                    <tr>
                      <td><strong>Phase 1: Conceptual Phase (Thinking Phase)</strong></td>
                      <td>
                        Step 1: Formulating & delimiting research problem.<br>
                        Step 2: Reviewing related literature (ROL).<br>
                        Step 3: Developing theoretical / conceptual framework.<br>
                        Step 4: Formulating research questions and hypotheses.<br>
                        Step 5: Defining variables (independent, dependent, extraneous).
                      </td>
                      <td>Identifying a clinical challenge (e.g., "Effectiveness of structured repositioning protocol on pressure injury prevention"). Stating directional hypothesis: "Patients repositioned q2h will exhibit significantly lower incidence of Stage 2 pressure injuries than patients receiving routine care."</td>
                    </tr>
                    <tr>
                      <td><strong>Phase 2: Design & Planning Phase</strong></td>
                      <td>
                        Step 6: Selecting research design (Experimental, Quasi-experimental, Non-experimental).<br>
                        Step 7: Developing intervention protocols.<br>
                        Step 8: Identifying target population & accessible population.<br>
                        Step 9: Specifying sampling plan (technique, sample size power analysis).<br>
                        Step 10: Specifying data collection methods (Braden scale, physiological biophysiologic measures).<br>
                        Step 11: Finalizing ethical approval (Institutional Ethics Committee - IEC clearance).<br>
                        Step 12: Conducting a <strong>Pilot Study</strong> and revising plan.
                      </td>
                      <td>Choosing a Randomized Controlled Trial (RCT) design. Obtaining formal IEC clearance and written informed consent. Testing questionnaire reliability on 10% sample size during pilot study.</td>
                    </tr>
                    <tr>
                      <td><strong>Phase 3: Empirical Phase (Doing Phase)</strong></td>
                      <td>
                        Step 13: Collecting data under standardized conditions.<br>
                        Step 14: Preparing data for analysis (coding, data cleaning, verification).
                      </td>
                      <td>Administering structured questionnaires, recording physiological parameters, ensuring high response rate, blinded data entry.</td>
                    </tr>
                    <tr>
                      <td><strong>Phase 4: Analytic Phase</strong></td>
                      <td>
                        Step 15: Analyzing data using descriptive & inferential statistics.<br>
                        Step 16: Interpreting statistical results in light of hypotheses and theoretical framework.
                      </td>
                      <td>Calculating Mean, SD, t-test, or Chi-Square ($p < 0.05$); determining clinical significance vs statistical significance.</td>
                    </tr>
                    <tr>
                      <td><strong>Phase 5: Dissemination Phase</strong></td>
                      <td>
                        Step 17: Communicating research findings (publishing in peer-reviewed journals, conferences).<br>
                        Step 18: Facilitating translation of findings into evidence-based clinical nursing practice.
                      </td>
                      <td>Publishing in Indian Journal of Nursing Studies; integrating findings into hospital clinical standard operating procedures (SOPs).</td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </div>

        <!-- QUESTION 2: FEB 2020 (MAIN) Q.1 [15 MARKS] -->
        <div class="q-block">
          <div class="q-header">
            <span class="q-badge">MPMSU Feb 2020 (Main) — Q.1 [15 Marks]</span>
            <span class="q-weight">Full Long Essay | Target: 5 Handwritten Pages</span>
          </div>
          <div class="q-text-prompt">
            <strong>Exam Question:</strong> a. Define Research and Nursing Research (2) | b. Describe the scope and significance of nursing research (5) | c. Discuss the criteria of a good research problem (8).
          </div>
          <div class="q-answer-content">
            <div class="ans-part">
              <div class="ans-part-title">Part (a): Definitions of Research & Nursing Research (2 Marks)</div>
              <div class="ans-part-body">
                <p><strong>Research:</strong> A systematic, controlled, empirical, and critical investigation of hypothetical propositions about presumed relationships among natural phenomena (Kerlinger).</p>
                <p><strong>Nursing Research:</strong> Scientific inquiry that validates and refines existing knowledge and generates new knowledge that directly and indirectly influences clinical nursing practice and client outcomes.</p>
              </div>
            </div>

            <div class="ans-part">
              <div class="ans-part-title">Part (b): Scope and Significance of Nursing Research (5 Marks)</div>
              <div class="ans-part-body">
                <p>Significance centers on establishing evidence-based standards, demonstrating the economic value of skilled nursing, promoting individualized patient care, reducing hospital stays, and expanding specialized advanced nursing roles (Nurse Practitioner, Clinical Nurse Specialist).</p>
              </div>
            </div>

            <div class="ans-part">
              <div class="ans-part-title">Part (c): Criteria of a Good Research Problem (FINER Criteria) (8 Marks)</div>
              <div class="ans-part-body">
                <p>A research problem must be rigorously evaluated against standard scientific criteria prior to study initiation:</p>
                <table class="clinical-table">
                  <thead>
                    <tr><th>Criterion</th><th>Scientific Dimension</th><th>Clinical Application & Verification</th></tr>
                  </thead>
                  <tbody>
                    <tr>
                      <td><strong>1. Significance to Nursing</strong></td>
                      <td>Must have clear relevance and practical utility for nursing practice, education, or administration.</td>
                      <td>Will the findings improve patient recovery, reduce nursing workload, or prevent clinical errors? (Trivial problems should not be pursued).</td>
                    </tr>
                    <tr>
                      <td><strong>2. Feasibility (The FINER Criteria)</strong></td>
                      <td>Practical capability of executing the study within constraints:
                        <br>&bull; <strong>F - Feasible:</strong> Adequate subjects, technical expertise, time, and budget.
                        <br>&bull; <strong>I - Interesting:</strong> Sustains investigator enthusiasm.
                        <br>&bull; <strong>N - Novel:</strong> Confirms, refutes, or extends previous findings.
                        <br>&bull; <strong>E - Ethical:</strong> Meets ethical standards.
                        <br>&bull; <strong>R - Relevant:</strong> Contributes to scientific advancement.
                      </td>
                      <td>Ensures researcher has access to target patient population (e.g., obtaining 100 ventilated ICU patients within 6 months).</td>
                    </tr>
                    <tr>
                      <td><strong>3. Researchability</strong></td>
                      <td>The problem must be capable of being answered through empirical observation and scientific measurement.</td>
                      <td>Cannot be a philosophical or moral value judgment (e.g., "Is euthanasia moral?" is a philosophical question, whereas "What are nurses' attitudes toward DNR orders?" is an empirical, researchable question).</td>
                    </tr>
                    <tr>
                      <td><strong>4. Ethical Acceptability</strong></td>
                      <td>Must comply with the <em>Declaration of Helsinki</em> and Belmont Report (Beneficence, Respect for Autonomy, Justice).</td>
                      <td>Guarantees zero physical or psychological harm, voluntary written informed consent, confidentiality, and institutional ethical committee clearance.</td>
                    </tr>
                    <tr>
                      <td><strong>5. Clarity & Specificity</strong></td>
                      <td>Must clearly specify the population, independent variable (intervention), and dependent variable (outcome). (PICO format: Population, Intervention, Comparison, Outcome).</td>
                      <td>Avoids vague terminology; variables can be operationally defined and measured with validated instruments.</td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </div>

      </div>
    </div>

    <!-- ------------------------------------------------------------ -->
    <!-- TOPIC 2: PILOT STUDY (REPEATED IN ALL 4 PAPERS - 100%)       -->
    <!-- ------------------------------------------------------------ -->`},{id:`grp-pilot`,title:`Pilot Study (100% Repetition Across All Papers)`,repeatCount:4,years:[`2019`,`2020`,`2022`,`2025`],probability:98,priorityTier:`Tier 1 • Guaranteed`,tierClass:`tier-guaranteed`,subItems:[{concept:`Definition, primary objectives & "dress rehearsal" concept`,years:`2019, 2020, 2022, 2025`},{concept:`Testing feasibility, adequacy of sampling frame & tool reliability`,years:`2022, 2025`},{concept:`Distinction between pilot study and pre-testing of tools`,years:`2020, 2025`}],questions:[{paperBadge:`MPMSU '19, '20, '22, '25 — Q.5 [5 Marks]`,weight:`Guaranteed 100% Repeated Short Note | Target: 2–3 Handwritten Pages`,questionText:`Short Note: Pilot Study - Purpose, steps and significance in nursing research (5 Marks).`}],answerHtml:`<!-- QUESTION 1: REPEATED IN 2019, 2020, 2022, 2025 [5 MARKS] -->
        <div class="q-block">
          <div class="q-header">
            <span class="q-badge">MPMSU '19, '20, '22, '25 — Q.5 [5 Marks]</span>
            <span class="q-weight">Guaranteed 100% Repeated Short Note | Target: 2–3 Handwritten Pages</span>
          </div>
          <div class="q-text-prompt">
            <strong>Exam Question:</strong> Short Note: Pilot Study - Purpose, steps and significance in nursing research (5 Marks).
          </div>
          <div class="q-answer-content">
            <div class="ans-part">
              <div class="ans-part-title">Comprehensive Clinical Model Answer: Pilot Study</div>
              <div class="ans-part-body">
                <p><strong>Definition:</strong> A pilot study is a small-scale, preliminary version or miniature trial of a planned research study, typically conducted on a small sample (10% to 20% of the planned main sample) with similar characteristics to the target population, designed to test the feasibility, adequacy, and operational mechanics of the research design before committing major resources to the full-scale investigation ("The Dress Rehearsal of Research").</p>

                <p><strong>1. Primary Purposes & Objectives of a Pilot Study:</strong></p>
                <ul>
                  <li><strong>Assess Feasibility:</strong> Determines whether the proposed research can realistically be completed within the planned budget, timeframe, and institutional setting.</li>
                  <li><strong>Evaluate Adequacy of Sampling Frame:</strong> Tests whether subjects are readily available, willing to participate, and assesses anticipated refusal/dropout rates.</li>
                  <li><strong>Test Research Instruments (Reliability & Validity):</strong> Identifies ambiguous, confusing, culturally offensive, or redundant questions in questionnaires; determines the exact time required for subject completion.</li>
                  <li><strong>Standardize Intervention Protocols:</strong> Ensures that all data collectors and research nurses administer clinical interventions identically and reliably (inter-rater reliability).</li>
                  <li><strong>Identify Unanticipated Methodological Problems:</strong> Uncovers logistical flaws in laboratory processing, equipment malfunctions, or storage issues.</li>
                  <li><strong>Determine Statistical Power & Sample Size:</strong> Generates preliminary estimates of outcome variability (standard deviation) to perform formal sample size power calculations ($1-\\beta = 0.80$).</li>
                </ul>

                <p><strong>2. Methodological Steps in Conducting a Pilot Study:</strong></p>
                <ol>
                  <li>Select a pilot sample (approx. 10–20 subjects) matching the inclusion/exclusion criteria of the target population.</li>
                  <li>Administer the research intervention and data collection tools under identical conditions planned for the main study.</li>
                  <li>Observe and record all subject difficulties, questions, non-verbal hesitancies, and timing.</li>
                  <li>Analyze pilot data using planned statistical software (check for coding errors, floor/ceiling effects).</li>
                  <li>Debrief subjects: Ask participants for constructive feedback on clarity, discomfort, or fatigue.</li>
                  <li>Revise research design, rewrite confusing questions, recalibrate instruments, and adjust protocols.</li>
                </ol>

                <p><strong>3. Critical Methodological Rule:</strong></p>
                <div class="callout">
                  <strong>CONTAMINATION RULE:</strong> Subjects who participated in the pilot study should generally <strong>NOT be included in the main study</strong>, as prior exposure to the instruments or intervention introduces significant practice effects, awareness bias, and threatens internal validity.
                </div>
              </div>
            </div>
          </div>
        </div>

      </div>
    </div>

    <!-- ------------------------------------------------------------ -->
    <!-- TOPIC 3: REVIEW OF LITERATURE (ROL) (REPEATED 4/4 - 100%)    -->
    <!-- ------------------------------------------------------------ -->`},{id:`grp-rol`,title:`Review of Literature (ROL) (100% Repetition)`,repeatCount:4,years:[`2019`,`2020`,`2022`,`2025`],probability:98,priorityTier:`Tier 1 • Guaranteed`,tierClass:`tier-guaranteed`,subItems:[{concept:`Definition, primary vs secondary sources & electronic bibliographic databases`,years:`2022, 2025`},{concept:`Purpose, steps of literature review & synthesis matrix`,years:`2019, 2020, 2022, 2025`},{concept:`Writing styles (APA vs Vancouver) & avoiding plagiarism`,years:`2022`}],questions:[{paperBadge:`MPMSU Feb 2025 (Supp) Q.2 & July 2022 Q.2 [10 Marks]`,weight:`Repeated Essay Question | Target: 4 Handwritten Pages`,questionText:`a. Define Review of Literature (2) | b. State the sources of literature review (Primary vs Secondary) (3) | c. Explain the purpose and steps of conducting literature review in nursing research (5).`}],answerHtml:`<!-- QUESTION 1: FEB 2025 (SUPP) Q.2 & JULY 2022 Q.2 [10 MARKS] -->
        <div class="q-block">
          <div class="q-header">
            <span class="q-badge">MPMSU Feb 2025 (Supp) Q.2 & July 2022 Q.2 [10 Marks]</span>
            <span class="q-weight">Repeated Essay Question | Target: 4 Handwritten Pages</span>
          </div>
          <div class="q-text-prompt">
            <strong>Exam Question:</strong> a. Define Review of Literature (2) | b. State the sources of literature review (Primary vs Secondary) (3) | c. Explain the purpose and steps of conducting literature review in nursing research (5).
          </div>
          <div class="q-answer-content">
            <div class="ans-part">
              <div class="ans-part-title">Part (a): Definition of Review of Literature (2 Marks)</div>
              <div class="ans-part-body">
                <p><strong>Review of Literature (ROL):</strong> A systematic, critical, comprehensive identification, location, appraisal, and synthesis of written scholarly published and unpublished research documents, theoretical formulations, and clinical evidence related to a specific research topic, providing the intellectual foundation for a scientific study.</p>
              </div>
            </div>

            <div class="ans-part">
              <div class="ans-part-title">Part (b): Sources of Literature Review (3 Marks)</div>
              <div class="ans-part-body">
                <table class="clinical-table">
                  <thead>
                    <tr><th>Source Category</th><th>Definition & Key Characteristics</th><th>Examples in Nursing Research</th></tr>
                  </thead>
                  <tbody>
                    <tr>
                      <td><strong>1. Primary Sources (Gold Standard)</strong></td>
                      <td>First-hand, original written research reports published by the actual investigators who conducted the scientific inquiry. Provides complete descriptions of methodology, raw data, and statistical analyses.</td>
                      <td>Original research articles in peer-reviewed journals (e.g., <em>Nursing Research, International Journal of Nursing Studies, Journal of Advanced Nursing</em>); original master's theses/doctoral dissertations.</td>
                    </tr>
                    <tr>
                      <td><strong>2. Secondary Sources</strong></td>
                      <td>Descriptions, summaries, critiques, or interpretations of research compiled by authors who did NOT directly participate in the original study. Useful for quick overviews, but subject to author misinterpretation.</td>
                      <td>Textbooks (Brunner & Suddarth), systematic reviews, meta-analyses, narrative literature reviews, clinical clinical practice guidelines.</td>
                    </tr>
                    <tr>
                      <td><strong>3. Electronic Bibliographic Databases</strong></td>
                      <td>Computerized indexing and abstracting databases accessed via medical libraries.</td>
                      <td><strong>CINAHL (Cumulative Index to Nursing and Allied Health Literature - the premier nursing database)</strong>, PubMed / MEDLINE, Cochrane Library (systematic reviews), Scopus, Google Scholar.</td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>

            <div class="ans-part">
              <div class="ans-part-title">Part (c): Purpose and Steps of Conducting Literature Review (5 Marks)</div>
              <div class="ans-part-body">
                <p><strong>Purposes of ROL:</strong></p>
                <ul>
                  <li>Identifies research gaps and unanswered clinical questions in existing knowledge.</li>
                  <li>Prevents unintentional, wasteful replication of previously solved problems.</li>
                  <li>Assists in selecting suitable theoretical frameworks and operationalizing variables.</li>
                  <li>Helps select validated data collection tools, reliable scales, and appropriate statistical tests.</li>
                  <li>Provides a benchmark for interpreting and contextualizing newly obtained study findings.</li>
                </ul>

                <p><strong>Sequential Steps in Conducting ROL:</strong></p>
                <ol>
                  <li><strong>Formulate Search Strategy:</strong> Define search keywords using Boolean operators (AND, OR, NOT) and MeSH (Medical Subject Headings) terms (e.g., "Kangaroo Mother Care" AND "Low Birth Weight" AND "Hypothermia").</li>
                  <li><strong>Search Literature:</strong> Query bibliographic databases (CINAHL, PubMed, Cochrane) applying filters (last 5 years, English, human subjects).</li>
                  <li><strong>Screen & Filter Titles/Abstracts:</strong> Retrieve relevant full-text articles; discard off-topic studies.</li>
                  <li><strong>Critical Appraisal of Evidence:</strong> Evaluate methodological quality, sample size power, validity of instruments, and risk of bias (using PRISMA or CASP appraisal checklists).</li>
                  <li><strong>Organize & Synthesize Findings (Literature Matrix):</strong> Group articles thematically into a matrix table (Author, Year, Sample, Design, Key Findings, Limitations).</li>
                  <li><strong>Write the Synthesized Review:</strong> Write a cohesive, analytical narrative connecting previous studies logically rather than summarizing paper-by-paper like an annotated bibliography. Use standardized citation styles (APA 7th edition or Vancouver).</li>
                </ol>
              </div>
            </div>
          </div>
        </div>

      </div>
    </div>

    <!-- ------------------------------------------------------------ -->
    <!-- TOPIC 4: SAMPLING TECHNIQUES & SAMPLE SIZE (REPEATED 4/4)    -->
    <!-- ------------------------------------------------------------ -->`},{id:`grp-sampling`,title:`Sampling Techniques & Sample Size Determination`,repeatCount:4,years:[`2019`,`2020`,`2022`,`2025`],probability:98,priorityTier:`Tier 1 • Guaranteed`,tierClass:`tier-guaranteed`,subItems:[{concept:`Definitions: Target/accessible population, sample, sampling frame & sampling error`,years:`2022`},{concept:`Probability sampling: Simple random, stratified, systematic & cluster sampling`,years:`2022, 2025`},{concept:`Non-probability sampling: Purposive, convenience, quota & snowball sampling`,years:`2019, 2020`}],questions:[{paperBadge:`MPMSU July 2022 (Main & Supp) — Q.3 [10 Marks]`,weight:`Essay Question | Target: 4 Handwritten Pages`,questionText:`a. Define Population, Sample, Sampling frame and Sampling error (3) | b. Differentiate between Probability and Non-Probability sampling (3) | c. Explain various types of probability sampling techniques with nursing examples (4).`}],answerHtml:`<!-- QUESTION 1: JULY 2022 (MAIN) Q.3 [10 MARKS] -->
        <div class="q-block">
          <div class="q-header">
            <span class="q-badge">MPMSU July 2022 (Main & Supp) — Q.3 [10 Marks]</span>
            <span class="q-weight">Essay Question | Target: 4 Handwritten Pages</span>
          </div>
          <div class="q-text-prompt">
            <strong>Exam Question:</strong> a. Define Population, Sample, Sampling frame and Sampling error (3) | b. Differentiate between Probability and Non-Probability sampling (3) | c. Explain various types of probability sampling techniques with nursing examples (4).
          </div>
          <div class="q-answer-content">
            <div class="ans-part">
              <div class="ans-part-title">Part (a): Definitions of Fundamental Sampling Concepts (3 Marks)</div>
              <div class="ans-part-body">
                <ul>
                  <li><strong>Population (Universe):</strong> The entire aggregate or totality of individuals, cases, or objects that conform to a designated set of inclusion specifications (e.g., all registered nurses working in government hospitals in Madhya Pradesh).</li>
                  <li><strong>Sample:</strong> A selected subset or portion of the target population chosen to participate in a research study to represent the whole.</li>
                  <li><strong>Sampling Frame:</strong> An actual, comprehensive, objective list or directory of all eligible sampling units/elements in the accessible population from which the sample is drawn (e.g., the official staff register of a hospital).</li>
                  <li><strong>Sampling Error:</strong> The inevitable, random statistical discrepancy between a sample statistic (e.g., sample mean $\\bar{X}$) and the true population parameter (population mean $\\mu$), caused by random fluctuation inherent in selecting a subset.</li>
                </ul>
              </div>
            </div>

            <div class="ans-part">
              <div class="ans-part-title">Part (b): Differentiating Probability vs. Non-Probability Sampling (3 Marks)</div>
              <div class="ans-part-body">
                <table class="clinical-table">
                  <thead>
                    <tr><th>Parameter</th><th>Probability Sampling</th><th>Non-Probability Sampling</th></tr>
                  </thead>
                  <tbody>
                    <tr><td><strong>Random Selection</strong></td><td>Uses strict random selection mechanisms; every element has a known, non-zero probability of being selected.</td><td>Does not involve random selection; elements chosen based on convenience, judgment, or availability.</td></tr>
                    <tr><td><strong>Representativeness & Bias</strong></td><td>High representativeness; minimizes researcher selection bias.</td><td>Lower representativeness; high risk of selection bias.</td></tr>
                    <tr><td><strong>Generalizability</strong></td><td>Findings can be confidently generalized to the broader target population with calculated sampling error.</td><td>Generalizability is severely limited; findings apply strictly to the immediate sample.</td></tr>
                    <tr><td><strong>Use Case</strong></td><td>Preferred in quantitative, experimental, and epidemiological surveys.</td><td>Common in qualitative research, preliminary exploratory studies, or when sampling frames are unavailable.</td></tr>
                  </tbody>
                </table>
              </div>
            </div>

            <div class="ans-part">
              <div class="ans-part-title">Part (c): Types of Probability Sampling Techniques with Nursing Examples (4 Marks)</div>
              <div class="ans-part-body">
                <ol>
                  <li><strong>1. Simple Random Sampling (SRS):</strong>
                    <ul>
                      <li><em>Mechanism:</em> Every element in the sampling frame has an equal and independent chance of selection. Accomplished via lottery method or computer-generated random number table.</li>
                      <li><em>Nursing Example:</em> Selecting 50 nurses randomly from a hospital staff list of 500 using random number software.</li>
                    </ul>
                  </li>
                  <li><strong>2. Stratified Random Sampling:</strong>
                    <ul>
                      <li><em>Mechanism:</em> The heterogeneous population is divided into mutually exclusive, homogeneous subgroups (strata) based on an important variable (e.g., clinical department, experience), and random samples are drawn proportionally from each stratum.</li>
                      <li><em>Nursing Example:</em> In a hospital study on needle-stick injuries, dividing nurses into ICU, Ward, and OPD strata, then randomly selecting 20% of nurses from each department to ensure proportional representation.</li>
                    </ul>
                  </li>
                  <li><strong>3. Systematic Random Sampling:</strong>
                    <ul>
                      <li><em>Mechanism:</em> Selecting every $k$-th element from an ordered sampling frame, where the sampling interval $k = N / n$ (Population size / Sample size), with a random starting point between 1 and $k$.</li>
                      <li><em>Nursing Example:</em> If $N = 1,000$ patient admission files and $n = 100$, $k = 10$. Randomly pick a number between 1 and 10 (e.g., 4). Then select files 4, 14, 24, 34, 44... up to 100 files.</li>
                    </ul>
                  </li>
                  <li><strong>4. Cluster Sampling (Multi-Stage Sampling):</strong>
                    <ul>
                      <li><em>Mechanism:</em> Used when a comprehensive sampling frame of individuals is impossible across large geographic areas. Large natural clusters (villages, districts, hospitals) are randomly selected first, then all individuals within chosen clusters are sampled.</li>
                      <li><em>Nursing Example:</em> In a statewide study on rural childhood malnutrition in MP, randomly selecting 10 Primary Health Centers (PHCs) out of 100, then screening all infants attending those 10 PHCs.</li>
                    </ul>
                  </li>
                </ol>
              </div>
            </div>
          </div>
        </div>

      </div>
    </div>

    <!-- ------------------------------------------------------------ -->
    <!-- TOPIC 5: MEASURES OF CENTRAL TENDENCY & NUMERICALS (4/4)    -->
    <!-- ------------------------------------------------------------ -->`},{id:`grp-central`,title:`Statistics: Measures of Central Tendency & Solved Numerical`,repeatCount:4,years:[`2019`,`2020`,`2022`,`2025`],probability:98,priorityTier:`Tier 1 • Guaranteed`,tierClass:`tier-guaranteed`,subItems:[{concept:`Theoretical concepts, properties, merits, and limitations of Mean, Median, and Mode`,years:`2020, 2022`},{concept:`Full step-by-step solved numerical calculation for continuous grouped frequency distribution`,years:`2019, 2025`},{concept:`Exact dataset repeated verbatim in May 2019 (Q.2) and Feb 2025 Supp (Q.3a)`,years:`2019, 2025`}],questions:[{paperBadge:`MPMSU Feb 2025 (Supp) Q.3a & May 2019 Q.2 [10 Marks]`,weight:`Identical Solved Numerical | Target: 4 Handwritten Pages`,questionText:`Calculate the Mean, Median, and Mode for the following frequency distribution: Class Interval (X): 10–20 (f=28), 20–30 (f=73), 30–40 (f=115), 40–50 (f=205), 50–60 (f=110), 60–70 (f=88), 70–80 (f=37), 80–90 (f=13).`},{paperBadge:`MPMSU July 2022 (Main) — Q.4a [8 Marks]`,weight:`Theory Essay | Target: 3–4 Handwritten Pages`,questionText:`Define Measures of Central Tendency. Compare the properties, uses, merits and limitations of Mean, Median and Mode in nursing research (8 Marks).`}],answerHtml:`<!-- ======================================================== -->
        <!-- CATEGORIZED CLINICAL CONCEPTS & BIOSTATISTICS            -->
        <!-- ======================================================== -->
        <div class="concept-category-title">Categorized Concepts & Measurement Hierarchy</div>

        <!-- 1. LEVELS OF MEASUREMENT -->
        <div class="concept-card">
          <div class="concept-title">1. Levels of Measurement Hierarchy (NOIR Scale)</div>
          <div class="concept-body">
            <ul>
              <li><strong>Nominal Scale:</strong> Qualitative categorical data without inherent ordering (e.g., Blood groups A/B/AB/O, biological sex, surgical complications). <em>Permissible Measure:</em> <strong>Mode only</strong>.</li>
              <li><strong>Ordinal Scale:</strong> Categorical data with logical ranked order, but non-equal mathematical intervals (e.g., Cancer staging I–IV, Glasgow Coma Scale score, Likert satisfaction scales). <em>Permissible Measure:</em> <strong>Median</strong> and Mode.</li>
              <li><strong>Interval Scale:</strong> Ordered quantitative data with equal intervals between points, but an arbitrary (non-absolute) zero point (e.g., Body temperature in Celsius/Fahrenheit). <em>Permissible Measure:</em> <strong>Mean</strong>, Median, Mode.</li>
              <li><strong>Ratio Scale:</strong> Quantitative continuous data with equal intervals and a true absolute zero point representing total absence of the variable (e.g., Weight, blood pressure, hourly urine output, drug dosage). <em>Permissible Measure:</em> <strong>All statistical measures</strong>.</li>
            </ul>
          </div>
        </div>

        <!-- 2. SKEWNESS & CENTRAL TENDENCY -->
        <div class="concept-card">
          <div class="concept-title">2. Skewness and the Relational Shift of Mean, Median, and Mode</div>
          <div class="concept-body">
            <ul>
              <li><em>Symmetrical (Normal) Distribution:</em> $\\text{Mean} = \\text{Median} = \\text{Mode}$. Classic bell-shaped Gaussian curve.</li>
              <li><em>Positively Skewed Distribution (Right-Tailed):</em> Tail extends toward high values. $\\text{Mean} > \\text{Median} > \\text{Mode}$. (Mean is pulled rightward by extreme outliers; <strong>Median is the most accurate measure</strong>).</li>
              <li><em>Negatively Skewed Distribution (Left-Tailed):</em> Tail extends toward low values. $\\text{Mean} < \\text{Median} < \\text{Mode}$.</li>
            </ul>
          </div>
        </div>

        <!-- ======================================================== -->
        <!-- SECTION B: PAST UNIVERSITY EXAM QUESTIONS & ANSWERS      -->
        <!-- ======================================================== -->
        <div class="section-divider-title">Exact University Exam Questions & 2–5 Page Model Answers</div>

        <!-- QUESTION 1: FEB 2025 (SUPP) Q.3a & MAY 2019 Q.2 [10 MARKS - IDENTICAL DATASET] -->
        <div class="q-block">
          <div class="q-header">
            <span class="q-badge">MPMSU Feb 2025 (Supp) Q.3a & May 2019 Q.2 [10 Marks]</span>
            <span class="q-weight">Identical Solved Numerical | Target: 4 Handwritten Pages</span>
          </div>
          <div class="q-text-prompt">
            <strong>Exam Question:</strong> Calculate the Mean, Median, and Mode for the following frequency distribution:
            <br>Class Interval (X): 10–20 (f=28), 20–30 (f=73), 30–40 (f=115), 40–50 (f=205), 50–60 (f=110), 60–70 (f=88), 70–80 (f=37), 80–90 (f=13).
          </div>
          <div class="q-answer-content">
            <div class="ans-part">
              <div class="ans-part-title">Step 1: Comprehensive Statistical Computation Table</div>
              <div class="ans-part-body">
                <p>We construct the complete frequency table with midpoints ($m$), deviation $d = \\frac{m - A}{i}$ (with Assumed Mean $A = 45$, class width $i = 10$), frequency products ($f \\cdot d$), and cumulative frequency ($cf$):</p>
                <table class="clinical-table">
                  <thead>
                    <tr>
                      <th>Class Interval ($X$)</th>
                      <th>Frequency ($f$)</th>
                      <th>Midpoint ($m$)</th>
                      <th>Step Deviation $d = \\frac{m - 45}{10}$</th>
                      <th>$f \\cdot d$</th>
                      <th>Cumulative Frequency ($cf$)</th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr><td>10 – 20</td><td>28</td><td>15</td><td>-3</td><td>-84</td><td>28</td></tr>
                    <tr><td>20 – 30</td><td>73</td><td>25</td><td>-2</td><td>-146</td><td>101</td></tr>
                    <tr><td>30 – 40</td><td>115</td><td>35</td><td>-1</td><td>-115</td><td>216</td></tr>
                    <tr style="background: rgba(16, 185, 129, 0.1); font-weight: bold;">
                      <td>40 – 50 (Modal & Median Class)</td>
                      <td>205</td>
                      <td>45 ($A$)</td>
                      <td>0</td>
                      <td>0</td>
                      <td>421</td>
                    </tr>
                    <tr><td>50 – 60</td><td>110</td><td>55</td><td>+1</td><td>+110</td><td>531</td></tr>
                    <tr><td>60 – 70</td><td>88</td><td>65</td><td>+2</td><td>+176</td><td>619</td></tr>
                    <tr><td>70 – 80</td><td>37</td><td>75</td><td>+3</td><td>+111</td><td>656</td></tr>
                    <tr><td>80 – 90</td><td>13</td><td>85</td><td>+4</td><td>+52</td><td>669 ($N$)</td></tr>
                    <tr style="font-weight: bold; background: var(--table-header);">
                      <td>TOTAL</td>
                      <td>$N = \\sum f = \\mathbf{669}$</td>
                      <td>—</td>
                      <td>—</td>
                      <td>$\\sum fd = \\mathbf{+104}$</td>
                      <td>—</td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>

            <div class="ans-part">
              <div class="ans-part-title">Step 2: Step-by-Step Calculation of Arithmetic Mean ($\\bar{X}$)</div>
              <div class="ans-part-body">
                <div class="calc-box">
                  <strong>STEP-DEVIATION FORMULA:</strong><br>
                  $\\bar{X} = A + \\left( \\frac{\\sum fd}{N} \\right) \\times i$<br><br>
                  Where:<br>
                  &bull; $A$ (Assumed Mean) = 45<br>
                  &bull; $\\sum fd$ = +104<br>
                  &bull; $N$ (Total Frequency) = 669<br>
                  &bull; $i$ (Class width) = 10<br><br>
                  <strong>CALCULATION:</strong><br>
                  $\\bar{X} = 45 + \\left( \\frac{104}{669} \\right) \\times 10$<br>
                  $\\bar{X} = 45 + \\left( 0.15545 \\right) \\times 10$<br>
                  $\\bar{X} = 45 + 1.5545 = \\mathbf{46.55}$
                </div>
                <p><strong>Result: Arithmetic Mean ($\\bar{X}$) = 46.55</strong></p>
              </div>
            </div>

            <div class="ans-part">
              <div class="ans-part-title">Step 3: Step-by-Step Calculation of Median ($M$)</div>
              <div class="ans-part-body">
                <div class="calc-box">
                  <strong>MEDIAN FORMULA:</strong><br>
                  Median Rank $= \\frac{N}{2} = \\frac{669}{2} = \\mathbf{334.5}$<br>
                  Looking at the cumulative frequency ($cf$) column, the 334.5th item falls in the class <strong>40 – 50</strong> ($cf = 421$).<br>
                  Therefore, the <strong>Median Class is 40 – 50</strong>.<br><br>
                  Formula: $\\text{Median} = L + \\left( \\frac{\\frac{N}{2} - cf_{prev}}{f_{med}} \\right) \\times i$<br><br>
                  Where:<br>
                  &bull; $L$ (Lower boundary of median class) = 40<br>
                  &bull; $N/2$ = 334.5<br>
                  &bull; $cf_{prev}$ (Cumulative frequency of preceding class 30–40) = 216<br>
                  &bull; $f_{med}$ (Frequency of median class) = 205<br>
                  &bull; $i$ (Class width) = 10<br><br>
                  <strong>CALCULATION:</strong><br>
                  $\\text{Median} = 40 + \\left( \\frac{334.5 - 216}{205} \\right) \\times 10$<br>
                  $\\text{Median} = 40 + \\left( \\frac{118.5}{205} \\right) \\times 10$<br>
                  $\\text{Median} = 40 + (0.5780 \\times 10) = 40 + 5.78 = \\mathbf{45.78}$
                </div>
                <p><strong>Result: Median ($M$) = 45.78</strong></p>
              </div>
            </div>

            <div class="ans-part">
              <div class="ans-part-title">Step 4: Step-by-Step Calculation of Mode ($Z$)</div>
              <div class="ans-part-body">
                <div class="calc-box">
                  <strong>MODE FORMULA:</strong><br>
                  The maximum frequency is <strong>205</strong>, which occurs in the class <strong>40 – 50</strong>.<br>
                  Therefore, the <strong>Modal Class is 40 – 50</strong>.<br><br>
                  Formula: $\\text{Mode} = L + \\left( \\frac{f_1 - f_0}{2f_1 - f_0 - f_2} \\right) \\times i$<br><br>
                  Where:<br>
                  &bull; $L$ (Lower boundary of modal class) = 40<br>
                  &bull; $f_1$ (Frequency of modal class) = 205<br>
                  &bull; $f_0$ (Frequency of preceding class 30–40) = 115<br>
                  &bull; $f_2$ (Frequency of succeeding class 50–60) = 110<br>
                  &bull; $i$ (Class width) = 10<br><br>
                  <strong>CALCULATION:</strong><br>
                  $\\text{Mode} = 40 + \\left( \\frac{205 - 115}{2(205) - 115 - 110} \\right) \\times 10$<br>
                  $\\text{Mode} = 40 + \\left( \\frac{90}{410 - 225} \\right) \\times 10$<br>
                  $\\text{Mode} = 40 + \\left( \\frac{90}{185} \\right) \\times 10$<br>
                  $\\text{Mode} = 40 + (0.4865 \\times 10) = 40 + 4.86 = \\mathbf{44.86}$
                </div>
                <p><strong>Result: Mode ($Z$) = 44.86</strong></p>
                <p><em>Empirical Verification Check:</em> In a moderately skewed distribution, $\\text{Mode} \\approx 3(\\text{Median}) - 2(\\text{Mean}) = 3(45.78) - 2(46.55) = 137.34 - 93.10 = 44.24$, confirming perfect consistency!</p>
              </div>
            </div>
          </div>
        </div>

        <!-- QUESTION 2: JULY 2022 (MAIN) Q.4a [8 MARKS] -->
        <div class="q-block">
          <div class="q-header">
            <span class="q-badge">MPMSU July 2022 (Main) — Q.4a [8 Marks]</span>
            <span class="q-weight">Theory Essay | Target: 3–4 Handwritten Pages</span>
          </div>
          <div class="q-text-prompt">
            <strong>Exam Question:</strong> Define Measures of Central Tendency. Compare the properties, uses, merits and limitations of Mean, Median and Mode in nursing research (8 Marks).
          </div>
          <div class="q-answer-content">
            <div class="ans-part">
              <div class="ans-part-title">Comprehensive Comparison of Central Tendency Measures</div>
              <div class="ans-part-body">
                <p><strong>Definition:</strong> A measure of central tendency is a single summary statistical value that describes the center, middle point, or central location of an entire distribution of quantitative data, around which observations tend to cluster.</p>
                <table class="clinical-table">
                  <thead>
                    <tr><th>Parameter</th><th>Arithmetic Mean ($\\bar{X}$)</th><th>Median ($M$)</th><th>Mode ($Z$)</th></tr>
                  </thead>
                  <tbody>
                    <tr>
                      <td><strong>Definition</strong></td>
                      <td>The arithmetic average obtained by dividing the sum of all observed values by the total number of observations.</td>
                      <td>The physical middle value that divides an ordered array of data into two equal halves (50th percentile).</td>
                      <td>The most frequently occurring score or value in a data distribution.</td>
                    </tr>
                    <tr>
                      <td><strong>Level of Measurement</strong></td>
                      <td>Interval and Ratio level data only.</td>
                      <td>Ordinal, Interval, and Ratio level data.</td>
                      <td>Nominal, Ordinal, Interval, and Ratio level data.</td>
                    </tr>
                    <tr>
                      <td><strong>Sensitivity to Outliers</strong></td>
                      <td><strong>Extremely sensitive to extreme outliers / skewed data</strong> (e.g., one patient with an ICU stay of 180 days drastically pulls mean upward).</td>
                      <td><strong>Completely insensitive / resistant to extreme outliers</strong>; best measure for skewed data.</td>
                      <td>Completely unaffected by extreme outliers.</td>
                    </tr>
                    <tr>
                      <td><strong>Mathematical Properties</strong></td>
                      <td>Lends itself to further advanced algebraic manipulation (ANOVA, regression, Pearson correlation). $\\sum (X - \\bar{X}) = 0$.</td>
                      <td>Cannot be algebraically manipulated further; insensitive to values other than rank.</td>
                      <td>Cannot be algebraically manipulated; unstable across small samples.</td>
                    </tr>
                    <tr>
                      <td><strong>Application in Nursing Research</strong></td>
                      <td>Reporting continuous normally distributed vital parameters: Blood pressure, serum glucose, body temperature, hematocrit.</td>
                      <td>Reporting skewed clinical data: Length of hospital stay (LOS), pain scores on visual analog scale (VAS), income levels.</td>
                      <td>Categorical epidemiological data: Most common hospital-acquired infection (e.g., CAUTI), most prevalent blood group.</td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </div>

      </div>
    </div>

    <!-- ------------------------------------------------------------ -->
    <!-- TOPIC 6: CORRELATION & DISPERSION (REPEATED 3/4)            -->
    <!-- ------------------------------------------------------------ -->`},{id:`grp-dispersion`,title:`Correlation & Dispersion (Normal Curve, Standard Deviation)`,repeatCount:3,years:[`2020`,`2022`,`2025`],probability:90,priorityTier:`Tier 2 • Very High`,tierClass:`tier-high`,subItems:[{concept:`Correlation: Direction, magnitude, Karl Pearson's coefficient ($r$) & interpretation`,years:`2025`},{concept:`Normal Probability Curve: Bell shape, symmetry, 68–95–99.7% empirical rule`,years:`2022`},{concept:`Standard deviation: Formula, variance relation & clinical significance in nursing`,years:`2020`}],questions:[{paperBadge:`MPMSU Feb 2025 (Supp) — Q.3b [7 Marks]`,weight:`Short Essay | Target: 3 Handwritten Pages`,questionText:`a. Define Correlation (2) | b. Explain types of correlation and Karl Pearson's correlation coefficient formula with interpretation (5).`},{paperBadge:`MPMSU July 2022 (Main) — Q.4b [7 Marks]`,weight:`Short Essay | Target: 3 Handwritten Pages`,questionText:`Short Note: Normal Probability Curve - Properties, characteristics and application in nursing research (7 Marks).`}],answerHtml:`<!-- ======================================================== -->
        <!-- CATEGORIZED CLINICAL CONCEPTS & BIOSTATISTICS            -->
        <!-- ======================================================== -->
        <div class="concept-category-title">Categorized Concepts & Probability Distribution</div>

        <!-- 1. NORMAL DISTRIBUTION BELL CURVE -->
        <div class="concept-card">
          <div class="concept-title">1. The Standard Normal Probability Curve (Gaussian Bell Curve)</div>
          <div class="concept-body">
            <p><strong>The Normal Distribution & Standard Deviation:</strong> The normal distribution is the cornerstone of biological measurement and inferential biostatistics. Most physiological variables across healthy human populations (hemoglobin, serum electrolytes, infant head circumference, adult blood pressure) follow this symmetrical bell-shaped curve:</p>
            
            <img src="/pyqs/images/normal_distribution_curve.png" class="med-img med-img-dark" alt="Standard Normal Distribution Gaussian Bell Curve">
            
            <div class="img-notes">
              <strong>Fundamental Properties of the Normal Distribution & Empirical Rule:</strong>
              <br>&bull; <strong>The Empirical (68–95–99.7%) Rule:</strong>
              <table class="clinical-table" style="margin-top: 8px;">
                <thead>
                  <tr><th>Standard Deviation Interval</th><th>Exact Area Under Curve</th><th>Significance in Nursing Research & Biostatistics</th></tr>
                </thead>
                <tbody>
                  <tr><td><strong>Mean &plusmn; 1 Standard Deviation (&mu; &plusmn; 1&sigma;)</strong></td><td><strong>68.26%</strong> of total data</td><td>34.13% on each side of the mean. Normal clinical physiological reference ranges encompass this cohort.</td></tr>
                  <tr><td><strong>Mean &plusmn; 2 Standard Deviations (&mu; &plusmn; 2&sigma;)</strong></td><td><strong>95.44%</strong> of total data</td><td>Standard threshold for 95% Confidence Intervals (CI). A Z-score threshold of &plusmn;1.96 defines &alpha; = 0.05 significance.</td></tr>
                  <tr><td><strong>Mean &plusmn; 3 Standard Deviations (&mu; &plusmn; 3&sigma;)</strong></td><td><strong>99.74%</strong> of total data</td><td>Nearly the entirety of the clinical population falls within &plusmn;3&sigma;. Defines 99% CI (Z = &plusmn;2.58, &alpha; = 0.01).</td></tr>
                </tbody>
              </table>
              <div style="margin-top: 8px;">
                &bull; <strong>Mathematical Properties:</strong> Symmetrical bell shape around the central axis where <em>Mean = Median = Mode</em>. Total area under the curve equals exactly 1.0 (100%). The tails are asymptotic to the horizontal baseline.
                <br>&bull; <strong>Standard Score (Z-Score) Formula:</strong> \\( Z = \\frac{X - \\mu}{\\sigma} \\), where \\(X\\) is the raw observation, \\(\\mu\\) is the population mean, and \\(\\sigma\\) is the standard deviation.
              </div>
            </div>
          </div>
        </div>

        <!-- ======================================================== -->
        <!-- SECTION B: PAST UNIVERSITY EXAM QUESTIONS & ANSWERS      -->
        <!-- ======================================================== -->
        <div class="section-divider-title">Exact University Exam Questions & 2–5 Page Model Answers</div>

        <!-- QUESTION 1: FEB 2025 (SUPP) Q.3b [7 MARKS] -->
        <div class="q-block">
          <div class="q-header">
            <span class="q-badge">MPMSU Feb 2025 (Supp) — Q.3b [7 Marks]</span>
            <span class="q-weight">Short Essay | Target: 3 Handwritten Pages</span>
          </div>
          <div class="q-text-prompt">
            <strong>Exam Question:</strong> a. Define Correlation (2) | b. Explain types of correlation and Karl Pearson's correlation coefficient formula with interpretation (5).
          </div>
          <div class="q-answer-content">
            <div class="ans-part">
              <div class="ans-part-title">Part (a): Definition of Correlation (2 Marks)</div>
              <div class="ans-part-body">
                <p><strong>Correlation:</strong> A bivariate statistical technique used to measure and describe the strength, direction, and magnitude of a linear relationship or association between two continuous quantitative variables, without implying direct causation.</p>
              </div>
            </div>

            <div class="ans-part">
              <div class="ans-part-title">Part (b): Types of Correlation & Karl Pearson's Formula (5 Marks)</div>
              <div class="ans-part-body">
                <p><strong>1. Classification by Direction:</strong></p>
                <ul>
                  <li><strong>Positive Correlation ($+1.0$):</strong> As variable $X$ increases, variable $Y$ increases proportionally (e.g., patient age and systolic blood pressure; maternal weight gain and fetal birth weight).</li>
                  <li><strong>Negative (Inverse) Correlation ($-1.0$):</strong> As variable $X$ increases, variable $Y$ decreases proportionally (e.g., nurse-to-patient staffing ratio and incidence of medication errors; adherence to antihypertensive therapy and risk of CVA).</li>
                  <li><strong>Zero (No) Correlation ($0.0$):</strong> No linear relationship between variables (e.g., shoe size and clinical nursing knowledge).</li>
                </ul>

                <p><strong>2. Karl Pearson's Coefficient of Correlation ($r$):</strong></p>
                <div class="calc-box">
                  <strong>FORMULA:</strong><br>
                  $r = \\frac{N \\sum XY - (\\sum X)(\\sum Y)}{\\sqrt{\\left[ N \\sum X^2 - (\\sum X)^2 \\right] \\left[ N \\sum Y^2 - (\\sum Y)^2 \\right]}}$<br><br>
                  <strong>Numerical Range:</strong> $-1.00 \\le r \\le +1.00$
                </div>

                <p><strong>3. Standard Clinical Interpretation:</strong></p>
                <ul>
                  <li>$r = \\pm 1.0$: Perfect positive / negative linear correlation.</li>
                  <li>$r = \\pm 0.70 \\text{ to } \\pm 0.99$: Very strong correlation.</li>
                  <li>$r = \\pm 0.50 \\text{ to } \\pm 0.69$: Substantial / moderate correlation.</li>
                  <li>$r = \\pm 0.30 \\text{ to } \\pm 0.49$: Weak correlation.</li>
                  <li>$r = 0.00 \\text{ to } \\pm 0.29$: Negligible correlation.</li>
                </ul>
              </div>
            </div>
          </div>
        </div>

        <!-- QUESTION 2: JULY 2022 (MAIN) Q.4b [7 MARKS] -->
        <div class="q-block">
          <div class="q-header">
            <span class="q-badge">MPMSU July 2022 (Main) — Q.4b [7 Marks]</span>
            <span class="q-weight">Short Essay | Target: 3 Handwritten Pages</span>
          </div>
          <div class="q-text-prompt">
            <strong>Exam Question:</strong> Short Note: Normal Probability Curve - Properties, characteristics and application in nursing research (7 Marks).
          </div>
          <div class="q-answer-content">
            <div class="ans-part">
              <div class="ans-part-title">Comprehensive Clinical Answer: Normal Probability Curve (NPC / Gaussian Distribution)</div>
              <div class="ans-part-body">
                <p><strong>Definition:</strong> A theoretical symmetrical bell-shaped mathematical frequency distribution of a continuous random variable, uniquely defined by its mean ($\\mu$) and standard deviation ($\\sigma$).</p>

                <p><strong>1. Fundamental Mathematical Properties & Characteristics:</strong></p>
                <ul>
                  <li><strong>Bell-Shaped & Unimodal:</strong> Has a single central peak corresponding to the mode.</li>
                  <li><strong>Perfect Symmetry:</strong> Exactly symmetrical around the central vertical axis. Skewness = 0; Kurtosis = 3 (mesokurtic).</li>
                  <li><strong>Coincidence of Central Tendency Measures:</strong> At the center, <strong>$\\text{Mean} = \\text{Median} = \\text{Mode}$</strong>.</li>
                  <li><strong>Asymptotic to Baseline:</strong> The tails extend infinitely in both directions without ever touching the horizontal axis ($X$-axis).</li>
                  <li><strong>Total Area Under Curve:</strong> Exactly equal to 1.0 (or 100%). Exactly 50% lies to the left of the mean and 50% to the right.</li>
                </ul>

                <p><strong>2. The Empirical Rule (68–95–99.7% Rule):</strong></p>
                <div class="callout">
                  &bull; <strong>$\\mu \\pm 1\\sigma$:</strong> Encloses <strong>68.26%</strong> of all observations.<br>
                  &bull; <strong>$\\mu \\pm 2\\sigma$:</strong> Encloses <strong>95.44%</strong> of all observations (strictly $1.96\\sigma = 95.0\\%$).<br>
                  &bull; <strong>$\\mu \\pm 3\\sigma$:</strong> Encloses <strong>99.74%</strong> of all observations.
                </div>

                <p><strong>3. Applications in Nursing & Healthcare:</strong></p>
                <ul>
                  <li><em>Establishing Biological Reference Ranges:</em> Normal laboratory ranges (e.g., serum electrolytes, hemoglobin, fasting blood glucose) are established as $\\text{Mean} \\pm 2\\text{SD}$ of healthy populations.</li>
                  <li><em>Inferential Statistics:</em> Serves as the fundamental assumption for parametric statistical testing (t-tests, ANOVA, Pearson correlation, regression).</li>
                  <li><em>Standard Scores ($Z$-scores):</strong> Used in pediatric growth charts to classify malnutrition ($<-2\\text{SD}$ underweight, $<-3\\text{SD}$ severe stunting/wasting).</li>
                </ul>
              </div>
            </div>
          </div>
        </div>

      </div>
    </div>

    <!-- ------------------------------------------------------------ -->
    <!-- TOPIC 7: DATA TABULATION & PRESENTATION (REPEATED 3/4)      -->
    <!-- ------------------------------------------------------------ -->`},{id:`grp-tabulation`,title:`Data Presentation, Tabulation & Graphs`,repeatCount:3,years:[`2019`,`2020`,`2022`],probability:90,priorityTier:`Tier 2 • Very High`,tierClass:`tier-high`,subItems:[{concept:`Statistical table parts: Table number, title, stub, caption, body & footnote`,years:`2022`},{concept:`Graphical presentation: Bar chart, histogram, frequency polygon, pie chart`,years:`2020`},{concept:`Rules and guidelines for frequency distribution tables and graphs`,years:`2019`}],questions:[{paperBadge:`MPMSU July 2022 (Main) — Q.5c [5 Marks]`,weight:`Short Note | Target: 2–3 Handwritten Pages`,questionText:`Short Note: Tabulation - Principles, parts of a table and rules for constructing statistical tables (5 Marks).`}],answerHtml:`<!-- QUESTION 1: JULY 2022 (MAIN) Q.5c [5 MARKS] -->
        <div class="q-block">
          <div class="q-header">
            <span class="q-badge">MPMSU July 2022 (Main) — Q.5c [5 Marks]</span>
            <span class="q-weight">Short Note | Target: 2–3 Handwritten Pages</span>
          </div>
          <div class="q-text-prompt">
            <strong>Exam Question:</strong> Short Note: Tabulation - Principles, parts of a table and rules for constructing statistical tables (5 Marks).
          </div>
          <div class="q-answer-content">
            <div class="ans-part">
              <div class="ans-part-title">Comprehensive Clinical Answer: Statistical Tabulation</div>
              <div class="ans-part-body">
                <p><strong>Definition:</strong> Tabulation is the systematic, logical presentation of numerical quantitative and qualitative data in rows (horizontal) and columns (vertical), designed to simplify complex data, facilitate comparison, save space, and provide a basis for statistical analysis.</p>

                <p><strong>1. Essential Component Parts of a Statistical Table:</strong></p>
                <ol>
                  <li><strong>Table Number:</strong> Clear identifying number placed at the top (e.g., Table 4.1).</li>
                  <li><strong>Title:</strong> Concise, self-explanatory statement answering: <em>What, Where, When, and How</em> data are classified.</li>
                  <li><strong>Stub:</strong> The extreme left-hand column containing row headings / classifications.</li>
                  <li><strong>Caption (Box Head):</strong> The column headings and sub-headings at the top of the columns.</li>
                  <li><strong>Body:</strong> The core interior containing the actual numerical figures in cells formed by row-column intersections.</li>
                  <li><strong>Prefatory Note / Headnote:</strong> Brief explanatory note below title specifying measurement units (e.g., "Values in thousands").</li>
                  <li><strong>Footnote:</strong> Placed at the bottom to clarify abbreviations, specific cells, or statistical symbols (* $p < 0.05$).</li>
                  <li><strong>Source Note:</strong> Cites the original source of secondary data.</li>
                </ol>

                <p><strong>2. Core Principles & Rules of Tabulation:</strong></p>
                <ul>
                  <li>Tables should be self-explanatory without requiring reader to search the text.</li>
                  <li>Units of measurement must be clearly stated in the column/row headings.</li>
                  <li>Rows and columns should include sub-totals and grand totals for verification.</li>
                  <li>If data are missing or zero, use "0" or "—" rather than leaving cells blank.</li>
                </ul>
              </div>
            </div>
          </div>
        </div>

      </div>
    </div>
  </div>

  <!-- ============================================================== -->
  <!-- 4. CHILD HEALTH NURSING (CHN / PEDIATRICS)                     -->
  <!-- ============================================================== -->`}]}},t={msn:[{id:`grp-msn-dialysis-renal`,title:`Acute Kidney Injury, ESRD & Hemodialysis / Peritoneal Dialysis`,repeatCount:2,years:[`2019`,`2022`],subItems:[{concept:`Indications, principles (diffusion, osmosis, ultrafiltration) & vascular access (AV fistula)`,years:`2019, 2022`},{concept:`Nursing care before, during, and after hemodialysis & disequilibrium syndrome`,years:`2022`}],questions:[{paperBadge:`MPMSU 2022 — Short Essay [5 Marks]`,weight:`Short Essay | Target: 2–3 Handwritten Pages`,questionText:`Define Hemodialysis. Explain its principles, vascular access, and nursing management of a patient undergoing hemodialysis.`},{paperBadge:`NTRUHS 2019 — Short Note [5 Marks]`,weight:`Short Note | Target: 2 Handwritten Pages`,questionText:`Write a short note on Peritoneal Dialysis and its complications.`}],answerHtml:`
        <div class="concept-card">
          <div class="concept-title">1. Definition & Core Physiologic Principles</div>
          <div class="concept-body">
            <p><strong>Hemodialysis</strong> is an extracorporeal renal replacement therapy in which blood is diverted from the patient's vascular system through an artificial semipermeable membrane (dialyzer) to clear uremic toxins, correct electrolyte imbalances, and remove excess fluid.</p>
            <ul>
              <li><strong>Diffusion:</strong> Movement of solutes (urea, creatinine, potassium) from an area of higher concentration (blood) to lower concentration (dialysate) across the semipermeable membrane.</li>
              <li><strong>Osmosis:</strong> Movement of water across the membrane from lower solute concentration to higher solute concentration.</li>
              <li><strong>Ultrafiltration:</strong> Movement of fluid under hydrostatic/transmembrane pressure gradient to relieve fluid overload.</li>
            </ul>
          </div>
        </div>
        <div class="concept-card">
          <div class="concept-title">2. Vascular Access & Care of AV Fistula</div>
          <div class="concept-body">
            <ul>
              <li><strong>Temporary Access:</strong> Dual-lumen central venous catheter (internal jugular or femoral vein).</li>
              <li><strong>Permanent Access:</strong> Arteriovenous (AV) fistula (Brescia-Cimino) or AV graft.</li>
              <li><strong>Nursing Care of AV Fistula:</strong> Palpate for <em>thrill</em> and auscultate for <em>bruit</em> every shift. Strictly avoid BP measurements, venipuncture, IV lines, or tight clothing on the fistula arm.</li>
            </ul>
          </div>
        </div>
        <div class="concept-card">
          <div class="concept-title">3. Nursing Management & Complications</div>
          <div class="concept-body">
            <ul>
              <li><strong>Pre-Dialysis:</strong> Record baseline weight, vital signs, and hold antihypertensives/water-soluble vitamins prior to session as ordered.</li>
              <li><strong>Intra-Dialysis:</strong> Monitor BP every 30 min for intradialytic hypotension, maintain heparinization, and watch for air embolism or muscle cramps.</li>
              <li><strong>Dialysis Disequilibrium Syndrome:</strong> Rapid urea clearance from blood vs CSF causes cerebral edema (headache, nausea, seizures); slow blood flow rate and notify physician.</li>
            </ul>
          </div>
        </div>
      `},{id:`grp-msn-myasthenia`,title:`Myasthenia Gravis & Guillain-Barré Syndrome (GBS)`,repeatCount:2,years:[`2020`,`2025`],subItems:[{concept:`Pathophysiology (acetylcholine receptor antibodies) & Tensilon (Edrophonium) test`,years:`2020, 2025`},{concept:`Myasthenic crisis vs Cholinergic crisis & airway management`,years:`2025`}],questions:[{paperBadge:`MPMSU Feb 2025 (Supp) — Short Note [5 Marks]`,weight:`Short Note | Target: 2–3 Handwritten Pages`,questionText:`Explain Myasthenia Gravis: clinical manifestations, diagnostic evaluation, and nursing management.`},{paperBadge:`MPMSU 2020 — Short Answer [3 Marks]`,weight:`Short Answer | Target: 1–2 Handwritten Pages`,questionText:`Differentiate between Myasthenic Crisis and Cholinergic Crisis.`}],answerHtml:`
        <div class="concept-card">
          <div class="concept-title">1. Definition & Pathophysiology</div>
          <div class="concept-body">
            <p><strong>Myasthenia Gravis</strong> is a chronic autoimmune neuromuscular junction disorder characterized by IgG autoantibodies directed against postsynaptic nicotinic acetylcholine receptors (AChR), resulting in fluctuating weakness of voluntary skeletal muscles that worsens with activity and improves with rest.</p>
          </div>
        </div>
        <div class="concept-card">
          <div class="concept-title">2. Clinical Manifestations & Diagnosis</div>
          <div class="concept-body">
            <ul>
              <li><strong>Ocular Symptoms (Early):</strong> Ptosis (drooping eyelids) and diplopia (double vision).</li>
              <li><strong>Bulbar & Respiratory:</strong> Dysphagia, dysarthria, weak cough, and progressive respiratory muscle fatigue.</li>
              <li><strong>Diagnosis:</strong> Anti-AChR antibody titer, Repetitive Nerve Stimulation (decremental response), Ice-pack test, and Edrophonium (Tensilon) test (transient improvement within 30–60 sec).</li>
            </ul>
          </div>
        </div>
        <div class="concept-card">
          <div class="concept-title">3. Pharmacological & Nursing Management</div>
          <div class="concept-body">
            <ul>
              <li><strong>Anticholinesterases:</strong> Pyridostigmine (Mestinon) given 30–45 minutes before meals to optimize chewing and swallowing.</li>
              <li><strong>Immunotherapy & Thymectomy:</strong> Corticosteroids, azathioprine, plasmapheresis / IVIG in acute crisis.</li>
              <li><strong>Myasthenic vs Cholinergic Crisis:</strong> Myasthenic crisis = under-medication (needs more neostigmine + ventilator support); Cholinergic crisis = over-medication (SLUDGE symptoms, requires atropine).</li>
            </ul>
          </div>
        </div>
      `},{id:`grp-msn-fracture-traction`,title:`Fractures, Plaster Cast Care & Traction Nursing Management`,repeatCount:2,years:[`2019`,`2020`],subItems:[{concept:`Stages of bone healing & Compartment Syndrome (6 P's)`,years:`2019, 2020`},{concept:`Skin vs Skeletal traction & nursing principles`,years:`2020`}],questions:[{paperBadge:`MPMSU 2020 — Short Essay [5 Marks]`,weight:`Short Essay | Target: 2–3 Handwritten Pages`,questionText:`Describe the principles of Traction and nursing care of a patient with Skeletal Traction.`},{paperBadge:`NTRUHS 2019 — Short Note [5 Marks]`,weight:`Short Note | Target: 2 Handwritten Pages`,questionText:`Explain Compartment Syndrome and stages of fracture healing.`}],answerHtml:`
        <div class="concept-card">
          <div class="concept-title">1. Principles of Effective Traction</div>
          <div class="concept-body">
            <ul>
              <li>Maintain continuous pull; never remove weights without a physician's order.</li>
              <li>Weights must hang freely off the floor and not rest on bed frames.</li>
              <li>Maintain proper body alignment and counter-traction (patient's body weight / slight elevation of foot of bed).</li>
              <li>Ropes must remain unobstructed in pulley grooves and knots secured tightly.</li>
            </ul>
          </div>
        </div>
        <div class="concept-card">
          <div class="concept-title">2. Neurovascular Assessment (6 P's of Compartment Syndrome)</div>
          <div class="concept-body">
            <p>Check every 1–2 hours distal to the cast/traction: <strong>Pain</strong> (unrelieved by opioids, worst on passive stretch), <strong>Pallor</strong>, <strong>Pulselessness</strong>, <strong>Paresthesia</strong>, <strong>Paralysis</strong>, and <strong>Poikilothermia</strong> (coolness). Immediate fasciotomy is required if compartment pressure rises.</p>
          </div>
        </div>
      `},{id:`grp-msn-disaster-nursing`,title:`Disaster Nursing, Phases & Disaster Management Cycle`,repeatCount:1,years:[`2025`],subItems:[{concept:`Mitigation, Preparedness, Response, Recovery & Rehabilitation`,years:`2025`},{concept:`Role of nurse during mass casualty & psychological first aid`,years:`2025`}],questions:[{paperBadge:`MPMSU Feb 2025 (Supp) — Short Essay [5 Marks]`,weight:`Short Essay | Target: 2–3 Handwritten Pages`,questionText:`Define Disaster. Explain the Disaster Management Cycle and the role of a nurse in disaster preparedness and response.`}],answerHtml:`
        <div class="concept-card">
          <div class="concept-title">1. Definition & Types of Disasters</div>
          <div class="concept-body">
            <p>A <strong>Disaster</strong> is a serious disruption of the functioning of a community or society causing widespread human, material, economic, or environmental losses exceeding the ability of the affected community to cope using its own resources. Classified into Natural (earthquakes, floods, cyclones) and Man-made (industrial chemical leaks, transport accidents, bioterrorism).</p>
          </div>
        </div>
        <div class="concept-card">
          <div class="concept-title">2. Disaster Management Cycle & Nursing Roles</div>
          <div class="concept-body">
            <ul>
              <li><strong>Mitigation:</strong> Hazard mapping, structural safety, public health policy.</li>
              <li><strong>Preparedness:</strong> Hospital disaster drills, stockpiling emergency kits, staff training, communication trees.</li>
              <li><strong>Response:</strong> Rapid Triage (Red-Immediate, Yellow-Delayed, Green-Minimal, Black-Expectant), airway/hemorrhage stabilization, infection control, safe shelter & water sanitation.</li>
              <li><strong>Recovery & Rehabilitation:</strong> Long-term wound care, prosthetic/mobility rehab, PTSD & grief counseling, epidemiological disease surveillance.</li>
            </ul>
          </div>
        </div>
      `},{id:`grp-msn-dermatology-psoriasis`,title:`Psoriasis, Pemphigus Vulgaris & Burn-like Dermatoses`,repeatCount:1,years:[`2022`],subItems:[{concept:`Silvery scales, Auspitz sign, PUVA therapy & topical corticosteroids`,years:`2022`}],questions:[{paperBadge:`MPMSU 2022 — Short Note [5 Marks]`,weight:`Short Note | Target: 2 Handwritten Pages`,questionText:`Define Psoriasis. Write its clinical manifestations, diagnostic signs, and nursing management.`}],answerHtml:`
        <div class="concept-card">
          <div class="concept-title">1. Pathophysiology & Clinical Features</div>
          <div class="concept-body">
            <p><strong>Psoriasis</strong> is a chronic, non-infectious, immune-mediated inflammatory skin disorder marked by accelerated epidermal keratinocyte turnover (3–4 days instead of 28 days), leading to well-demarcated erythematous plaques topped with thick silvery-white scales over extensor surfaces (elbows, knees, scalp).</p>
            <ul>
              <li><strong>Auspitz Sign:</strong> Pinpoint bleeding when scales are gently scraped off.</li>
              <li><strong>Koebner Phenomenon:</strong> Appearance of new psoriatic lesions at sites of skin trauma.</li>
            </ul>
          </div>
        </div>
        <div class="concept-card">
          <div class="concept-title">2. Medical & Nursing Management</div>
          <div class="concept-body">
            <ul>
              <li><strong>Topical:</strong> Emollients, salicylic acid keratolytics, calcipotriene (Vitamin D analog), coal tar, corticosteroids.</li>
              <li><strong>Phototherapy & Systemic:</strong> Narrowband UVB, PUVA (Psoralen + UVA), Methotrexate, Cyclosporine, Biologics (anti-TNF).</li>
              <li><strong>Nursing Care:</strong> Advise gentle bathing with lukewarm water, avoid scratching, moisturize immediately post-bath, and provide psychosocial support for body image disturbance.</li>
            </ul>
          </div>
        </div>
      `},{id:`grp-msn-hiv-aids`,title:`HIV / AIDS, Opportunistic Infections & Post-Exposure Prophylaxis (PEP)`,repeatCount:1,years:[`2019`],subItems:[{concept:`CD4 count monitoring, ART regimen & Needle-stick injury PEP protocol`,years:`2019`}],questions:[{paperBadge:`NTRUHS 2019 — Short Note [5 Marks]`,weight:`Short Note | Target: 2 Handwritten Pages`,questionText:`Explain Post-Exposure Prophylaxis (PEP) for needle-stick injury and nursing care of a patient with HIV/AIDS.`}],answerHtml:`
        <div class="concept-card">
          <div class="concept-title">1. Immediate Needle-Stick Injury & PEP Protocol</div>
          <div class="concept-body">
            <ul>
              <li>Wash wound immediately with soap and running water (do NOT squeeze or apply bleach/caustic agents).</li>
              <li>Report immediately to Infection Control Officer / ICTC and test source & exposed healthcare worker.</li>
              <li><strong>PEP Initiation:</strong> Start 3-drug Antiretroviral Therapy (Tenofovir + Lamivudine + Dolutegravir) ideally within <strong>2 hours</strong> (and no later than 72 hours) for 28 days.</li>
            </ul>
          </div>
        </div>
        <div class="concept-card">
          <div class="concept-title">2. Nursing Care & Opportunistic Infection Prevention</div>
          <div class="concept-body">
            <p>Monitor CD4+ T-cell counts (&lt;200 cells/mm³ defines AIDS) and viral load; enforce strict hand hygiene and neutropenic/food-safety precautions to prevent <em>Pneumocystis jirovecii</em> pneumonia (PCP), oral candidiasis, and tuberculosis; provide high-calorie, high-protein nutrition and strict ART adherence counseling.</p>
          </div>
        </div>
      `}],chn:[{id:`grp-chn-chd-tof`,title:`Congenital Heart Diseases & Tetralogy of Fallot (TOF)`,repeatCount:2,years:[`2019`,`2022`],subItems:[{concept:`4 defects of TOF, Tet spells (hypercyanotic spells) & knee-chest position`,years:`2019, 2022`},{concept:`Acyanotic vs Cyanotic CHD classification & Blalock-Taussig shunt`,years:`2022`}],questions:[{paperBadge:`MPMSU 2022 — Long Essay [10 Marks]`,weight:`Essay Question | Target: 3–4 Handwritten Pages`,questionText:`Classify Congenital Heart Diseases. Describe the pathophysiology, clinical features, and emergency nursing management of a child with Tetralogy of Fallot.`},{paperBadge:`NTRUHS 2019 — Short Note [5 Marks]`,weight:`Short Note | Target: 2 Handwritten Pages`,questionText:`Write nursing management of a child experiencing a Hypercyanotic ('Tet') Spell.`}],answerHtml:`
        <div class="concept-card">
          <div class="concept-title">1. Classification & Four Defects of TOF</div>
          <div class="concept-body">
            <p><strong>Acyanotic (Left-to-Right shunt):</strong> VSD, ASD, PDA. <strong>Cyanotic (Right-to-Left shunt):</strong> Tetralogy of Fallot (TOF), Transposition of Great Arteries (TGA).</p>
            <p><strong>Four Anatomical Defects of Tetralogy of Fallot (PROVe):</strong></p>
            <ul>
              <li><strong>P</strong>ulmonary Stenosis (right ventricular outflow tract obstruction)</li>
              <li><strong>R</strong>ight Ventricular Hypertrophy (boot-shaped heart on X-ray)</li>
              <li><strong>O</strong>verriding Aorta (aorta sits over the VSD)</li>
              <li><strong>Ve</strong>ntricular Septal Defect (large VSD)</li>
            </ul>
          </div>
        </div>
        <div class="concept-card">
          <div class="concept-title">2. Emergency Management of a Hypercyanotic ('Tet') Spell</div>
          <div class="concept-body">
            <ul>
              <li><strong>Position:</strong> Immediately place the child in the <strong>Knee-Chest (Squatting) Position</strong> to increase systemic vascular resistance and force blood back into the pulmonary artery.</li>
              <li><strong>Oxygen & Calming:</strong> Administer 100% humidified oxygen and calm the child/parents to reduce oxygen demand.</li>
              <li><strong>Medications:</strong> IV Morphine sulfate (decreases infundibular spasm and respiratory drive), IV fluids, and Propranolol/Sodium bicarbonate if acidotic.</li>
            </ul>
          </div>
        </div>
      `},{id:`grp-chn-cleft-lip-palate`,title:`Cleft Lip & Cleft Palate (Pre & Post-Operative Care)`,repeatCount:2,years:[`2020`,`2025`],subItems:[{concept:`Rule of 10s for cheiloplasty & palatoplasty timing`,years:`2020, 2025`},{concept:`ESSR feeding technique & suture line protection (Logan bow, elbow restraints)`,years:`2025`}],questions:[{paperBadge:`MPMSU Feb 2025 (Supp) — Short Essay [5 Marks]`,weight:`Short Essay | Target: 2–3 Handwritten Pages`,questionText:`Describe the feeding techniques and pre- & post-operative nursing management of an infant with Cleft Lip and Cleft Palate.`}],answerHtml:`
        <div class="concept-card">
          <div class="concept-title">1. Surgical Timing & Feeding Techniques</div>
          <div class="concept-body">
            <ul>
              <li><strong>Cleft Lip Repair (Cheiloplasty):</strong> Performed at 3 months using the <em>Rule of 10s</em> (10 weeks old, 10 lbs weight, Hb &ge;10 g/dL).</li>
              <li><strong>Cleft Palate Repair (Palatoplasty):</strong> Performed around 12–18 months before speech development.</li>
              <li><strong>ESSR Feeding Technique:</strong> <strong>E</strong>nlarge nipple opening, <strong>S</strong>timulate suck reflex, <strong>S</strong>wallow upright (45–60°), <strong>R</strong>est & burp frequently to prevent aspiration and otitis media.</li>
            </ul>
          </div>
        </div>
        <div class="concept-card">
          <div class="concept-title">2. Post-Operative Nursing Care</div>
          <div class="concept-body">
            <ul>
              <li><strong>Positioning:</strong> Side-lying or supine after cleft lip repair (never prone, to prevent rubbing suture line); prone/side-lying after palate repair for drainage.</li>
              <li><strong>Suture Protection:</strong> Apply elbow restraints (remove every 2 hrs for ROM), use Logan bow if ordered, avoid pacifiers, straws, spoons, or hard objects in mouth, and clean suture line gently with sterile normal saline after every feed.</li>
            </ul>
          </div>
        </div>
      `},{id:`grp-chn-hirschsprung`,title:`Hirschsprung's Disease (Congenital Aganglionic Megacolon)`,repeatCount:2,years:[`2019`,`2020`],subItems:[{concept:`Absence of Meissner's & Auerbach's ganglion cells, ribbon-like stools, enterocolitis`,years:`2019, 2020`}],questions:[{paperBadge:`MPMSU 2020 — Short Note [5 Marks]`,weight:`Short Note | Target: 2 Handwritten Pages`,questionText:`Define Hirschsprung's disease. Explain its pathophysiology, clinical manifestations, and surgical nursing care.`}],answerHtml:`
        <div class="concept-card">
          <div class="concept-title">1. Pathophysiology & Clinical Signs</div>
          <div class="concept-body">
            <p><strong>Hirschsprung's Disease</strong> is a congenital anomaly caused by the absence of parasympathetic ganglion cells (Meissner's and Auerbach's plexuses) in the distal colon/rectum, leading to absent peristalsis, functional obstruction, and proximal colonic dilation (megacolon).</p>
            <ul>
              <li><strong>Neonatal Signs:</strong> Failure to pass meconium within 24–48 hours, bilious vomiting, abdominal distension.</li>
              <li><strong>Older Child:</strong> Chronic constipation, foul-smelling <strong>ribbon-like stools</strong>, failure to thrive.</li>
              <li><strong>Diagnosis:</strong> Rectal biopsy (gold standard confirming absent ganglion cells), Barium enema (transition zone).</li>
            </ul>
          </div>
        </div>
        <div class="concept-card">
          <div class="concept-title">2. Surgical & Nursing Management</div>
          <div class="concept-body">
            <p>Two-stage repair: temporary diverting colostomy followed by definitive pull-through procedure (Swenson/Duhamel/Soave). Pre-op nursing: isotonic saline bowel irrigations (never tap water enemas due to water intoxication), measure abdominal girth daily, watch closely for toxic enterocolitis (explosive watery diarrhea, fever, shock).</p>
          </div>
        </div>
      `},{id:`grp-chn-jaundice`,title:`Neonatal Hyperbilirubinemia (Jaundice) & Phototherapy Care`,repeatCount:2,years:[`2020`,`2022`],subItems:[{concept:`Physiological vs Pathological jaundice, Kernicterus & Phototherapy nursing protocol`,years:`2020, 2022`}],questions:[{paperBadge:`MPMSU 2022 — Short Note [5 Marks]`,weight:`Short Note | Target: 2 Handwritten Pages`,questionText:`Differentiate Physiological and Pathological Neonatal Jaundice. Explain nursing care of a newborn under Phototherapy.`}],answerHtml:`
        <div class="concept-card">
          <div class="concept-title">1. Physiological vs Pathological Jaundice</div>
          <div class="concept-body">
            <ul>
              <li><strong>Physiological:</strong> Appears after 24 hours of life, peaks day 3–5 (&lt;12 mg/dL), resolves by 7–10 days.</li>
              <li><strong>Pathological:</strong> Appears within <strong>first 24 hours</strong>, bilirubin rises &gt;5 mg/dL/day or exceeds 15 mg/dL, persistent &gt;2 weeks. Risk of <strong>Kernicterus</strong> (bilirubin encephalopathy).</li>
            </ul>
          </div>
        </div>
        <div class="concept-card">
          <div class="concept-title">2. Nursing Care During Phototherapy (420–470 nm Blue Light)</div>
          <div class="concept-body">
            <ul>
              <li>Shield eyes completely with opaque eye patches and cover genitalia/gonads.</li>
              <li>Keep infant naked except diaper/eye shield, placed 35–45 cm from light source; turn every 2 hours.</li>
              <li>Monitor temperature every 2–4 hours, maintain hydration (encourage frequent breastfeeding + 10–20% extra fluid allowance), and track urine/stool output (greenish loose stools are expected).</li>
            </ul>
          </div>
        </div>
      `},{id:`grp-chn-tef`,title:`Tracheoesophageal Fistula (TEF) & Esophageal Atresia`,repeatCount:1,years:[`2025`],subItems:[{concept:`3 C's (Coughing, Choking, Cyanosis), frothy saliva & Replogle suction`,years:`2025`}],questions:[{paperBadge:`MPMSU Feb 2025 (Supp) — Short Answer [3 Marks]`,weight:`Short Answer | Target: 1–2 Handwritten Pages`,questionText:`Write the clinical features (3 C's) and immediate nursing management of a newborn with Tracheoesophageal Fistula.`}],answerHtml:`
        <div class="concept-card">
          <div class="concept-title">1. Clinical Recognition (3 C's) & Management</div>
          <div class="concept-body">
            <p>Suspect TEF/Esophageal Atresia in a neonate with maternal polyhydramnios, excessive frothy white oral secretions, and the <strong>3 C's during first feed: Coughing, Choking, and Cyanosis</strong>, plus inability to pass a nasogastric tube (coils in blind upper pouch).</p>
            <ul>
              <li><strong>Immediate Action:</strong> Keep strictly <strong>NPO</strong>, elevate head 30–45° (to prevent gastric reflux through fistula into lungs), maintain continuous low-intermittent suction of upper esophageal pouch (Replogle tube), administer IV fluids and broad-spectrum antibiotics prior to primary surgical anastomosis.</li>
            </ul>
          </div>
        </div>
      `},{id:`grp-chn-underfive`,title:`Under-Five Clinic (Well Baby Clinic) & Play Therapy`,repeatCount:1,years:[`2019`],subItems:[{concept:`5 components of Under-Five Clinic symbol & therapeutic play for hospitalized children`,years:`2019`}],questions:[{paperBadge:`NTRUHS 2019 — Short Note [5 Marks]`,weight:`Short Note | Target: 2 Handwritten Pages`,questionText:`Explain the aims and components of an Under-Five Clinic with its standard emblem.`}],answerHtml:`
        <div class="concept-card">
          <div class="concept-title">1. Emblem & Five Core Services</div>
          <div class="concept-body">
            <p>The <strong>Under-Five Clinic</strong> integrates preventive, promotive, curative, referral, and educational services for children aged 0–5 years, represented by the triangular emblem:</p>
            <ul>
              <li><strong>Apex:</strong> Care in Illness (diagnosis & treatment of acute respiratory infections, diarrhea, malnutrition).</li>
              <li><strong>Left Side:</strong> Adequate Nutrition & Growth Monitoring (Road-to-Health card).</li>
              <li><strong>Right Side:</strong> Immunization & Preventive Care (NIS vaccines, Vitamin A).</li>
              <li><strong>Center (Inverted Triangle):</strong> Family Planning & Spacing.</li>
              <li><strong>Outer Border:</strong> Health Education for Mothers.</li>
            </ul>
          </div>
        </div>
      `}],mhn:[{id:`grp-mhn-substance-abuse`,title:`Alcohol Dependence Syndrome, Withdrawal (Delirium Tremens) & De-addiction`,repeatCount:2,years:[`2019`,`2022`],subItems:[{concept:`Wernicke-Korsakoff syndrome, Delirium Tremens, Disulfiram & Benzodiazepines`,years:`2019, 2022`}],questions:[{paperBadge:`MPMSU 2022 — Long Essay [10 Marks]`,weight:`Essay Question | Target: 3–4 Handwritten Pages`,questionText:`Define Alcohol Dependence Syndrome. Describe withdrawal symptoms, Delirium Tremens, and comprehensive nursing management including rehabilitation.`},{paperBadge:`NTRUHS 2019 — Short Answer [3 Marks]`,weight:`Short Answer | Target: 1–2 Handwritten Pages`,questionText:`Explain Disulfiram (Antabuse) therapy and patient education.`}],answerHtml:`
        <div class="concept-card">
          <div class="concept-title">1. Alcohol Withdrawal & Delirium Tremens (DTs)</div>
          <div class="concept-body">
            <ul>
              <li><strong>Early Withdrawal (6–24 hrs):</strong> Coarse hand tremors, diaphoresis, tachycardia, anxiety, insomnia.</li>
              <li><strong>Delirium Tremens (48–72 hrs):</strong> Life-threatening emergency marked by severe agitation, autonomic instability (fever, hypertension), disorientation, and vivid visual/tactile hallucinations (formication).</li>
            </ul>
          </div>
        </div>
        <div class="concept-card">
          <div class="concept-title">2. Medical & Nursing Management</div>
          <div class="concept-body">
            <ul>
              <li><strong>Detoxification:</strong> Long-acting Benzodiazepines (Chlordiazepoxide or Lorazepam) guided by CIWA-Ar score to prevent seizures.</li>
              <li><strong>Thiamine (Vitamin B1):</strong> Administer IV/IM Thiamine <strong>before</strong> glucose infusions to prevent Wernicke's encephalopathy.</li>
              <li><strong>Relapse Prevention:</strong> Disulfiram (educate strictly to avoid hidden alcohol in mouthwash, perfumes, cough syrups), Naltrexone, Acamprosate, and Alcoholics Anonymous (AA) group support.</li>
            </ul>
          </div>
        </div>
      `},{id:`grp-mhn-phobia-anxiety`,title:`Phobic Disorders, Generalized Anxiety & Systematic Desensitization`,repeatCount:2,years:[`2020`,`2025`],subItems:[{concept:`Agoraphobia, Social Phobia, Flooding vs Systematic Desensitization`,years:`2020, 2025`}],questions:[{paperBadge:`MPMSU Feb 2025 (Supp) — Short Essay [5 Marks]`,weight:`Short Essay | Target: 2–3 Handwritten Pages`,questionText:`Define Phobia. Classify types of phobias and explain behavioral therapies (Systematic Desensitization & Flooding) with nursing management.`}],answerHtml:`
        <div class="concept-card">
          <div class="concept-title">1. Classification & Clinical Picture</div>
          <div class="concept-body">
            <p>A <strong>Phobia</strong> is an irrational, persistent, intense fear of a specific object, activity, or situation that leads to compelling avoidance behavior despite the person recognizing the fear is excessive.</p>
            <ul>
              <li><strong>Agoraphobia:</strong> Fear of open spaces, crowds, or places where escape is difficult.</li>
              <li><strong>Social Phobia:</strong> Fear of scrutiny or embarrassment in social/performance settings.</li>
              <li><strong>Specific Phobia:</strong> Acrophobia (heights), Claustrophobia (closed spaces), Zoophobia (animals).</li>
            </ul>
          </div>
        </div>
        <div class="concept-card">
          <div class="concept-title">2. Behavioral & Nursing Management</div>
          <div class="concept-body">
            <ul>
              <li><strong>Systematic Desensitization (Wolpe):</strong> 3 steps — Relaxation training (Jacobson's PMR), constructing an anxiety hierarchy, and gradual graded exposure while relaxed.</li>
              <li><strong>Flooding:</strong> Immediate prolonged exposure to the most feared stimulus until anxiety peaks and extinguishes (never force without informed consent).</li>
              <li><strong>Pharmacotherapy:</strong> SSRIs (Fluoxetine/Sertraline), Propranolol for performance anxiety, short-term Benzodiazepines.</li>
            </ul>
          </div>
        </div>
      `},{id:`grp-mhn-dementia-delirium`,title:`Delirium vs Dementia (Organic Mental Disorders)`,repeatCount:2,years:[`2019`,`2022`],subItems:[{concept:`Onset, consciousness, reversibility, sundowning & safety interventions`,years:`2019, 2022`}],questions:[{paperBadge:`MPMSU 2022 — Short Essay [5 Marks]`,weight:`Short Essay | Target: 2–3 Handwritten Pages`,questionText:`Differentiate between Delirium and Dementia. Describe nursing management of a patient with Alzheimer's Dementia.`}],answerHtml:`
        <div class="concept-card">
          <div class="concept-title">1. Differential Comparison: Delirium vs Dementia</div>
          <div class="concept-body">
            <table class="ans-table">
              <thead><tr><th>Feature</th><th>Delirium</th><th>Dementia</th></tr></thead>
              <tbody>
                <tr><td>Onset</td><td>Acute / Sudden (hours to days)</td><td>Insidious / Gradual (months to years)</td></tr>
                <tr><td>Consciousness</td><td>Clouded, fluctuating attention</td><td>Clear until late terminal stages</td></tr>
                <tr><td>Course</td><td>Fluctuates (worse at night / sundowning)</td><td>Chronic, progressive decline</td></tr>
                <tr><td>Prognosis</td><td>Usually reversible when cause treated</td><td>Largely irreversible (Alzheimer's, Vascular)</td></tr>
              </tbody>
            </table>
          </div>
        </div>
        <div class="concept-card">
          <div class="concept-title">2. Nursing Care in Dementia</div>
          <div class="concept-body">
            <p>Maintain structured daily routines, place large clocks/calendars for reality orientation, use short simple sentences, prevent wandering with ID bracelets and safe low-bed environment, and avoid arguing when patient confabulates (use validation and gentle redirection).</p>
          </div>
        </div>
      `},{id:`grp-mhn-tnpr`,title:`Therapeutic Nurse-Patient Relationship (Peplau's Phases) & Communication`,repeatCount:2,years:[`2020`,`2025`],subItems:[{concept:`Pre-interaction, Orientation, Working & Termination phases; Transference/Countertransference`,years:`2020, 2025`}],questions:[{paperBadge:`MPMSU Feb 2025 (Supp) — Short Essay [5 Marks]`,weight:`Short Essay | Target: 2–3 Handwritten Pages`,questionText:`Describe the phases of a Therapeutic Nurse-Patient Relationship and explain therapeutic communication techniques.`}],answerHtml:`
        <div class="concept-card">
          <div class="concept-title">1. Four Phases of Peplau's Therapeutic Relationship</div>
          <div class="concept-body">
            <ul>
              <li><strong>Pre-Interaction Phase:</strong> Nurse reviews chart and explores own biases/anxieties before meeting the patient.</li>
              <li><strong>Orientation Phase:</strong> Establishing trust, rapport, confidentiality boundaries, and defining contract/goals.</li>
              <li><strong>Working Phase:</strong> Exploring stressors, overcoming resistance/transference, developing adaptive coping skills.</li>
              <li><strong>Termination Phase:</strong> Summarizing progress, preparing for discharge, and resolving separation anxiety.</li>
            </ul>
          </div>
        </div>
      `},{id:`grp-mhn-suicide`,title:`Suicide Risk Assessment & Psychiatric Emergency Prevention`,repeatCount:1,years:[`2022`],subItems:[{concept:`SAD PERSONS scale, Warning signs & One-to-One observation protocol`,years:`2022`}],questions:[{paperBadge:`MPMSU 2022 — Short Note [5 Marks]`,weight:`Short Note | Target: 2 Handwritten Pages`,questionText:`List the risk factors for suicide and describe nursing prevention & safety protocols in an inpatient psychiatric ward.`}],answerHtml:`
        <div class="concept-card">
          <div class="concept-title">1. Risk Assessment & Immediate Inpatient Safety</div>
          <div class="concept-body">
            <ul>
              <li><strong>High-Risk Indicators:</strong> Specific lethal plan, prior attempt, hopelessness, sudden calm after severe depression, giving away prized possessions.</li>
              <li><strong>Ward Safety Protocol:</strong> Place on continuous <strong>1:1 constant observation</strong>, remove all sharp objects, belts, shoelaces, glass, and cords; perform mouth checks after medication administration ("cheeking"); establish a no-harm safety contract and notify psychiatrist immediately.</li>
            </ul>
          </div>
        </div>
      `},{id:`grp-mhn-personality`,title:`Personality Disorders (Cluster A, B, C) & Eating Disorders`,repeatCount:1,years:[`2019`],subItems:[{concept:`Borderline (splitting), Antisocial, Anorexia Nervosa vs Bulimia Nervosa`,years:`2019`}],questions:[{paperBadge:`NTRUHS 2019 — Short Note [5 Marks]`,weight:`Short Note | Target: 2 Handwritten Pages`,questionText:`Classify Personality Disorders and explain nursing management of Borderline Personality Disorder.`}],answerHtml:`
        <div class="concept-card">
          <div class="concept-title">1. Classification & Nursing Approach</div>
          <div class="concept-body">
            <ul>
              <li><strong>Cluster A (Odd/Eccentric):</strong> Paranoid, Schizoid, Schizotypal.</li>
              <li><strong>Cluster B (Dramatic/Erratic):</strong> Antisocial, Borderline (impulsivity, self-harm, splitting), Histrionic, Narcissistic.</li>
              <li><strong>Cluster C (Anxious/Fearful):</strong> Avoidant, Dependent, Obsessive-Compulsive.</li>
              <li><strong>Nursing Care for BPD:</strong> Maintain firm, consistent team-wide limit setting to prevent staff <em>splitting</em>, validate feelings without reinforcing self-harm, and encourage Dialectical Behavior Therapy (DBT).</li>
            </ul>
          </div>
        </div>
      `}],stats:[{id:`grp-stats-design`,title:`Research Designs (Experimental, Quasi-Experimental & Non-Experimental)`,repeatCount:2,years:[`2019`,`2022`],subItems:[{concept:`True experimental (Randomization, Control, Manipulation) vs Quasi-experimental`,years:`2019, 2022`},{concept:`Descriptive, Correlational, Cohort & Case-Control designs`,years:`2022`}],questions:[{paperBadge:`MPMSU 2022 — Long Essay [10 Marks]`,weight:`Essay Question | Target: 3–4 Handwritten Pages`,questionText:`Define Research Design. Classify research designs and differentiate between True Experimental and Quasi-Experimental designs with nursing examples.`}],answerHtml:`
        <div class="concept-card">
          <div class="concept-title">1. Definition & Pillars of True Experimental Design</div>
          <div class="concept-body">
            <p>A <strong>Research Design</strong> is the overall architectural blueprint or plan for conducting a study to answer research questions and control extraneous variables.</p>
            <ul>
              <li><strong>Manipulation:</strong> Researcher introduces an intervention/treatment to the experimental group.</li>
              <li><strong>Control:</strong> Use of a comparison/control group receiving standard care or placebo.</li>
              <li><strong>Randomization:</strong> Every participant has an equal chance of assignment to experimental or control group.</li>
            </ul>
            <p><strong>Quasi-Experimental Design:</strong> Lacks either randomization or a control group (e.g., Non-equivalent control group pretest-posttest design).</p>
          </div>
        </div>
      `},{id:`grp-stats-hypothesis`,title:`Hypothesis: Types, Characteristics & Formulation`,repeatCount:2,years:[`2020`,`2025`],subItems:[{concept:`Null (H0) vs Research (H1), Simple vs Complex, Directional vs Non-directional`,years:`2020, 2025`}],questions:[{paperBadge:`MPMSU Feb 2025 (Supp) — Short Essay [5 Marks]`,weight:`Short Essay | Target: 2–3 Handwritten Pages`,questionText:`Define Hypothesis. Explain its types and criteria of a good research hypothesis with examples.`}],answerHtml:`
        <div class="concept-card">
          <div class="concept-title">1. Definition & Classification of Hypothesis</div>
          <div class="concept-body">
            <p>A <strong>Hypothesis</strong> is a tentative, testable statement of the predicted relationship between two or more variables.</p>
            <ul>
              <li><strong>Null Hypothesis (H0):</strong> States there is NO statistically significant relationship/difference between variables.</li>
              <li><strong>Alternative/Research Hypothesis (H1):</strong> States a relationship/difference exists.</li>
              <li><strong>Directional vs Non-directional:</strong> Directional predicts the exact direction (e.g., "increases" or "decreases"); Non-directional states a difference exists without specifying direction.</li>
            </ul>
          </div>
        </div>
      `},{id:`grp-stats-data-collection`,title:`Data Collection Methods & Tools (Questionnaire, Interview, Observation)`,repeatCount:2,years:[`2019`,`2020`],subItems:[{concept:`Structured vs Unstructured, Likert Scale, Advantages & Limitations`,years:`2019, 2020`}],questions:[{paperBadge:`MPMSU 2020 — Short Essay [5 Marks]`,weight:`Short Essay | Target: 2–3 Handwritten Pages`,questionText:`Describe the various methods of data collection in nursing research. Compare Questionnaire and Interview methods.`}],answerHtml:`
        <div class="concept-card">
          <div class="concept-title">1. Methods & Comparison</div>
          <div class="concept-body">
            <ul>
              <li><strong>Questionnaire:</strong> Self-administered paper/digital forms; economical for large samples, preserves anonymity, but lower response rate and requires literacy.</li>
              <li><strong>Interview:</strong> Face-to-face or telephonic verbal questioning; high response rate, allows clarification and observation of non-verbal cues, but time-consuming and prone to interviewer bias.</li>
              <li><strong>Observation & Biophysiologic Measures:</strong> Checklist/rating scale observation and clinical instruments (BP, HbA1c, pulse oximetry).</li>
            </ul>
          </div>
        </div>
      `},{id:`grp-stats-reliability-validity`,title:`Reliability & Validity of Research Instruments`,repeatCount:2,years:[`2020`,`2022`],subItems:[{concept:`Test-retest, Split-half, Cronbach's alpha; Content, Construct & Criterion validity`,years:`2020, 2022`}],questions:[{paperBadge:`MPMSU 2022 — Short Note [5 Marks]`,weight:`Short Note | Target: 2 Handwritten Pages`,questionText:`Define Reliability and Validity. Explain their types and relationship in nursing research.`}],answerHtml:`
        <div class="concept-card">
          <div class="concept-title">1. Reliability vs Validity</div>
          <div class="concept-body">
            <p><strong>Reliability</strong> is the consistency, stability, and repeatability of an instrument (Test-retest, Inter-rater, Split-half, Cronbach's alpha &ge; 0.70).</p>
            <p><strong>Validity</strong> is the degree to which an instrument accurately measures what it is intended to measure (Face, Content, Construct, and Criterion-related validity). <em>Note: A reliable tool is not always valid, but a valid tool must always be reliable.</em></p>
          </div>
        </div>
      `},{id:`grp-stats-npc`,title:`Normal Probability Curve (NPC) & Properties`,repeatCount:2,years:[`2019`,`2025`],subItems:[{concept:`Bell-shaped symmetrical curve, Mean=Median=Mode, 68-95-99.7% rule & Skewness`,years:`2019, 2025`}],questions:[{paperBadge:`MPMSU Feb 2025 (Supp) — Short Note [5 Marks]`,weight:`Short Note | Target: 2 Handwritten Pages`,questionText:`Explain the characteristics and applications of a Normal Probability Curve (NPC) in nursing statistics.`}],answerHtml:`
        <div class="concept-card">
          <div class="concept-title">1. Characteristics of Normal Probability Curve</div>
          <div class="concept-body">
            <ul>
              <li>Bell-shaped, bilaterally symmetrical, and unimodal; Mean = Median = Mode at the center.</li>
              <li>Tails are asymptotic to the X-axis (never touch the baseline).</li>
              <li><strong>Empirical Rule:</strong> Mean ± 1 SD covers <strong>68.26%</strong>, Mean ± 2 SD covers <strong>95.44%</strong>, and Mean ± 3 SD covers <strong>99.72%</strong> of all observations.</li>
              <li><strong>Skewness:</strong> Positive skew (tail right, Mean &gt; Median &gt; Mode); Negative skew (tail left, Mean &lt; Median &lt; Mode).</li>
            </ul>
          </div>
        </div>
      `},{id:`grp-stats-ethics`,title:`Ethical Principles in Nursing Research & Informed Consent`,repeatCount:1,years:[`2025`],subItems:[{concept:`Beneficence, Respect for Human Dignity, Justice, IRB & Informed Consent`,years:`2025`}],questions:[{paperBadge:`MPMSU Feb 2025 (Supp) — Short Answer [3 Marks]`,weight:`Short Answer | Target: 1–2 Handwritten Pages`,questionText:`Discuss the Belmont ethical principles and elements of Informed Consent in nursing research.`}],answerHtml:`
        <div class="concept-card">
          <div class="concept-title">1. Core Ethical Principles & Informed Consent</div>
          <div class="concept-body">
            <ul>
              <li><strong>Beneficence:</strong> Freedom from harm and maximizing benefits over risks.</li>
              <li><strong>Respect for Human Dignity:</strong> Right to self-determination (voluntary participation & right to withdraw anytime) and full disclosure.</li>
              <li><strong>Justice:</strong> Fair treatment and right to privacy, anonymity, and confidentiality.</li>
              <li><strong>Informed Consent:</strong> Written voluntary agreement after explaining purpose, procedures, risks/benefits, alternatives, and Institutional Review Board (IRB) approval.</li>
            </ul>
          </div>
        </div>
      `},{id:`grp-stats-tests-significance`,title:`Tests of Significance (t-test, Chi-Square Test & ANOVA) + Scales of Measurement`,repeatCount:1,years:[`2022`],subItems:[{concept:`Parametric vs Non-parametric tests; Nominal, Ordinal, Interval & Ratio scales`,years:`2022`}],questions:[{paperBadge:`MPMSU 2022 — Short Note [5 Marks]`,weight:`Short Note | Target: 2 Handwritten Pages`,questionText:`Write a short note on Scales of Measurement and differentiate Parametric vs Non-parametric tests (t-test vs Chi-square).`}],answerHtml:`
        <div class="concept-card">
          <div class="concept-title">1. Four Scales of Measurement (NOIR)</div>
          <div class="concept-body">
            <ul>
              <li><strong>Nominal:</strong> Categories without order (Gender, Blood group).</li>
              <li><strong>Ordinal:</strong> Ranked categories without equal intervals (Pain scale, Socioeconomic class).</li>
              <li><strong>Interval:</strong> Equal intervals, arbitrary zero (°C temperature, IQ).</li>
              <li><strong>Ratio:</strong> Equal intervals with absolute true zero (Height, Weight, Age).</li>
            </ul>
          </div>
        </div>
        <div class="concept-card">
          <div class="concept-title">2. Parametric vs Non-Parametric Tests</div>
          <div class="concept-body">
            <p><strong>Parametric (t-test, ANOVA, Pearson r):</strong> Require normally distributed interval/ratio data. <strong>Non-Parametric (Chi-square χ², Mann-Whitney U, Spearman rho):</strong> Distribution-free, ideal for nominal/ordinal or skewed data.</p>
          </div>
        </div>
      `}]};Object.keys(t).forEach(n=>{if(e[n]&&Array.isArray(e[n].topics)){let r=new Set(e[n].topics.map(e=>e.id));t[n].forEach(t=>{r.has(t.id)||e[n].topics.push(t)})}});var n=`msn`,r=`priority`,i=document.getElementById(`pyq-subject-selector`),a=document.getElementById(`pyq-mode-priority`),o=document.getElementById(`pyq-mode-papers`),s=document.getElementById(`pyq-priority-section`),c=document.getElementById(`pyq-papers-section`),l=document.getElementById(`pyq-topics-list`),u=document.getElementById(`pyq-papers-grid`),d=document.getElementById(`pyq-pdf-modal`),f=document.getElementById(`pyq-pdf-modal-title`),p=document.getElementById(`pyq-pdf-modal-download`),m=document.getElementById(`pyq-pdf-modal-close`),h=document.getElementById(`pyq-pdf-canvas`),g=document.getElementById(`pyq-pdf-loading`),_=document.getElementById(`pdf-prev-page`),v=document.getElementById(`pdf-next-page`),y=document.getElementById(`pdf-page-num`),b=document.getElementById(`pdf-zoom-in`),x=document.getElementById(`pdf-zoom-out`),S=null,C=1,w=1,T=1,E=!1,D=null;function O(){let t=new URLSearchParams(window.location.search),i=t.get(`subject`);i&&e[i]&&(n=i),t.get(`mode`)===`papers`&&(r=`papers`),window.pdfjsLib&&(window.pdfjsLib.GlobalWorkerOptions.workerSrc=`/vendor/pdfjs/pdf.worker.min.js`),k(),A(),M(),I()}function k(){i&&(i.innerHTML=``,Object.values(e).forEach(e=>{let t=document.createElement(`button`);t.type=`button`,t.className=`pyq-sub-chip ${e.id===n?`active`:``}`,t.setAttribute(`data-sub-id`,e.id),t.innerHTML=`<span>${e.shortName}</span>`,t.addEventListener(`click`,()=>{n!==e.id&&(n=e.id,i.querySelectorAll(`.pyq-sub-chip`).forEach(e=>e.classList.remove(`active`)),t.classList.add(`active`),I())}),i.appendChild(t)}))}function A(){a&&o&&(a.addEventListener(`click`,()=>{r!==`priority`&&(r=`priority`,a.classList.add(`active`),o.classList.remove(`active`),I())}),o.addEventListener(`click`,()=>{r!==`papers`&&(r=`papers`,o.classList.add(`active`),a.classList.remove(`active`),I())}))}function j(e,t,n){let r=t||`Question Paper PDF`,i=n||`question_paper.pdf`;if(window.AndroidBridge&&typeof window.AndroidBridge.downloadPdf==`function`)try{window.AndroidBridge.downloadPdf(e,r,i);return}catch(e){console.warn(`AndroidBridge download error:`,e)}if(window.AndroidVideoBridge&&typeof window.AndroidVideoBridge.downloadPdf==`function`)try{window.AndroidVideoBridge.downloadPdf(e,r,i);return}catch(e){console.warn(`AndroidVideoBridge download error:`,e)}let a=document.createElement(`a`);a.href=e,a.download=i,a.target=`_blank`,document.body.appendChild(a),a.click(),document.body.removeChild(a)}window.triggerFileDownload=j;function M(){if(!d)return;let e=()=>{if(d.classList.remove(`open`),S=null,C=1,T=1,h){let e=h.getContext(`2d`);e&&e.clearRect(0,0,h.width,h.height)}};m&&m.addEventListener(`click`,e),p&&p.addEventListener(`click`,e=>{e.preventDefault(),j(p.getAttribute(`data-url`)||p.href,f?f.textContent:`Question Paper`,p.getAttribute(`download`)||`question_paper.pdf`)}),_&&_.addEventListener(`click`,()=>{C>1&&(C--,N(C))}),v&&v.addEventListener(`click`,()=>{C<w&&(C++,N(C))}),b&&b.addEventListener(`click`,()=>{T<2.5&&(T+=.25,N(C))}),x&&x.addEventListener(`click`,()=>{T>.6&&(T-=.25,N(C))}),d.addEventListener(`click`,t=>{t.target===d&&e()}),window.addEventListener(`keydown`,t=>{t.key===`Escape`&&d.classList.contains(`open`)&&e()})}function N(e){E?D=e:P(e)}async function P(e){if(!(!S||!h)){E=!0;try{let t=await S.getPage(e),n=document.getElementById(`pyq-pdf-body`),r=n?n.clientWidth-32:window.innerWidth-48,i=Math.min(Math.max(r,320),860)/t.getViewport({scale:1}).width*T,a=t.getViewport({scale:i}),o=h.getContext(`2d`);h.height=a.height,h.width=a.width;let s={canvasContext:o,viewport:a};await t.render(s).promise}catch(e){console.error(`Error rendering PDF page:`,e)}finally{if(E=!1,y&&(y.textContent=`${e} / ${w}`),g&&(g.style.display=`none`),D!==null){let e=D;D=null,P(e)}}}}async function F(e,t){if(!d||!h){window.open(t,`_blank`);return}if(f&&(f.textContent=e),p){let n=e.replace(/[^a-zA-Z0-9_-]/g,`_`)+`.pdf`;p.href=t,p.setAttribute(`data-url`,t),p.setAttribute(`download`,n)}if(d.classList.add(`open`),g&&(g.style.display=`flex`),y&&(y.textContent=`...`),!window.pdfjsLib){console.warn(`PDF.js not loaded, opening URL directly`),g&&(g.style.display=`none`),window.open(t,`_blank`);return}try{S=await window.pdfjsLib.getDocument(t).promise,w=S.numPages||1,C=1,T=1,P(C)}catch(e){console.error(`Failed to load PDF document via PDF.js:`,e),g&&(g.innerHTML=`<span style="color:#F87171;">Failed to load PDF preview. <a href="${t}" target="_blank" style="color:var(--pyq-accent);text-decoration:underline;">Click to download</a></span>`)}}window.openPdfViewer=F;function I(){let t=e[n];t&&(r===`priority`?(s.style.display=`block`,c.style.display=`none`,L([...t.topics||[]].sort((e,t)=>(t.repeatCount||1)-(e.repeatCount||1)))):(s.style.display=`none`,c.style.display=`block`,R(t.papers)))}function L(e){if(l){if(l.innerHTML=``,!e||e.length===0){l.innerHTML=`<div style="grid-column:1/-1;text-align:center;padding:30px;color:var(--pyq-text-muted);font-size:13.5px;">No questions match this filter for the selected subject.</div>`;return}e.forEach(e=>{let t=document.createElement(`div`);t.className=`pyq-topic-card`,t.id=`card-${e.id}`,(e.years||[]).map(e=>`<span class="pyq-year-pill">${e}</span>`).join(``);let n=(e.subItems||[]).map(e=>`
      <li class="pyq-concept-item">
        <span>${e.concept}</span>
        <span class="pyq-concept-years">${e.years}</span>
      </li>
    `).join(``),r=(e.questions||[]).map(e=>`
      <div class="pyq-q-row">
        <div class="pyq-q-badge">${e.paperBadge} • ${e.weight}</div>
        <div class="pyq-q-text">${e.questionText}</div>
      </div>
    `).join(``),i=e.repeatCount>=4?4:e.repeatCount||1,a=i===1?`1x Asked in Exam`:`${i}x Repeated in NTRUHS`,o=(e.years||[]).join(` • `);t.innerHTML=`
      <div class="pyq-topic-header">
        <div class="pyq-topic-meta-row">
          <span class="pyq-freq-badge b-${i}-repeat">
            ${a}
          </span>
          ${o?`<span class="pyq-year-summary">${o}</span>`:``}
        </div>

        <h3 class="pyq-topic-title">${e.title}</h3>

        ${n?`<ul class="pyq-concepts-list">${n}</ul>`:``}

        ${r?`
          <div class="pyq-questions-section">
            ${r}
          </div>
        `:``}

        <div class="pyq-answer-action-bar">
          <button type="button" class="btn-toggle-answer">
            <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2"><path d="M2 3h6a4 4 0 0 1 4 4v14a3 3 0 0 0-3-3H2z"/><path d="M22 3h-6a4 4 0 0 0-4 4v14a3 3 0 0 1 3-3h7z"/></svg>
            <span class="btn-toggle-txt">Show Answer</span>
          </button>
        </div>
      </div>

      <div class="pyq-model-answer-wrapper">
        <div class="concept-body">
          ${e.answerHtml}
        </div>
      </div>
    `;let s=t.querySelector(`.btn-toggle-answer`);s&&s.addEventListener(`click`,e=>{e.stopPropagation(),t.classList.toggle(`expanded`);let n=t.querySelector(`.btn-toggle-txt`);n&&(n.textContent=t.classList.contains(`expanded`)?`Hide Answer`:`Show Answer`)}),l.appendChild(t)})}}function R(e){u&&(u.innerHTML=``,e.forEach(e=>{let t=document.createElement(`div`);t.className=`pyq-paper-card`,t.innerHTML=`
      <div>
        <h4 class="pyq-paper-title">${e.year} — ${e.badge||`Annual Exam`}</h4>
      </div>
      <div class="pyq-paper-actions">
        <button type="button" class="pyq-btn-view btn-read-paper">
          <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/></svg>
          <span>View</span>
        </button>
        <button type="button" class="pyq-btn-download btn-download-paper">
          <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/></svg>
          <span>Download</span>
        </button>
      </div>
    `;let n=t.querySelector(`.btn-read-paper`);n&&n.addEventListener(`click`,t=>{t.preventDefault(),F(`${e.year} ${e.badge||`Paper`}`,e.file)});let r=t.querySelector(`.btn-download-paper`);r&&r.addEventListener(`click`,t=>{t.preventDefault();let n=`${e.year}_${e.badge||`question_paper`}.pdf`.replace(/[^a-zA-Z0-9_.-]/g,`_`);j(e.file,`${e.year} Question Paper`,n)}),u.appendChild(t)}))}document.readyState===`loading`?document.addEventListener(`DOMContentLoaded`,O):O();