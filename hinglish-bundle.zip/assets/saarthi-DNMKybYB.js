import"./apk-shell-DT9v0LPh.js";var e=`nnl_saarthi_chat_history_v4`,t=document.getElementById(`saarthi-chat-log`),n=document.getElementById(`saarthi-chat-form`),r=document.getElementById(`saarthi-chat-input`),i=document.getElementById(`saarthi-back-btn`),a=document.getElementById(`saarthi-clear-chat-btn`),o=document.getElementById(`saarthi-topic-chips`),s={role:`bot`,text:`
    <p>Namaste! I am <strong>NNL Saarthi</strong>, your dedicated 24/7 AI Clinical Mentor &amp; NORCET Companion.</p>
    <p>Ask me anything regarding:</p>
    <ul>
      <li><strong>Clinical Drug Calculations:</strong> IV drop factor, pediatric dosages, mcg/kg/min infusions.</li>
      <li><strong>NORCET &amp; Nursing Officer High-Yield:</strong> Priority rationales, Gold Standard nursing interventions.</li>
      <li><strong>Diagnostics &amp; ECG:</strong> Dysrhythmias, electrolyte imbalances, arterial blood gas (ABG) interpretations.</li>
      <li><strong>Specialty Concepts:</strong> OBG labor stages, pediatric milestones, emergency resuscitation.</li>
    </ul>
    <p>Pick a suggested question above or type your clinical question below!</p>
  `,timestamp:Date.now()};function c(e){if(!e)return``;let t=e;return t=t.replace(/</g,`&lt;`).replace(/>/g,`&gt;`),t=t.replace(/^### (.*$)/gim,`<h4 class="saarthi-md-h4">$1</h4>`),t=t.replace(/^## (.*$)/gim,`<h3 class="saarthi-md-h3">$1</h3>`),t=t.replace(/^# (.*$)/gim,`<h2 class="saarthi-md-h2">$1</h2>`),t=t.replace(/\*\*(.*?)\*\*/g,`<strong>$1</strong>`),t=t.replace(/\*(.*?)\*/g,`<em>$1</em>`),t=t.replace(/`([^`]+)`/g,`<code class="saarthi-inline-code">$1</code>`),t=t.replace(/^\s*[-*]\s+(.*)$/gim,`<li>$1</li>`),t=t.replace(/(<li>[\s\S]*?<\/li>)/g,`<ul class="saarthi-md-list">$1</ul>`),t=t.replace(/<\/ul>\s*<ul class="saarthi-md-list">/g,``),t=t.replace(/^\s*(\d+)\.\s+(.*)$/gim,`<li>$2</li>`),t=t.replace(/\n\n+/g,`</p><p>`),t=t.replace(/\n/g,`<br/>`),`<p>${t}</p>`}function l(){return localStorage.getItem(`token`)||localStorage.getItem(`nnl_access_token`)||sessionStorage.getItem(`nnl_access_token`)||``}function u(){try{let t=localStorage.getItem(e);if(!t)return[s];let n=JSON.parse(t);return Array.isArray(n)&&n.length>0?n:[s]}catch{return[s]}}function d(t){try{localStorage.setItem(e,JSON.stringify(t.slice(-50)))}catch{}}function f(e){return new Date(e).toLocaleTimeString([],{hour:`2-digit`,minute:`2-digit`})}function p(e){if(!t)return;let n=e.role===`bot`,r=document.createElement(`div`);r.className=`saarthi-message-row ${n?`bot-row`:`user-row`}`;let i=n?`<div class="saarthi-msg-avatar bot-avatar">
         <svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.3">
           <path d="M12 2a8 8 0 0 0-8 8c0 3.37 2.1 6.25 5.08 7.37L9 22l4-2 4 2-.08-4.63A8 8 0 0 0 12 2z"/>
         </svg>
       </div>`:`<div class="saarthi-msg-avatar user-avatar">
         <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.3">
           <path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/>
         </svg>
       </div>`,a=e.subject?`<span class="saarthi-msg-tag">${e.subject}</span>`:``,o=typeof e.remainingQuestions==`number`?`<span class="saarthi-remaining-badge">${e.remainingQuestions} queries left</span>`:``;r.innerHTML=`
    ${i}
    <div class="saarthi-msg-bubble">
      <div class="saarthi-msg-sender">
        <span>${n?`NNL Saarthi`:`You`}</span>
        ${a}
        ${o}
      </div>
      <div class="saarthi-msg-content">${e.text}</div>
      <div class="saarthi-msg-time">${f(e.timestamp||Date.now())}</div>
    </div>
  `,t.appendChild(r),t.scrollTop=t.scrollHeight}function m(){t&&(t.innerHTML=``,u().forEach(p))}function h(e){let t=(e||``).toLowerCase().trim();return/^(hi|hello|hey|namaste|good\s*(morning|afternoon|evening)|start|help|who are you|what can you do|introduce yourself)$/i.test(t)?`
      <p>Namaste! I am your <strong>NNL Saarthi AI Clinical Mentor</strong>.</p>
      <p>I am your 24/7 companion for cracking <strong>AIIMS NORCET, ESIC, RRB, and State Nursing Officer</strong> exams. I can instantly assist you with:</p>
      <ul>
        <li><strong>Drug Dosage &amp; IV Calculations:</strong> Drop factor, Dopamine/Noradrenaline infusions, pediatric rules.</li>
        <li><strong>Cardiology &amp; ECG:</strong> Arrhythmias, MI STEMI/NSTEMI, electrolyte ECG signatures.</li>
        <li><strong>Critical Care &amp; Resuscitation:</strong> CPR (BLS/ACLS), Triage color tags, Shock types, Parkland burn formula.</li>
        <li><strong>OBG &amp; Pediatrics:</strong> Stages of labor, Bishop score, APGAR, pediatric milestones &amp; NIS immunization.</li>
        <li><strong>Pharmacology Antidotes:</strong> Heparin, Warfarin, Digoxin, Paracetamol, Opioids, Magnesium.</li>
      </ul>
      <p>Type any clinical term, calculation problem, or rationale question to get started!</p>
    `:/^(ok|okay|k|thanks|thank you|got it|cool|nice|understood|super|clear|fine|great|awesome)$/i.test(t)?`
      <p>You're welcome! Keep the momentum going — consistency is what transforms nursing students into AIIMS Nursing Officers.</p>
      <p>Would you like to test your recall on <strong>Drug Calculations</strong>, <strong>ECG Rhythms</strong>, or <strong>OBG High-Yield Points</strong>?</p>
    `:t.includes(`drop`)||t.includes(`formula`)||t.includes(`dosage`)||t.includes(`infusion`)||t.includes(`gtt`)||t.includes(`dopamine`)||t.includes(`dobutamine`)||t.includes(`flow rate`)?`
      <h4>💉 Clinical Drug Calculation: IV Drop Factor &amp; Inotrope Infusion</h4>
      <p><strong>1. Standard IV Drop Rate Formula:</strong></p>
      <div class="saarthi-callout">
        <strong>Flow Rate (gtt/min) = [Total Volume (mL) × Drop Factor (gtt/mL)] ÷ Time in Minutes</strong>
      </div>
      <p><strong>Key Clinical Drop Factors:</strong></p>
      <ul>
        <li><strong>Macrodrip Tubing:</strong> 15 or 20 gtt/mL (standard adult IV sets in hospitals).</li>
        <li><strong>Microdrip Tubing:</strong> Exactly <strong>60 gtt/mL</strong> (Formula shortcut: When drop factor is 60, Flow Rate in gtt/min = Rate in mL/hr).</li>
      </ul>
      <p><strong>2. Dopamine / Noradrenaline mcg/kg/min Formula:</strong></p>
      <div class="saarthi-callout">
        <strong>Rate (mL/hr) = [Desired Dose (mcg/kg/min) × Weight (kg) × 60 min] ÷ Drug Concentration (mcg/mL)</strong>
      </div>
      <p><em>Exam Golden Rule:</em> If time in question is stated in hours (e.g., "over 8 hours"), ALWAYS multiply hours by 60 before dividing: <code>8 × 60 = 480 minutes</code>.</p>
    `:t.includes(`cpr`)||t.includes(`bls`)||t.includes(`acls`)||t.includes(`resuscitation`)||t.includes(`cardiac arrest`)||t.includes(`compression`)||t.includes(`defibrillat`)?`
      <h4>❤️ CPR &amp; ACLS Gold-Standard Protocols (AHA / NORCET Core)</h4>
      <p><strong>1. Adult BLS Sequence (C-A-B):</strong></p>
      <ul>
        <li><strong>Compression Rate:</strong> 100 – 120 compressions per minute.</li>
        <li><strong>Compression Depth:</strong> At least <strong>2 inches (5 cm)</strong>, not exceeding 2.4 inches (6 cm). Allow full chest recoil.</li>
        <li><strong>Compression-to-Ventilation Ratio:</strong> <strong>30:2</strong> for 1-rescuer and 2-rescuer adult CPR.</li>
        <li><strong>Pulse Check:</strong> Carotid pulse for no more than 10 seconds. If absent or uncertain within 10s, initiate compressions.</li>
      </ul>
      <p><strong>2. ACLS Rhythms Classification:</strong></p>
      <ul>
        <li><strong>Shockable Rhythms:</strong> Ventricular Fibrillation (VF) and Pulseless Ventricular Tachycardia (pVT) -> Immediate defibrillation (120-200 J biphasic) + Epinephrine 1 mg every 3-5 min + Amiodarone 300 mg (1st) / 150 mg (2nd).</li>
        <li><strong>Non-Shockable Rhythms:</strong> Asystole &amp; PEA (Pulseless Electrical Activity) -> High-quality CPR + Epinephrine 1 mg IV q3-5 min. <em>Do NOT shock Asystole/PEA!</em></li>
      </ul>
    `:t.includes(`burn`)||t.includes(`parkland`)||t.includes(`rule of nine`)||t.includes(`tbsa`)?`
      <h4>🔥 Burn Injury &amp; Parkland Formula Fluid Resuscitation</h4>
      <p><strong>The Parkland Formula for 24-Hour IV Fluid:</strong></p>
      <div class="saarthi-callout">
        <strong>Total 24-hr Fluid (Lactated Ringer's) = 4 mL × Body Weight (kg) × % Total Body Surface Area Burned (% TBSA)</strong>
      </div>
      <p><strong>Administration Schedule:</strong></p>
      <ul>
        <li><strong>First 8 Hours:</strong> Give <strong>50% (half)</strong> of total calculated fluid, timed from the <em>exact moment of burn injury</em> (NOT hospital arrival time).</li>
        <li><strong>Next 16 Hours:</strong> Give remaining <strong>50% (half)</strong> split equally over 16 hours.</li>
      </ul>
      <p><strong>Rule of Nines Breakdown:</strong> Head &amp; Neck (9%), Each Arm (9%), Anterior Torso (18%), Posterior Torso (18%), Each Leg (18%), Perineum (1%).</p>
      <p><em>Monitoring Landmark:</em> Adequate fluid resuscitation is confirmed by urinary output of <strong>0.5 – 1.0 mL/kg/hr</strong> (approx 30–50 mL/hr in adults).</p>
    `:t.includes(`antidote`)||t.includes(`toxicity`)||t.includes(`poison`)||t.includes(`heparin`)||t.includes(`warfarin`)||t.includes(`naloxone`)||t.includes(`paracetamol`)?`
      <h4>💊 Essential Pharmacology Antidotes (NORCET Frequent Ask)</h4>
      <div class="saarthi-callout">
        <ul>
          <li><strong>Heparin:</strong> <em>Protamine Sulfate</em> (1 mg neutralizes ~100 units of heparin).</li>
          <li><strong>Warfarin (Coumadin):</strong> <em>Vitamin K (Phytonadione)</em>; Fresh Frozen Plasma (FFP) for acute bleeding.</li>
          <li><strong>Acetaminophen (Paracetamol):</strong> <em>N-acetylcysteine (NAC / Mucomyst)</em>.</li>
          <li><strong>Opioids (Morphine, Fentanyl):</strong> <em>Naloxone (Narcan)</em>.</li>
          <li><strong>Magnesium Sulfate:</strong> <em>Calcium Gluconate (10%)</em> IV slow push.</li>
          <li><strong>Digoxin:</strong> <em>Digoxin Immune Fab (DigiFab / Digibind)</em>.</li>
          <li><strong>Benzodiazepines (Diazepam, Midazolam):</strong> <em>Flumazenil</em>.</li>
          <li><strong>Beta-Blockers:</strong> <em>Glucagon</em>.</li>
          <li><strong>Iron Toxicity:</strong> <em>Deferoxamine</em>.</li>
        </ul>
      </div>
      <p><em>Exam Tip:</em> For Heparin monitor <strong>aPTT</strong> (target 1.5–2.5× control). For Warfarin monitor <strong>PT / INR</strong> (target INR 2.0–3.0).</p>
    `:t.includes(`gcs`)||t.includes(`glasgow`)||t.includes(`coma`)?`
      <h4>🧠 Glasgow Coma Scale (GCS) Clinical Breakdown</h4>
      <p>Total score ranges from <strong>3 to 15</strong> (There is NO zero score in GCS).</p>
      <ul>
        <li><strong>Eye Opening (E - Max 4):</strong>
          <br/>4 = Spontaneous, 3 = To verbal request, 2 = To painful stimulus, 1 = No response.
        </li>
        <li><strong>Verbal Response (V - Max 5):</strong>
          <br/>5 = Oriented, 4 = Confused conversation, 3 = Inappropriate words, 2 = Incomprehensible sounds, 1 = No response.
        </li>
        <li><strong>Motor Response (M - Max 6):</strong>
          <br/>6 = Obeys commands, 5 = Localizes to pain, 4 = Normal flexion (withdrawal), 3 = Abnormal flexion (Decorticate rigidity), 2 = Extension (Decerebrate rigidity), 1 = Flaccid (no response).
        </li>
      </ul>
      <div class="saarthi-callout">
        <strong>Critical NORCET Rule:</strong> <em>"GCS ≤ 8, Intubate!"</em> A score of 8 or below defines severe traumatic brain injury requiring immediate airway protection.
      </div>
    `:t.includes(`hyperkalemia`)||t.includes(`hypokalemia`)||t.includes(`potassium`)||t.includes(`kalemia`)||t.includes(`ecg`)||t.includes(`arrhythmia`)?`
      <h4>📈 Hyperkalemia (Serum K+ &gt; 5.0 mEq/L) &amp; ECG Sequence</h4>
      <p><strong>Progressive ECG Changes:</strong></p>
      <ol>
        <li><strong>Tall, peaked/tented T waves</strong> (earliest and most classic NORCET sign).</li>
        <li>Prolonged PR interval and flattening/loss of P waves.</li>
        <li>Widened QRS complex.</li>
        <li>Sine wave pattern leading to Ventricular Fibrillation or Asystole.</li>
      </ol>
      <p><strong>Priority Emergency Management:</strong></p>
      <ul>
        <li><strong>Step 1 (Myocardial Membrane Stabilization):</strong> <em>IV Calcium Gluconate (10%)</em> — does NOT lower potassium; protects heart against arrhythmias.</li>
        <li><strong>Step 2 (Shift K+ Intracellularly):</strong> Regular Insulin (10 units) with 50% Dextrose (D50W) + Nebulized Albuterol.</li>
        <li><strong>Step 3 (Elimination from Body):</strong> Sodium Polystyrene Sulfonate (Kayexalate), Loop diuretics (Furosemide), or Emergency Hemodialysis.</li>
      </ul>
      <p><em>Contrast Note:</em> In <strong>Hypokalemia (&lt; 3.5 mEq/L)</strong>, look for <strong>Prominent U waves</strong>, ST depression, and flat/inverted T waves.</p>
    `:t.includes(`abg`)||t.includes(`acidosis`)||t.includes(`alkalosis`)||t.includes(`rome`)||t.includes(`blood gas`)?`
      <h4>🧪 Arterial Blood Gas (ABG) Mastery — ROME Method</h4>
      <p><strong>Standard Normal Values:</strong></p>
      <ul>
        <li><strong>pH:</strong> 7.35 – 7.45 (&lt;7.35 = Acidosis | &gt;7.45 = Alkalosis)</li>
        <li><strong>PaCO2:</strong> 35 – 45 mmHg (Respiratory component)</li>
        <li><strong>HCO3:</strong> 22 – 26 mEq/L (Metabolic renal component)</li>
      </ul>
      <div class="saarthi-callout">
        <strong>The R.O.M.E. Rule:</strong><br/>
        <strong>R</strong>espiratory <strong>O</strong>pposite: If pH is abnormal, PaCO2 moves in the OPPOSITE direction.<br/>
        <strong>M</strong>etabolic <strong>E</strong>qual: If pH is abnormal, HCO3 moves in the SAME direction.
      </div>
      <p><em>Example:</em> pH 7.28 (Low), PaCO2 54 (High) = <strong>Respiratory Acidosis</strong> (e.g., COPD, respiratory depression).<br/>
      <em>Example:</em> pH 7.26 (Low), HCO3 16 (Low) = <strong>Metabolic Acidosis</strong> (e.g., DKA, renal failure).</p>
    `:t.includes(`labor`)||t.includes(`bishop`)||t.includes(`obg`)||t.includes(`cervix`)||t.includes(`apgar`)||t.includes(`placenta`)||t.includes(`pph`)?`
      <h4>👶 Stages of Labor, Bishop Score &amp; High-Yield OBG</h4>
      <p><strong>The 4 Clinical Stages of Labor:</strong></p>
      <ul>
        <li><strong>First Stage (0 to 10 cm Dilatation):</strong>
          <br/>• <em>Latent Phase:</em> 0–3 cm (mild contractions).
          <br/>• <em>Active Phase:</em> 4–7 cm (rapid cervical change, epidural window).
          <br/>• <em>Transition Phase:</em> 8–10 cm (most intense, urge to push).
        </li>
        <li><strong>Second Stage:</strong> Full cervical dilatation (10 cm) to fetal expulsion.</li>
        <li><strong>Third Stage:</strong> Fetal birth to complete placenta delivery (normal &lt;30 mins).</li>
        <li><strong>Fourth Stage (Recovery):</strong> First 1–2 hours postpartum. Priority: monitor for Postpartum Hemorrhage (PPH) and fundal firmness.</li>
      </ul>
      <p><strong>Bishop Score:</strong> Assesses cervical readiness for induction (Parameters: Dilatation, Effacement, Station, Consistency, Position). Score &ge; 8 indicates favorable induction success.</p>
      <div class="saarthi-callout">
        <strong>Bleeding in Late Pregnancy:</strong>
        <br/>• <strong>Placenta Previa:</strong> <em>Painless</em>, bright-red vaginal bleeding. Vaginal exam is strictly contraindicated!
        <br/>• <strong>Abruptio Placentae:</strong> <em>Painful</em>, dark-red vaginal bleeding with board-like, rigid abdomen.
      </div>
    `:t.includes(`pediatric`)||t.includes(`milestone`)||t.includes(`fontanelle`)||t.includes(`immuniz`)||t.includes(`vaccin`)||t.includes(`bcg`)||t.includes(`weight`)?`
      <h4>🍼 Pediatrics Growth, Milestones &amp; National Immunization Schedule</h4>
      <p><strong>Key Growth &amp; Development Milestones:</strong></p>
      <ul>
        <li><strong>Birth Weight:</strong> Normal 2.5 – 3.5 kg. <strong>Doubles by 5–6 months</strong>, <strong>triples by 1 year</strong>, quadruples by 2 years.</li>
        <li><strong>Fontanelles:</strong>
          <br/>• <em>Posterior fontanelle</em> closes at <strong>6 – 8 weeks (2 months)</strong> (triangular shape).
          <br/>• <em>Anterior fontanelle</em> closes at <strong>12 – 18 months</strong> (diamond shape).
        </li>
        <li><strong>Motor Milestones:</strong> Neck holding (3 mos), sitting without support (6–8 mos), standing with support (9 mos), walking independently (12–15 mos).</li>
      </ul>
      <p><strong>NIS Vaccination at Birth:</strong></p>
      <ul>
        <li><strong>BCG:</strong> 0.05 mL ID (left upper arm) at birth (or 0.1 mL after 1 month).</li>
        <li><strong>OPV (Zero dose):</strong> 2 drops oral.</li>
        <li><strong>Hepatitis B (Birth dose):</strong> 0.5 mL IM (anterolateral thigh) within 24 hours.</li>
      </ul>
    `:t.includes(`shock`)||t.includes(`triage`)||t.includes(`disaster`)||t.includes(`anaphylaxis`)?`
      <h4>🚨 Disaster Triage &amp; Clinical Shock Management</h4>
      <p><strong>START Disaster Triage Color Codes:</strong></p>
      <ul>
        <li><strong>🔴 Red (Immediate):</strong> Critical life-threatening injuries with high chance of survival if treated immediately (e.g. tension pneumothorax, open chest wound, uncontrolled severe hemorrhage, RR &gt; 30).</li>
        <li><strong>🟡 Yellow (Delayed):</strong> Serious injuries requiring medical care within 1–2 hours, but not in immediate life threat (e.g. open fractures, large burns without airway compromise).</li>
        <li><strong>🟢 Green (Minor / "Walking Wounded"):</strong> Minor lacerations, sprains, superficial wounds.</li>
        <li><strong>⚫ Black (Expectant / Deceased):</strong> Fatal injuries or pulseless/apneic patients (e.g. massive head trauma with brain matter exposed, cardiac arrest in disaster settings).</li>
      </ul>
      <div class="saarthi-callout">
        <strong>Anaphylactic Shock Priority:</strong> First-line intervention is <strong>IM Epinephrine (1:1000) 0.3 – 0.5 mg</strong> in the anterolateral thigh, followed by high-flow O2 and IV fluids.
      </div>
    `:t.includes(`diabetes`)||t.includes(`insulin`)||t.includes(`dka`)||t.includes(`hypoglycemia`)?`
      <h4>🩸 Diabetes Mellitus, DKA &amp; Insulin Management</h4>
      <p><strong>Insulin Types &amp; Onset/Peak Characteristics:</strong></p>
      <ul>
        <li><strong>Rapid-Acting (Lispro/Aspart):</strong> Onset 15 min, <strong>Peak 1 hr</strong>, Duration 3-4 hrs. Give within 15 mins of a meal.</li>
        <li><strong>Short-Acting (Regular):</strong> Onset 30-60 min, <strong>Peak 2-4 hrs</strong>. <em>Only insulin that can be given IV!</em></li>
        <li><strong>Intermediate (NPH):</strong> Onset 1-2 hrs, <strong>Peak 4-12 hrs</strong> (Cloudy suspension).</li>
        <li><strong>Long-Acting (Glargine/Lantus):</strong> Onset 1-2 hrs, <strong>No Peak</strong>. Never mix with any other insulin in the same syringe!</li>
      </ul>
      <p><strong>Diabetic Ketoacidosis (DKA) Priorities:</strong></p>
      <ol>
        <li>Fluid resuscitation (0.9% Normal Saline 1-2 L in first hour).</li>
        <li>Continuous IV Regular Insulin infusion (0.1 units/kg/hr).</li>
        <li>Potassium monitoring: Never start insulin if K+ &lt; 3.3 mEq/L (insulin drives K+ into cells).</li>
      </ol>
    `:`
    <h4>🩺 NNL Saarthi Clinical Guidance</h4>
    <p>Regarding your query on <strong>"${e}"</strong>:</p>
    <ul>
      <li><strong>Core Clinical Concept:</strong> In NORCET clinical scenario questions, priority is always given to assessing physiological stability before initiating independent nursing interventions.</li>
      <li><strong>Priority Nursing Action:</strong> Always follow the <strong>Airway -> Breathing -> Circulation</strong> priority hierarchy unless managing an unwitnessed sudden cardiac arrest (CAB sequence).</li>
      <li><strong>Client Safety &amp; Legal:</strong> Never delegate assessment, patient teaching, or IV medication push to unlicensed assistive personnel (UAP).</li>
    </ul>
    <div class="saarthi-callout">
      <strong>Exam Tip:</strong> If an option asks you to "notify the healthcare provider" without performing an initial focused nursing assessment first, it is usually incorrect unless an acute emergency threshold is reached.
    </div>
    <p>Would you like specific practice questions, dosage calculations, or clinical mnemonics on this topic?</p>
  `}async function g(){let e=l(),t={Accept:`application/json`};e&&(t.Authorization=`Bearer ${e}`);try{let e=await fetch(`/api/api/ai/suggested_questions/`,{headers:t});if(!e.ok)return;let n=await e.json(),r=n?.data||n?.results||(Array.isArray(n)?n:null);if(!r||!Array.isArray(r)||r.length===0)return;o&&(o.innerHTML=r.map(e=>{let t=e.question||e.text||e.title||``;return t?`
          <button type="button" class="saarthi-chip" data-prompt="${t.replace(/"/g,`&quot;`)}">
            💡 ${t}
          </button>
        `:``}).join(``))}catch(e){console.warn(`[Saarthi] Suggested questions fetch note:`,e)}}async function _(e){if(!e||!e.trim())return;let n=e.trim(),i=l(),a={role:`user`,text:n.replace(/</g,`&lt;`).replace(/>/g,`&gt;`),timestamp:Date.now()},o=u();o.push(a),d(o),p(a),r&&(r.value=``);let s=document.createElement(`div`);s.className=`saarthi-message-row bot-row saarthi-typing-row`,s.innerHTML=`
    <div class="saarthi-msg-avatar bot-avatar">
      <svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.3">
        <path d="M12 2a8 8 0 0 0-8 8c0 3.37 2.1 6.25 5.08 7.37L9 22l4-2 4 2-.08-4.63A8 8 0 0 0 12 2z"/>
      </svg>
    </div>
    <div class="saarthi-msg-bubble typing-bubble">
      <span class="typing-dot"></span>
      <span class="typing-dot"></span>
      <span class="typing-dot"></span>
    </div>
  `,t.appendChild(s),t.scrollTop=t.scrollHeight;let f=``,m=`Clinical Mentor`;try{if(i){let e=await fetch(`/api/api/ai/ask_question/`,{method:`POST`,headers:{"Content-Type":`application/json`,Accept:`application/json`,Authorization:`Bearer ${i}`},body:JSON.stringify({question:n})});if(e.ok){let t=await e.json(),n=t.answer||t.text||t.data?.answer||``;n&&(f=c(n),m=t.subject||t.topic||`Clinical Mentor`)}}}catch(e){console.warn(`[Saarthi] Cloud AI fetch fallback triggered:`,e)}f||=h(n),s.remove();let g={role:`bot`,text:f,subject:m,timestamp:Date.now()};o.push(g),d(o),p(g)}n&&n.addEventListener(`submit`,e=>{e.preventDefault(),r&&_(r.value)}),i&&i.addEventListener(`click`,()=>{window.location.href=`/`}),a&&a.addEventListener(`click`,()=>{confirm(`Clear your conversation history with NNL Saarthi?`)&&(localStorage.removeItem(e),m())}),o&&o.addEventListener(`click`,e=>{let t=e.target.closest(`.saarthi-chip`);if(t){let e=t.getAttribute(`data-prompt`);e&&_(e)}});async function v(){let e=l();if(e)try{let t=await fetch(`/api/api/ai/question_history/`,{headers:{Accept:`application/json`,Authorization:`Bearer ${e}`}});if(!t.ok)return;let n=await t.json(),r=n?.data||n?.results||(Array.isArray(n)?n:null);if(r&&Array.isArray(r)&&r.length>0){let e=[s];r.forEach(t=>{t.question&&e.push({role:`user`,text:t.question.replace(/</g,`&lt;`).replace(/>/g,`&gt;`),timestamp:t.created_at?new Date(t.created_at).getTime():Date.now()-6e4}),t.answer&&e.push({role:`bot`,text:c(t.answer),subject:t.subject||`Clinical Mentor`,timestamp:t.answered_at?new Date(t.answered_at).getTime():Date.now()})}),e.length>1&&(d(e),m())}}catch(e){console.warn(`[Saarthi] Question history note:`,e)}}document.addEventListener(`DOMContentLoaded`,()=>{m(),g(),v()});