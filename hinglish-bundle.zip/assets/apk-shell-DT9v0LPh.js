(function(){let e=document.createElement(`link`).relList;if(e&&e.supports&&e.supports(`modulepreload`))return;for(let e of document.querySelectorAll(`link[rel="modulepreload"]`))n(e);new MutationObserver(e=>{for(let t of e)if(t.type===`childList`)for(let e of t.addedNodes)e.tagName===`LINK`&&e.rel===`modulepreload`&&n(e)}).observe(document,{childList:!0,subtree:!0});function t(e){let t={};return e.integrity&&(t.integrity=e.integrity),e.referrerPolicy&&(t.referrerPolicy=e.referrerPolicy),e.crossOrigin===`use-credentials`?t.credentials=`include`:e.crossOrigin===`anonymous`?t.credentials=`omit`:t.credentials=`same-origin`,t}function n(e){if(e.ep)return;e.ep=!0;let n=t(e);fetch(e.href,n)}})();var e=`/assets/botanical-heart-lungs-DOwpAYbV.png`,t=`nnl_companion_pet_id`,n=`nnl_companion_pet_enabled`;function r(){try{return localStorage.getItem(n)!==`false`}catch{return!0}}function i(e){try{localStorage.setItem(n,e?`true`:`false`)}catch{}let t=document.getElementById(`apk-companion-pet`);t&&t.style.setProperty(`display`,e?`inline-flex`:`none`,`important`)}function a(){return`Koda`}function o(e=`default`){return f(e)}function s(){return`koda`}function c(){try{localStorage.setItem(t,`koda`)}catch{}}var l=[`Focus mode locked: AIIMS New Delhi! 🎯`,`High-yield concepts only! ⚡`,`One concept at a time, Doctor! 🩺`,`Master your NCLEX & NORCET prep! 🚀`,`Consistent daily reps build champions! ⭐`,`Clinical rationales decoded! 🧠`,`Stay sharp, future AIIMS Nursing Officer! 🏆`],u=null;function d(e){let t=document.getElementById(`apk-companion-pet`);if(!t)return;let n=t.querySelector(`.mochi-speech-bubble, .koda-speech-bubble`);n||(n=document.createElement(`div`),n.className=`koda-speech-bubble`,t.appendChild(n)),n.textContent=e||l[Math.floor(Math.random()*l.length)],n.classList.add(`visible`),clearTimeout(u),u=setTimeout(()=>{n.classList.remove(`visible`)},2400)}function f(e=`default`){let t=``,n=``,r=``;return e===`happy`||e===`excited`||e===`cheer`?(t=`
      <path d="M 22 34 Q 28 26 34 34" stroke="#0F172A" stroke-width="3.2" stroke-linecap="round" fill="none"/>
      <path d="M 40 34 Q 46 26 52 34" stroke="#0F172A" stroke-width="3.2" stroke-linecap="round" fill="none"/>
    `,n=`
      <path d="M 33 42 Q 37 47 41 42" stroke="#0F172A" stroke-width="2.5" stroke-linecap="round" fill="#EA580C"/>
    `):e===`blink`?(t=`
      <line x1="22" y1="34" x2="34" y2="34" stroke="#0F172A" stroke-width="2.8" stroke-linecap="round"/>
      <line x1="40" y1="34" x2="52" y2="34" stroke="#0F172A" stroke-width="2.8" stroke-linecap="round"/>
    `,n=`
      <path d="M 33 41 Q 37 43 41 41" stroke="#0F172A" stroke-width="2.2" stroke-linecap="round" fill="none"/>
    `):e===`focus`||e===`study`?(t=`
      <!-- Focused Eyes -->
      <ellipse cx="28" cy="33" rx="4.5" ry="4.5" fill="#0F172A"/>
      <circle cx="29.5" cy="31.5" r="1.6" fill="#38BDF8"/>
      <ellipse cx="46" cy="33" rx="4.5" ry="4.5" fill="#0F172A"/>
      <circle cx="47.5" cy="31.5" r="1.6" fill="#38BDF8"/>
    `,r=`
      <!-- Cyber Study Glasses -->
      <rect x="20" y="27" width="16" height="12" rx="3.5" fill="rgba(6, 182, 212, 0.15)" stroke="#06B6D4" stroke-width="1.8"/>
      <rect x="38" y="27" width="16" height="12" rx="3.5" fill="rgba(6, 182, 212, 0.15)" stroke="#06B6D4" stroke-width="1.8"/>
      <line x1="36" y1="32" x2="38" y2="32" stroke="#06B6D4" stroke-width="1.8"/>
      <line x1="17" y1="31" x2="20" y2="31" stroke="#06B6D4" stroke-width="1.6"/>
      <line x1="54" y1="31" x2="57" y2="31" stroke="#06B6D4" stroke-width="1.6"/>
      <!-- Glass Glare Highlights -->
      <line x1="22" y1="29" x2="26" y2="29" stroke="#FFFFFF" stroke-width="1" stroke-linecap="round" opacity="0.8"/>
      <line x1="40" y1="29" x2="44" y2="29" stroke="#FFFFFF" stroke-width="1" stroke-linecap="round" opacity="0.8"/>
    `,n=`
      <line x1="34" y1="42" x2="40" y2="42" stroke="#0F172A" stroke-width="2.2" stroke-linecap="round"/>
    `):(t=`
      <!-- Left Eye -->
      <ellipse cx="28" cy="33" rx="4.8" ry="5.2" fill="#0F172A"/>
      <circle cx="29.8" cy="31.2" r="1.8" fill="#FFFFFF"/>
      <circle cx="26.5" cy="34.5" r="1.1" fill="#38BDF8"/>
      <!-- Right Eye -->
      <ellipse cx="46" cy="33" rx="4.8" ry="5.2" fill="#0F172A"/>
      <circle cx="47.8" cy="31.2" r="1.8" fill="#FFFFFF"/>
      <circle cx="44.5" cy="34.5" r="1.1" fill="#38BDF8"/>
    `,n=`
      <!-- Confident Smile -->
      <path d="M 33 41 Q 37 44 41 41" stroke="#0F172A" stroke-width="2.2" stroke-linecap="round" fill="none"/>
    `),`
    <div class="koda-companion-avatar" data-expr="${e}">
      <svg class="koda-svg" viewBox="0 0 74 74" fill="none" xmlns="http://www.w3.org/2000/svg">
        <defs>
          <!-- Fur Gradient: Rich Vibrant Amber-Orange -->
          <linearGradient id="kodaFurGrad" x1="16" y1="12" x2="58" y2="64" gradientUnits="userSpaceOnUse">
            <stop stop-color="#FB923C"/>
            <stop offset="0.45" stop-color="#EA580C"/>
            <stop offset="1" stop-color="#C2410C"/>
          </linearGradient>
          <!-- Charcoal Ears & Accents -->
          <linearGradient id="kodaCharcoalGrad" x1="20" y1="8" x2="54" y2="30" gradientUnits="userSpaceOnUse">
            <stop stop-color="#334155"/>
            <stop offset="1" stop-color="#0F172A"/>
          </linearGradient>
          <!-- Cream Muzzle Gradient -->
          <linearGradient id="kodaCreamGrad" x1="26" y1="34" x2="48" y2="52" gradientUnits="userSpaceOnUse">
            <stop stop-color="#FFFFFF"/>
            <stop offset="1" stop-color="#FEF3C7"/>
          </linearGradient>
          <!-- High-End Ambient Drop Shadow -->
          <filter id="kodaShadow" x="-15%" y="-15%" width="130%" height="130%">
            <feDropShadow dx="0" dy="4" stdDeviation="4.5" flood-color="rgba(15, 23, 42, 0.45)"/>
          </filter>
        </defs>

        <!-- Base Soft Ground Shadow -->
        <ellipse cx="37" cy="67" rx="22" ry="4" fill="rgba(15, 23, 42, 0.25)"/>

        <!-- Ears: Pointed, Sleek with Slate Tips & Cream Inner Tuft -->
        <g id="koda-ears">
          <!-- Left Ear Outer -->
          <path d="M 17 32 C 10 18 16 8 27 15 Z" fill="url(#kodaFurGrad)" stroke="#0F172A" stroke-width="1.8" stroke-linejoin="round"/>
          <!-- Left Ear Slate Tip -->
          <path d="M 12 21 C 11 16 14 10 20 12 Z" fill="url(#kodaCharcoalGrad)"/>
          <!-- Left Ear Inner Cream -->
          <path d="M 18 28 C 14 20 18 15 24 18 Z" fill="#FEF3C7" opacity="0.9"/>

          <!-- Right Ear Outer -->
          <path d="M 57 32 C 64 18 58 8 47 15 Z" fill="url(#kodaFurGrad)" stroke="#0F172A" stroke-width="1.8" stroke-linejoin="round"/>
          <!-- Right Ear Slate Tip -->
          <path d="M 62 21 C 63 16 60 10 54 12 Z" fill="url(#kodaCharcoalGrad)"/>
          <!-- Right Ear Inner Cream -->
          <path d="M 56 28 C 60 20 56 15 50 18 Z" fill="#FEF3C7" opacity="0.9"/>
        </g>

        <!-- Main Head Silhouette (Sleek Geometric Oval with Cheek Fluffs) -->
        <path d="M 15 38 C 12 44 16 52 23 55 C 29 58 45 58 51 55 C 58 52 62 44 59 38 C 58 26 50 18 37 18 C 24 18 16 26 15 38 Z"
              fill="url(#kodaFurGrad)"
              stroke="#0F172A"
              stroke-width="2.2"
              stroke-linejoin="round"
              filter="url(#kodaShadow)"/>

        <!-- Forehead Cyber Diamond Crest (Gold Accent) -->
        <polygon points="37,21 40,25 37,29 34,25" fill="#F59E0B" stroke="#0F172A" stroke-width="1"/>

        <!-- Cheek Flairs & Cream Muzzle (Gender-neutral, sharp & clean) -->
        <path d="M 24 45 C 22 51 28 56 37 56 C 46 56 52 51 50 45 C 47 38 43 35 37 35 C 31 35 27 38 24 45 Z"
              fill="url(#kodaCreamGrad)"
              stroke="#0F172A"
              stroke-width="1.8"/>

        <!-- Sleek Charcoal Nose -->
        <polygon points="35,38 39,38 37,40" fill="#0F172A"/>

        <!-- Eyes -->
        <g id="koda-eyes">
          ${t}
        </g>

        <!-- Mouth -->
        <g id="koda-mouth">
          ${n}
        </g>

        <!-- Accessory (Cyber Glasses if in Focus mode) -->
        ${r}

        <!-- Clean Paws Resting at Bottom -->
        <g id="koda-paws">
          <ellipse cx="27" cy="58" rx="4.5" ry="3.2" fill="#FEF3C7" stroke="#0F172A" stroke-width="1.6"/>
          <ellipse cx="47" cy="58" rx="4.5" ry="3.2" fill="#FEF3C7" stroke="#0F172A" stroke-width="1.6"/>
        </g>
      </svg>
    </div>
  `}function p(){let e=document.getElementById(`apk-companion-pet`);if(!e)return;let t=document.getElementById(`auth-screen`),n=!(localStorage.getItem(`token`)||localStorage.getItem(`nnl_access_token`)||localStorage.getItem(`nnl_auth_token`))&&(document.body.classList.contains(`on-login-screen`)||t&&!t.classList.contains(`hide`));!r()||n?(e.style.setProperty(`display`,`none`,`important`),e.classList.add(`hide`)):(e.classList.remove(`hide`,`hide-on-auth`),e.style.removeProperty(`display`),e.style.setProperty(`display`,`inline-flex`,`important`),e.style.setProperty(`visibility`,`visible`,`important`),e.style.setProperty(`opacity`,`1`,`important`))}var m=null;function h(e=`focus`,t=2400){let n=document.getElementById(`apk-companion-pet`);if(!n)return;let r=n.querySelector(`.apk-pet-avatar`);r&&(r.innerHTML=f(e),n.classList.add(`koda-pop-react`),g(n),clearTimeout(m),m=setTimeout(()=>{r.innerHTML=f(`default`),n.classList.remove(`koda-pop-react`)},t))}function g(e){let t=document.createElement(`div`);t.className=`koda-floating-star`,t.innerHTML=[`⭐`,`✨`,`⚡`,`🩺`,`🎯`][Math.floor(Math.random()*5)],e.appendChild(t),setTimeout(()=>t.remove(),1200)}var _=`bottom-right`;function v(e=`top-right`){let t=document.getElementById(`apk-companion-pet`);t&&(_=e,e===`top-right`?(t.style.top=`max(14px, env(safe-area-inset-top, 14px))`,t.style.bottom=`auto`,t.style.right=`16px`,t.style.left=`auto`):(t.style.top=`auto`,t.style.bottom=`88px`,t.style.right=`16px`,t.style.left=`auto`))}function y(){b()}function b(){if(typeof document>`u`)return;let e=document.getElementById(`apk-companion-pet`);if(!e)e=document.createElement(`div`),e.id=`apk-companion-pet`,e.className=`apk-companion-pet`,e.setAttribute(`role`,`button`),e.setAttribute(`aria-label`,`Koda AI Study Companion`),e.innerHTML=`
      <div class="apk-pet-avatar">${f(`default`)}</div>
    `,document.body.appendChild(e);else{let t=e.querySelector(`.apk-pet-avatar`);t&&(t.innerHTML=f(`default`))}p(),setInterval(()=>{if(document.hidden)return;let t=e.querySelector(`.apk-pet-avatar`);if(!t)return;let n=t.querySelector(`.koda-companion-avatar`)?.getAttribute(`data-expr`);(!n||n==="default")&&(t.innerHTML=f(`blink`),setTimeout(()=>{t.querySelector(`.koda-companion-avatar`)?.getAttribute(`data-expr`)===`blink`&&(t.innerHTML=f(`default`))},180))},3800),e.addEventListener(`click`,e=>{e.preventDefault(),e.stopPropagation();let t=[`focus`,`happy`,`excited`],n=t[Math.floor(Math.random()*t.length)];h(n,2200),d()});let t=null;window.addEventListener(`scroll`,()=>{(window.scrollY||document.documentElement.scrollTop)>250?_!==`top-right`&&(clearTimeout(t),t=setTimeout(()=>v(`top-right`),180)):_!==`bottom-right`&&(clearTimeout(t),t=setTimeout(()=>v(`bottom-right`),180))},{passive:!0}),new MutationObserver(()=>{let t=document.getElementById(`recording-viewer`);t&&!t.classList.contains(`hide`)?(e.style.opacity=`0.35`,v(`bottom-right`)):e.style.removeProperty(`opacity`)}).observe(document.body,{attributes:!0,subtree:!0,attributeFilter:[`class`]});let n=!1,r=0,i=0,a=0,o=0,s=!1;e.addEventListener(`touchstart`,t=>{let c=t.touches?t.touches[0].clientX:t.clientX,l=t.touches?t.touches[0].clientY:t.clientY;n=!0,s=!1,r=c,i=l;let u=e.getBoundingClientRect();a=u.left,o=u.top,e.style.transition=`none`},{passive:!0}),window.addEventListener(`touchmove`,t=>{if(!n)return;let c=t.touches?t.touches[0].clientX:t.clientX,l=t.touches?t.touches[0].clientY:t.clientY,u=c-r,d=l-i;Math.hypot(u,d)>8&&(s=!0);let f=Math.max(8,Math.min(window.innerWidth-64,a+u)),p=Math.max(60,Math.min(window.innerHeight-80,o+d));e.style.left=`${f}px`,e.style.top=`${p}px`,e.style.bottom=`auto`,e.style.right=`auto`},{passive:!0}),window.addEventListener(`touchend`,()=>{if(n&&(n=!1,e.style.transition=`all 0.4s cubic-bezier(0.16, 1, 0.3, 1)`,s)){let t=e.getBoundingClientRect(),n=window.innerWidth/2;t.left<n?(e.style.left=`16px`,e.style.right=`auto`):(e.style.left=`auto`,e.style.right=`16px`)}},{passive:!0})}typeof window<`u`&&(document.readyState===`loading`?document.addEventListener(`DOMContentLoaded`,b):b());function x(){try{let e=localStorage.getItem(`nnl_app_theme`);if(e===`dark`)return!0;if(e===`light`)return!1}catch{}try{if(typeof window.__NNL_SYSTEM_DARK__==`boolean`)return window.__NNL_SYSTEM_DARK__;if(window.AndroidThemeBridge&&typeof window.AndroidThemeBridge.isSystemDark==`function`)return!!window.AndroidThemeBridge.isSystemDark()}catch{}try{return!!(window.matchMedia&&window.matchMedia(`(prefers-color-scheme: dark)`).matches)}catch{return!1}}function S(e,t=!1){let n;try{let r=localStorage.getItem(`nnl_app_theme`);!t&&(r===`dark`||r===`light`)?n=r:(n=e?`dark`:`light`,localStorage.setItem(`nnl_app_theme`,n))}catch{n=e?`dark`:`light`}document.documentElement.setAttribute(`data-theme`,n);try{window.AndroidThemeBridge&&typeof window.AndroidThemeBridge.setDarkMode==`function`&&window.AndroidThemeBridge.setDarkMode(n===`dark`)}catch{}C(n===`dark`)}function C(e){typeof e!=`boolean`&&(e=document.documentElement.getAttribute(`data-theme`)===`dark`);let t=document.getElementById(`apk-theme-light-btn`),n=document.getElementById(`apk-theme-dark-btn`);t&&n&&(t.classList.toggle(`active`,!e),n.classList.toggle(`active`,e))}window.__nnlApplySystemTheme=S,S(x());try{let e=window.matchMedia(`(prefers-color-scheme: dark)`);e&&typeof e.addEventListener==`function`&&e.addEventListener(`change`,e=>S(!!e.matches))}catch{}var w=`<svg viewBox="0 0 64 64" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M18 45V20c7 0 11 5.5 14 11.5C35 37.5 39 43 46 43V18" stroke="#FFFFFF" stroke-width="5.2" stroke-linecap="round" stroke-linejoin="round"/><circle cx="46" cy="11.5" r="3.2" fill="#E9DFFF"/></svg>`,T={home:`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.1" stroke-linecap="round" stroke-linejoin="round"><path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/><polyline points="9 22 9 12 15 12 15 22"/></svg>`,live:`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.1" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="2.2"/><path d="M16.24 7.76a6 6 0 0 1 0 8.49m-8.48-.01a6 6 0 0 1 0-8.49m11.31-2.82a10 10 0 0 1 0 14.14m-14.14 0a10 10 0 0 1 0-14.14"/></svg>`,videos:`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.1" stroke-linecap="round" stroke-linejoin="round"><polygon points="6 4 20 12 6 20 6 4"/></svg>`,notes:`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.1" stroke-linecap="round" stroke-linejoin="round"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/><line x1="8" y1="13" x2="16" y2="13"/><line x1="8" y1="17" x2="13" y2="17"/></svg>`,tests:`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.1" stroke-linecap="round" stroke-linejoin="round"><path d="M9 11l3 3L22 4"/><path d="M21 12v7a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11"/></svg>`,saved:`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.1" stroke-linecap="round" stroke-linejoin="round"><path d="M19 21l-7-5-7 5V5a2 2 0 0 1 2-2h10a2 2 0 0 1 2 2z"/></svg>`,university:`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 21h18M2 10h20M12 3 2 10h20zM6 10v11M10 10v11M14 10v11M18 10v11"/></svg>`,pyqs:`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 21h18M2 10h20M12 3 2 10h20zM6 10v11M10 10v11M14 10v11M18 10v11"/></svg>`,nursing:`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 21h18M2 10h20M12 3 2 10h20zM6 10v11M10 10v11M14 10v11M18 10v11"/></svg>`,refresh:`<svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 12a9 9 0 0 0-9-9 9.75 9.75 0 0 0-6.74 2.74L3 8"/><path d="M3 3v5h5"/><path d="M3 12a9 9 0 0 0 9 9 9.75 9.75 0 0 0 6.74-2.74L21 16"/><path d="M16 16h5v5"/></svg>`,settings:`<svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.1" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-4 0v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1 0-4h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 2.83-2.83l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 4 0v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1z"/></svg>`,back:`<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"><path d="M19 12H5"/><path d="m12 19-7-7 7-7"/></svg>`,close:`<svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"><path d="M18 6 6 18"/><path d="m6 6 12 12"/></svg>`};function E(e){if(!e)return;let t=/[\u{1F300}-\u{1FAFF}\u{2600}-\u{27BF}\u{FE0F}]/u,n=/[\u{1F300}-\u{1FAFF}\u{2600}-\u{27BF}\u{FE0F}]/gu,r=document.createTreeWalker(e,NodeFilter.SHOW_TEXT,null),i;for(;i=r.nextNode();)i.parentElement?.closest(`#apk-hero-greeting, .apk-home-title, #user-phone, .apk-side-name`)||t.test(i.nodeValue)&&(i.nodeValue=i.nodeValue.replace(n,``).replace(/\s{2,}/g,` `));let a=document.getElementById(`vid-tab-all`);if(a){let e=a.querySelector(`span:not(.section-mode-count)`);e&&e.textContent.includes(`Subjects`)&&(e.textContent=`All Subjects`)}let o=document.getElementById(`vid-tab-rb103`);if(o){let e=o.querySelector(`span:not(.section-mode-count)`);e&&e.textContent.includes(`Red Sapphire`)&&(e.textContent=`Batch 103`)}let s=document.getElementById(`vid-tab-offline`);if(s){let e=s.querySelector(`span:not(.section-mode-count)`);e&&e.textContent.includes(`Downloaded`)&&(e.textContent=`Offline`)}e.querySelectorAll(`.sd-note-btn span`).forEach(e=>{e.textContent.includes(`Notes`)&&(e.textContent=`PDF`)}),e.querySelectorAll(`.sd-dl-btn span`).forEach(e=>{e.textContent.trim()===`Download`&&(e.textContent=`Save`),e.textContent.trim()===`Retry Save`&&(e.textContent=`Retry`)})}function D(){document.addEventListener(`pointerdown`,e=>{let t=e.target?.closest?.(`.class-card, .subject-card, .sd-lecture-card, .test-card, .doc-card, .nav-tab, .nav-btn, .apk-icon-btn, .section-mode-tab, .filter-chip, .btn, .sd-lecture-btn, .sd-note-btn, .sd-dl-btn, .sd-del-btn, .btn-note-view, .apk-pill-opt, .apk-pet-card, .continue-watching-card`);if(!t||t.disabled)return;t.classList.add(`apk-water-host`,`apk-pressing`);let n=t.getBoundingClientRect(),r=document.createElement(`span`);r.className=`apk-water-drop`;let i=Math.max(n.width,n.height,44);r.style.width=`${i}px`,r.style.height=`${i}px`,r.style.left=`${e.clientX?e.clientX-n.left:n.width/2}px`,r.style.top=`${e.clientY?e.clientY-n.top:n.height/2}px`,t.appendChild(r),setTimeout(()=>r.remove(),650)},{passive:!0});let e=()=>{document.querySelectorAll(`.apk-pressing`).forEach(e=>e.classList.remove(`apk-pressing`))};document.addEventListener(`pointerup`,e,{passive:!0}),document.addEventListener(`pointercancel`,e,{passive:!0})}function O(){let e=document.getElementById(`apk-side-panel`);e&&(e.classList.remove(`hide`),document.body.classList.add(`apk-side-open`),A())}function k(){let e=document.getElementById(`apk-side-panel`);e&&(e.classList.add(`hide`),document.body.classList.remove(`apk-side-open`))}function A(){let e=document.getElementById(`apk-side-panel`);if(!e)return;let t=s(),n=r(),i=e.querySelector(`#apk-pet-toggle-btn`);i&&(i.classList.toggle(`active`,n),i.classList.toggle(`is-on`,n));let a=e.querySelector(`.apk-companion-status-pill`);a&&(a.textContent=n?`Active 🩺`:`Disabled`,a.classList.toggle(`disabled`,!n)),e.querySelectorAll(`.apk-pet-card, .apk-pet-avatar-item`).forEach(e=>{let r=e.getAttribute(`data-pet-id`);e.classList.toggle(`active`,r===t&&n)})}function j(){if(document.getElementById(`apk-side-panel`))return;let e=document.createElement(`div`);e.id=`apk-side-panel`,e.className=`hide`,e.innerHTML=`
    <div class="apk-side-backdrop" aria-hidden="true"></div>
    <div class="apk-side-drawer" role="dialog" aria-label="Settings & Menu">
      <!-- Header -->
      <div class="apk-side-header">
        <div style="display:flex;align-items:center;gap:12px;">
          <div class="apk-logo-badge" style="width:36px;height:36px;border-radius:11px;">${w}</div>
          <div>
            <div class="apk-side-title">Settings &amp; Menu</div>
          </div>
        </div>
        <button type="button" id="apk-side-close-btn" class="apk-icon-btn" aria-label="Close">${T.close}</button>
      </div>

      <!-- Appearance Card -->
      <div class="apk-side-card">
        <div class="apk-side-section-title">Appearance</div>
        <div class="apk-theme-switcher-bar">
          <button type="button" id="apk-theme-light-btn" class="apk-theme-btn">
            <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2"><circle cx="12" cy="12" r="5"/><line x1="12" y1="1" x2="12" y2="3"/><line x1="12" y1="21" x2="12" y2="23"/><line x1="4.22" y1="4.22" x2="5.64" y2="5.64"/><line x1="18.36" y1="18.36" x2="19.78" y2="19.78"/><line x1="1" y1="12" x2="3" y2="12"/><line x1="21" y1="12" x2="23" y2="12"/><line x1="4.22" y1="19.78" x2="5.64" y2="18.36"/><line x1="18.36" y1="5.64" x2="19.78" y2="4.22"/></svg>
            <span>Light</span>
          </button>
          <button type="button" id="apk-theme-dark-btn" class="apk-theme-btn">
            <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2"><path d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z"/></svg>
            <span>Dark</span>
          </button>
        </div>
      </div>

      <!-- Batch Track Card -->
      <div class="apk-side-card">
        <div class="apk-side-section-title">Batch Track</div>
        <div class="apk-side-batch-row">
          <div style="display:flex;align-items:center;gap:8px;min-width:0;">
            <span style="font-weight:700;font-size:13.5px;color:var(--text-primary);flex-shrink:0;">Current:</span>
            <span style="font-size:12.5px;color:var(--text-secondary);font-weight:600;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;" id="apk-side-batch-label">Red Sapphire (Hinglish)</span>
          </div>
          <button type="button" id="apk-side-batch-btn" class="apk-icon-btn" aria-label="Switch Batch" style="width:32px;height:32px;border-radius:9px;flex-shrink:0;background:rgba(142,116,229,0.18);border:1px solid rgba(142,116,229,0.3);color:var(--accent);">
            <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.3" stroke-linecap="round" stroke-linejoin="round"><path d="M4 17h16M16 13l4 4-4 4M20 7H4M8 3L4 7l4 4"/></svg>
          </button>
        </div>
      </div>

      <!-- Study Companion Card (Compact) -->
      <div class="apk-side-card apk-companion-setting-card" style="padding:10px 14px;">
        <div style="display:flex;align-items:center;justify-content:space-between;">
          <div style="display:flex;align-items:center;gap:10px;">
            <div style="width:34px;height:34px;border-radius:50%;overflow:hidden;background:rgba(124,58,237,0.12);display:flex;align-items:center;justify-content:center;flex-shrink:0;">
              ${o(`default`)}
            </div>
            <div>
              <div style="font-weight:700;font-size:13.5px;color:var(--text-primary);" id="apk-side-companion-name">${a()}</div>
              <div style="font-size:11px;color:var(--text-secondary);">Interactive Companion</div>
            </div>
          </div>
          <button type="button" id="apk-pet-toggle-btn" class="apk-switch-btn" aria-label="Toggle Companion Pet">
            <span class="apk-switch-thumb"></span>
          </button>
        </div>
      </div>

      <!-- Academic Resources Card -->
      <div class="apk-side-card">
        <div class="apk-side-section-title">Saved &amp; Resources</div>
        <div style="display:flex;flex-direction:column;gap:10px;">
          <!-- Single Unified Saved Button -->
          <button type="button" id="apk-side-saved-hub-btn" class="apk-resource-btn">
            <div style="display:flex;align-items:center;gap:12px;">
              <div class="apk-res-icon apk-res-icon-purple">
                <svg width="15" height="15" viewBox="0 0 24 24" fill="currentColor"><path d="M19 21l-7-5-7 5V5a2 2 0 0 1 2-2h10a2 2 0 0 1 2 2z"/></svg>
              </div>
              <span class="apk-res-label">Saved Content</span>
            </div>
            <svg class="apk-res-arrow" width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"><polyline points="9 18 15 12 9 6"/></svg>
          </button>

          <!-- University Question Papers (PYQ) -->
          <button type="button" id="apk-side-pyq-btn" class="apk-resource-btn">
            <div style="display:flex;align-items:center;gap:12px;">
              <div class="apk-res-icon apk-res-icon-indigo" style="background:rgba(142,116,229,0.2);color:#A78BFA;">
                <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.1" stroke-linecap="round" stroke-linejoin="round">
                  <path d="M3 21h18M2 10h20M12 3 2 10h20zM6 10v11M10 10v11M14 10v11M18 10v11"/>
                </svg>
              </div>
              <span class="apk-res-label">University Question Papers</span>
            </div>
            <svg class="apk-res-arrow" width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"><polyline points="9 18 15 12 9 6"/></svg>
          </button>

          <!-- Red Sapphire Brochure & Timetable -->
          <button type="button" id="apk-side-brochure-btn" class="apk-resource-btn">
            <div style="display:flex;align-items:center;gap:12px;">
              <div class="apk-res-icon apk-res-icon-indigo">
                <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/></svg>
              </div>
              <span class="apk-res-label">Brochure &amp; Timetable</span>
            </div>
            <svg class="apk-res-arrow" width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"><polyline points="9 18 15 12 9 6"/></svg>
          </button>
        </div>
      </div>

      <!-- App Version & Updates Card (Compact) -->
      <div class="apk-side-card apk-ota-update-card" style="padding:10px 14px; margin-bottom:8px;">
        <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:6px;">
          <div class="apk-side-section-title" style="margin:0;font-size:12.5px;">App Updates</div>
          <span id="apk-side-ver-tag" class="apk-ota-badge" style="font-size:10.5px;font-weight:700;padding:2px 7px;border-radius:6px;background:rgba(124,58,237,0.18);color:var(--accent);border:1px solid rgba(167,139,250,0.3);">v1.0.33</span>
        </div>
        <div style="display:flex;flex-direction:column;width:100%;gap:6px;">
          <button type="button" id="apk-side-check-update-btn" class="apk-theme-btn" style="width:100%;justify-content:center;height:34px;font-size:12px;font-weight:700;background:rgba(255,255,255,0.08);border:1px solid rgba(255,255,255,0.14);color:var(--text-primary);border-radius:9px;cursor:pointer;display:inline-flex;align-items:center;gap:6px;padding:0 12px;transition:all 0.2s ease;">
            <svg id="apk-side-check-icon" width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M21.5 2v6h-6M21.34 15.57a10 10 0 1 1-.57-8.38l5.67-5.67"/></svg>
            <span id="apk-side-check-txt">Check for Update</span>
          </button>
          <button type="button" id="apk-side-download-apk-btn" class="apk-theme-btn" style="width:100%;justify-content:center;height:32px;font-size:11.5px;font-weight:700;background:rgba(124,58,237,0.18);border:1px solid rgba(167,139,250,0.3);color:#DDD6FE;border-radius:9px;cursor:pointer;display:none;align-items:center;gap:6px;padding:0 10px;transition:all 0.2s ease;">
            <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/></svg>
            <span>Download APK (Manual Install)</span>
          </button>
        </div>
        <div id="apk-update-status-msg" style="font-size:11px;color:var(--text-secondary);font-weight:600;display:none;margin-top:4px;text-align:center;"></div>
      </div>

      <!-- Bottom Pinned Footer: Sign Out -->
      <div class="apk-side-footer">
        <button id="apk-sheet-logout-btn" type="button" class="apk-signout-btn">
          <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"/><polyline points="16 17 21 12 16 7"/><line x1="21" y1="12" x2="9" y2="12"/></svg>
          <span id="apk-sheet-logout-txt">${localStorage.getItem(`nnl_access_token`)?`Sign Out`:`Log in with Mobile Number`}</span>
        </button>
      </div>
    </div>
  `,document.body.appendChild(e),e.querySelector(`.apk-side-backdrop`)?.addEventListener(`click`,k),e.querySelector(`#apk-side-close-btn`)?.addEventListener(`click`,k),e.querySelector(`#apk-pet-toggle-btn`)?.addEventListener(`click`,()=>{i(!r()),A()}),e.querySelectorAll(`.apk-pet-card, .apk-pet-avatar-item`).forEach(e=>{e.addEventListener(`click`,()=>{let t=e.getAttribute(`data-pet-id`);t&&(r()||i(!0),c(t),A())})}),e.querySelector(`#apk-side-pyq-btn`)?.addEventListener(`click`,()=>{k(),window.location.href=`/pyqs.html`}),e.querySelector(`#apk-side-saved-hub-btn`)?.addEventListener(`click`,()=>{k(),window.location.href=`/saved.html`}),e.querySelector(`#apk-side-batch-btn`)?.addEventListener(`click`,()=>{k(),L()}),e.querySelector(`#apk-side-brochure-btn`)?.addEventListener(`click`,()=>{k(),typeof window.__nnlOpenBrochure==`function`?window.__nnlOpenBrochure():window.location.href=`/notes.html?openBrochure=1`}),e.querySelector(`#apk-theme-light-btn`)?.addEventListener(`click`,()=>S(!1,!0)),e.querySelector(`#apk-theme-dark-btn`)?.addEventListener(`click`,()=>S(!0,!0));let t=e.querySelector(`#apk-side-check-update-btn`),n=e.querySelector(`#apk-side-check-txt`),s=e.querySelector(`#apk-side-download-apk-btn`),l=e.querySelector(`#apk-update-status-msg`),u=e.querySelector(`#apk-side-ver-tag`),d=null,f=``;async function p(e,t){let n=t?t.querySelector(`#apk-modal-progress-wrap`):null,r=t?t.querySelector(`#apk-modal-progress-txt`):null,i=t?t.querySelector(`#apk-modal-progress-bar`):null,a=t?t.querySelector(`.apk-update-actions`):null;n&&i&&r?(a&&(a.style.display=`none`),n.style.display=`flex`,r.textContent=`Downloading 0%`,i.style.width=`0%`):e&&(e.disabled=!0,e.innerHTML=`<div style="display:flex;align-items:center;justify-content:center;gap:6px;width:100%;"><span class="spinner" style="width:12px;height:12px;border-width:2px;"></span><span>Downloading 0%</span></div>`),l&&(l.textContent=`Downloading update...`,l.style.display=`block`);try{let o=await fetch(`/__ota/apk-progress?t=${Date.now()}`).then(e=>e.json()).catch(()=>null);if(!o||!o.ready)for(await fetch(`/__ota/start-apk-download`,{method:`POST`});;){await new Promise(e=>setTimeout(e,400));let t=await fetch(`/__ota/apk-progress?t=${Date.now()}`).then(e=>e.json()).catch(()=>null);if(!t||t.state===`ready`)break;if(t.state===`error`)throw Error(t.error||`Download failed`);let a=Math.max(0,Math.min(100,t.percent||0));n&&i&&r?(r.textContent=`Downloading ${a}%`,i.style.width=`${a}%`):e&&(e.innerHTML=`<div style="display:flex;align-items:center;justify-content:center;gap:6px;width:100%;"><span class="spinner" style="width:12px;height:12px;border-width:2px;"></span><span>Downloading ${a}%</span></div>`)}if(await fetch(`/__ota/open-downloads`,{method:`POST`}).catch(()=>{}),l&&(l.textContent=`Download complete`,l.style.color=`#10B981`,l.style.display=`block`),n&&a){n.style.display=`none`,a.style.display=`flex`;let e=t.querySelector(`#apk-update-modal-download`);e&&(e.disabled=!1,e.textContent=`Install Update`,e.onclick=async()=>{await fetch(`/__ota/launch-installer`,{method:`POST`}).catch(()=>{})})}e&&(e.disabled=!1,e.textContent=`Install Update`,e.onclick=async()=>{await fetch(`/__ota/launch-installer`,{method:`POST`}).catch(()=>{})})}catch(t){console.warn(`Bridge APK download fallback:`,t),window.location.href=`https://raw.githubusercontent.com/takexuu-ux/Nightingale/refs/heads/ota-hinglish/Nightingale.apk`,l&&(l.textContent=`Downloading in browser...`,l.style.display=`block`),e&&(e.disabled=!1,e.textContent=`Download APK`)}}function m(e,t){if(document.getElementById(`apk-update-prompt-modal`))return;let n=document.createElement(`div`);n.id=`apk-update-prompt-modal`,n.className=`apk-update-prompt-overlay`,n.innerHTML=`
      <div class="apk-update-prompt-card">
        <div class="apk-update-icon-glow">
          <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="#A78BFA" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round">
            <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/>
            <polyline points="7 10 12 15 17 10"/>
            <line x1="12" y1="15" x2="12" y2="3"/>
          </svg>
        </div>
        <h3 class="apk-update-title">Update Ready (${t})</h3>
        <p class="apk-update-desc">A fresh update is available with performance optimizations and stability fixes.</p>
        
        <!-- Centered Download Progress Bar Widget -->
        <div id="apk-modal-progress-wrap" style="display:none;width:100%;flex-direction:column;align-items:center;justify-content:center;gap:10px;margin:12px 0;">
          <span id="apk-modal-progress-txt" style="font-size:12px;font-weight:700;color:#f1f5f9;text-align:center;">Downloading 0%</span>
          <div style="width:100%;height:6px;background:rgba(255,255,255,0.12);border-radius:99px;overflow:hidden;">
            <div id="apk-modal-progress-bar" style="width:0%;height:100%;background:linear-gradient(90deg, #7c3aed 0%, #10B981 100%);border-radius:99px;transition:width 0.2s ease;"></div>
          </div>
        </div>

        <div class="apk-update-actions">
          <button id="apk-update-modal-btn" class="apk-update-btn-primary" type="button">Update Now</button>
          <button id="apk-update-modal-download" class="apk-update-btn-secondary" type="button">Download APK File</button>
          <button id="apk-update-modal-dismiss" class="apk-update-btn-dismiss" type="button">Later</button>
        </div>
      </div>
    `,document.body.appendChild(n);let r=n.querySelector(`#apk-update-modal-btn`),i=n.querySelector(`#apk-update-modal-download`),a=n.querySelector(`#apk-update-modal-dismiss`);a?.addEventListener(`click`,()=>n.remove()),r?.addEventListener(`click`,async()=>{r.disabled=!0,a&&(a.style.display=`none`);let t=n.querySelector(`#apk-modal-progress-wrap`),i=n.querySelector(`#apk-modal-progress-txt`),o=n.querySelector(`#apk-modal-progress-bar`),s=n.querySelector(`.apk-update-actions`);if(e===`apk`||d===`apk`)t&&(t.style.display=`flex`),s&&(s.style.display=`none`),await p(r,n);else{t&&(t.style.display=`flex`),s&&(s.style.display=`none`);let e=12;i&&(i.textContent=`Downloading update... ${e}%`),o&&(o.style.width=`${e}%`);let a=setInterval(()=>{e<92&&(e+=Math.floor(Math.random()*8)+5,e>92&&(e=92),i&&(i.textContent=`Downloading update... ${e}%`),o&&(o.style.width=`${e}%`))},120);try{let e=await(await fetch(`/__ota/apply`,{method:`POST`})).json();if(clearInterval(a),e.ok)i&&(i.textContent=`100% Complete (Restarting...)`),o&&(o.style.width=`100%`),setTimeout(()=>window.location.reload(),450);else throw Error(e.error||`Apply failed`)}catch(e){clearInterval(a),console.warn(`Web update apply failed, downloading APK instead:`,e),i&&(i.textContent=`Downloading APK...`),await p(r,n)}}}),i?.addEventListener(`click`,async()=>{i.disabled=!0,a&&(a.style.display=`none`),await p(i,n)})}e.querySelector(`#apk-side-check-icon`);async function h(e=!1){t&&!e&&(t.disabled=!0,t.innerHTML=`<span class="spinner" style="width:14px;height:14px;border-width:2px;display:inline-block;border-color:rgba(167,139,250,0.3);border-top-color:#a78bfa;"></span>`);try{let n=Date.now(),r=await fetch(`/__ota/check?t=${Date.now()}`);if(!e){let e=Date.now()-n;e<650&&await new Promise(t=>setTimeout(t,650-e))}if(r.ok){let e=await r.json(),n=!!e.hasWebUpdate,i=!!e.hasNativeUpdate;n?(d=`web`,f=`v${e.remoteWebVersion||92}`,u&&(u.textContent=`${f} Ready`,u.style.background=`rgba(16, 185, 129, 0.16)`,u.style.color=`#10b981`,u.style.borderColor=`rgba(16, 185, 129, 0.3)`),t&&(t.disabled=!1,t.innerHTML=`<span id="apk-side-check-txt">Install Update (${f})</span>`,t.style.background=`linear-gradient(135deg, #10b981 0%, #059669 100%)`,t.style.borderColor=`#10b981`,t.style.color=`#ffffff`),s&&(s.style.display=`none`),m(`web`,f)):i?(d=`apk`,f=`v1.0.${e.remoteNativeVersionCode}`,u&&(u.textContent=`${f} Ready`,u.style.background=`rgba(124, 58, 237, 0.16)`,u.style.color=`#a78bfa`,u.style.borderColor=`rgba(124, 58, 237, 0.3)`),t&&(t.disabled=!1,t.innerHTML=`<span id="apk-side-check-txt">Install Update (${f})</span>`,t.style.background=`linear-gradient(135deg, #7c3aed 0%, #6366f1 100%)`,t.style.borderColor=`#7c3aed`,t.style.color=`#ffffff`),s&&(s.style.display=`inline-flex`),m(`apk`,f)):(d=null,u&&(u.textContent=`v1.0.${e.currentNativeVersionCode||39}`,u.style.background=`rgba(124,58,237,0.18)`,u.style.color=`var(--accent)`,u.style.borderColor=`rgba(167,139,250,0.3)`),s&&(s.style.display=`none`),t&&(t.disabled=!1,t.innerHTML=`<span style="font-size:12px;font-weight:700;color:#10B981;">Up to Date</span>`,t.style.background=`rgba(255,255,255,0.08)`,t.style.borderColor=`rgba(255,255,255,0.14)`,t.style.color=`var(--text-primary)`,setTimeout(()=>{!d&&t&&(t.innerHTML=`
                  <svg id="apk-side-check-icon" width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M21.5 2v6h-6M21.34 15.57a10 10 0 1 1-.57-8.38l5.67-5.67"/></svg>
                  <span id="apk-side-check-txt">Check for Update</span>
                `)},3e3)))}else throw Error(`Check failed`)}catch{t&&(t.disabled=!1,t.innerHTML=`
          <svg id="apk-side-check-icon" width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M21.5 2v6h-6M21.34 15.57a10 10 0 1 1-.57-8.38l5.67-5.67"/></svg>
          <span id="apk-side-check-txt">Check for Update</span>
        `)}}s&&s.addEventListener(`click`,e=>{e.stopPropagation(),p(s)}),t&&t.addEventListener(`click`,async e=>{if(e.stopPropagation(),d===`web`){m(`web`,f),t.disabled=!0;let e=8;n&&(n.innerHTML=`<span class="spinner" style="width:12px;height:12px;border-width:2px;display:inline-block;vertical-align:middle;margin-right:6px;"></span><span>Updating ${e}%</span>`);let r=setInterval(()=>{e<90&&(e+=Math.floor(Math.random()*8)+6,e>90&&(e=90),n&&(n.innerHTML=`<span class="spinner" style="width:12px;height:12px;border-width:2px;display:inline-block;vertical-align:middle;margin-right:6px;"></span><span>Updating ${e}%</span>`))},140);try{let e=await(await fetch(`/__ota/apply`,{method:`POST`})).json();if(clearInterval(r),e.ok)n&&(n.textContent=`Reloading 100%...`),setTimeout(()=>window.location.reload(),400);else throw Error(e.error||`Apply failed`)}catch{clearInterval(r),t.disabled=!1,n&&(n.textContent=`Retry Update`)}}else if(d===`apk`){t.disabled=!0,n&&(n.innerHTML=`<span class="spinner" style="width:12px;height:12px;border-width:2px;display:inline-block;vertical-align:middle;margin-right:6px;"></span><span>Downloading APK...</span>`);try{let e=await fetch(`/__ota/apk-progress?t=${Date.now()}`);if(e.ok&&(await e.json()).ready){t.disabled=!1,n&&(n.textContent=`Install Update`),l&&(l.textContent=`Download complete`,l.style.display=`block`),await fetch(`/__ota/launch-installer`,{method:`POST`});return}for(await fetch(`/__ota/start-apk-download`,{method:`POST`});;){await new Promise(e=>setTimeout(e,350));let e=await fetch(`/__ota/apk-progress?t=${Date.now()}`);if(!e.ok)break;let r=await e.json();if(r.state===`ready`){t.disabled=!1,n&&(n.textContent=`Install Update`),l&&(l.textContent=`Download complete`,l.style.display=`block`),await fetch(`/__ota/launch-installer`,{method:`POST`});break}if(r.state===`error`)throw Error(r.error||`Download error`);r.state===`downloading`&&n&&(n.innerHTML=`<span class="spinner" style="width:12px;height:12px;border-width:2px;display:inline-block;vertical-align:middle;margin-right:6px;"></span><span>Downloading ${r.percent||0}%</span>`)}}catch{t.disabled=!1,n&&(n.textContent=`Retry Download`)}}else h(!1)}),setTimeout(()=>h(!0),1200),e.querySelector(`#apk-sheet-logout-btn`)?.addEventListener(`click`,()=>{try{sessionStorage.setItem(`nnl_explicit_logout`,`true`)}catch{}try{localStorage.removeItem(`nnl_access_token`)}catch{}try{localStorage.removeItem(`nnl_refresh_token`)}catch{}try{localStorage.removeItem(`nnl_guest_mode`)}catch{}try{localStorage.removeItem(`nnl_phone`)}catch{}try{localStorage.removeItem(`nnl_user_phone`)}catch{}try{localStorage.removeItem(`nnl_user_id`)}catch{}try{window.AndroidAuthBridge?.clearSession?.()}catch{}window.location.replace(`/`)}),C();let g=0,_=0;window.addEventListener(`touchstart`,e=>{e.touches.length===1&&(g=e.touches[0].clientX,_=e.touches[0].clientY)},{passive:!0}),window.addEventListener(`touchend`,t=>{if(t.changedTouches.length!==1)return;let n=t.changedTouches[0].clientX-g,r=t.changedTouches[0].clientY-_;Math.abs(r)>70||n<-60&&!e.classList.contains(`hide`)&&k()},{passive:!0});let v=()=>{let e=document.getElementById(`apk-ota-settings-box`),t=document.getElementById(`apk-sheet-ota-slot`);e&&t&&e.parentElement!==t&&(e.style.cssText=`padding:12px 14px;border-radius:16px;background:var(--bg-subtle);border:1px solid var(--border-hairline);`,t.appendChild(e));let n=document.getElementById(`apk-header-update-btn`);if(n){let e=n.textContent||``,t=document.getElementById(`apk-settings-dot`);t&&(e.includes(`Get`)||e.includes(`Update v`)||e.includes(`APK`))&&t.classList.remove(`hide`),n.style.display=`none`}};v(),window.__nnlAdoptOtaBox=v,A()}var M=[{value:`Red Sapphire (Hinglish)`,label:`Red Sapphire`,sub:`Hinglish`},{value:`Blue Sapphire (Hinglish)`,label:`Blue Sapphire`,sub:`Hinglish`},{value:`Red Sapphire (English)`,label:`Red Sapphire`,sub:`English`},{value:`Fast Track`,label:`Fast Track`,sub:`Crash Course`}];function N(){try{let e=localStorage.getItem(`nnl_active_batch`);if(e&&M.some(t=>t.value===e))return e}catch{}return`Red Sapphire (Hinglish)`}function P(e){let t=M.find(t=>t.value===e)||M[0];return e===`Red Sapphire (English)`?`Red Sapphire Eng`:t.label}var F=`<svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.6" stroke-linecap="round" stroke-linejoin="round"><polyline points="6 9 12 15 18 9"></polyline></svg>`;function I(){let e=N(),t=P(e);document.querySelectorAll(`.apk-batch-pill-btn`).forEach(n=>{n.dataset.batch=e,n.innerHTML=`<span>${t}</span>${F}`});let n=document.getElementById(`apk-side-batch-label`);n&&(n.textContent=e)}function L(){let e=document.getElementById(`apk-batch-sheet`);e&&e.remove();let t=N(),n=document.createElement(`div`);n.id=`apk-batch-sheet`,n.className=`apk-sheet-backdrop`,n.innerHTML=`
    <div class="apk-sheet-card" role="dialog" aria-modal="true" aria-label="Switch Batch">
      <div style="display:flex;align-items:center;justify-content:space-between;gap:10px;">
        <div>
          <div style="font-size:16px;font-weight:800;color:var(--text-primary);">Switch Batch</div>
          <div style="font-size:12px;color:var(--text-secondary);">Select your active classroom track</div>
        </div>
        <button type="button" class="apk-icon-btn apk-sheet-close" aria-label="Close">
          ${T.close}
        </button>
      </div>
      <div class="apk-batch-options-list" style="display:flex;flex-direction:column;gap:8px;padding:2px 0;">
        ${M.map(e=>{let n=e.value===t;return`
            <button type="button" class="apk-batch-option ${n?`active`:``}" data-batch-value="${e.value}">
              <div style="display:flex;flex-direction:column;align-items:flex-start;gap:2px;">
                <span style="font-weight:800;font-size:13.5px;">${e.label}</span>
                <span style="font-size:11.5px;opacity:0.72;font-weight:600;">${e.sub}</span>
              </div>
              <span class="apk-batch-check" style="display:inline-flex;align-items:center;justify-content:center;width:22px;height:22px;border-radius:99px;">
                ${n?`<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.8" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 6 9 17 4 12"/></svg>`:``}
              </span>
            </button>
          `}).join(``)}
      </div>
    </div>
  `,n.addEventListener(`click`,e=>{if(e.target===n||e.target.closest(`.apk-sheet-close`)){n.remove();return}let t=e.target.closest(`.apk-batch-option`);if(!t)return;let r=t.dataset.batchValue;if(r){try{localStorage.setItem(`nnl_active_batch`,r)}catch{}if(I(),n.remove(),typeof window.__nnlSelectBatch==`function`)try{window.__nnlSelectBatch(r)}catch{}else{let e=document.getElementById(`batch-select`);e&&(e.value=r,e.dispatchEvent(new Event(`change`,{bubbles:!0})))}}}),document.body.appendChild(n)}function R(){window.location.href=`/pyqs.html`}window.openPyqYearSelectorModal=R;function z(){[{id:`tab-live`,url:`/`,icon:T.home,label:`Home`},{id:`tab-videos`,url:`/all-videos.html`,icon:T.videos,label:`Videos`},{id:`tab-notes`,url:`/notes.html`,icon:T.notes,label:`Notes`},{id:`tab-tests`,url:`/tests.html`,icon:T.tests,label:`Tests`},{id:`tab-saved`,url:`/saved.html`,icon:T.saved,label:`Saved`},{id:`tab-pyqs`,url:`/pyqs.html`,icon:T.university,label:`University`}].forEach(({id:e,url:t,icon:n,label:r})=>{let i=document.getElementById(e);i&&(i.innerHTML=`${n}<span>${r}</span>`,i.removeAttribute(`onclick`),i.removeAttribute(`title`),i.__nnlFluidNavBound||(i.__nnlFluidNavBound=!0,i.addEventListener(`click`,e=>{e.preventDefault(),e.stopPropagation();let n=(window.location.pathname.replace(/^\//,``).replace(/\/$/,``)||`index.html`).toLowerCase(),r=(t.replace(/^\//,``).replace(/\/$/,``)||`index.html`).toLowerCase();if(n===r||n===`index.html`&&r===`index.html`){window.scrollTo({top:0,behavior:`smooth`});return}let a=i.closest(`.nav-tabs`)||document.querySelector(`.header-nav-tabs .nav-tabs, .app-header .nav-tabs`);if(a){a.querySelectorAll(`.nav-tab`).forEach(e=>e.classList.remove(`active`,`floating-active`)),i.classList.add(`active`);let e=document.getElementById(`apk-nav-liquid-indicator`);e&&i.offsetWidth>0&&(e.style.width=`${i.offsetWidth}px`,e.style.height=`${i.offsetHeight}px`,e.style.transform=`translate3d(${i.offsetLeft}px, ${i.offsetTop}px, 0)`,e.style.opacity=`1`)}let o=document.querySelector(`main, #catalog-view, #tests-catalog-view, #notes-catalog-view, .main-container`);o&&o.classList.add(`page-glide-out`),setTimeout(()=>{window.location.href=t},75)})))});let t=document.getElementById(`tab-upcoming`);t&&t.remove(),[`refetch-btn`,`videos-refetch-btn`,`notes-refetch-btn`,`tests-refetch-btn`].forEach(e=>{let t=document.getElementById(e);t&&(t.innerHTML=T.refresh,t.setAttribute(`aria-label`,`Refresh`))}),[`btn-back-to-subjects`,`btn-back-subjects`,`btn-back-tests`].forEach(e=>{let t=document.getElementById(e);t&&(t.innerHTML=T.back,t.setAttribute(`aria-label`,`Back`))}),[`pdf-modal-close-btn`,`close-recording-viewer`,`quiz-top-close-btn`].forEach(e=>{let t=document.getElementById(e);t&&(t.className=`apk-icon-btn`,t.innerHTML=T.close,t.setAttribute(`aria-label`,`Close`))});let n=document.getElementById(`apk-hamburger-btn`);n||(n=document.createElement(`button`),n.id=`apk-hamburger-btn`,n.className=`apk-hamburger-btn`,n.type=`button`,n.setAttribute(`aria-label`,`Open Menu & Settings`),n.innerHTML=`<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.3" stroke-linecap="round" stroke-linejoin="round"><line x1="3" y1="6" x2="21" y2="6"></line><line x1="3" y1="12" x2="21" y2="12"></line><line x1="3" y1="18" x2="21" y2="18"></line></svg>`),n&&!n.__bound&&(n.__bound=!0,n.addEventListener(`click`,e=>{e.preventDefault(),e.stopPropagation(),O()})),window.__nnlHamBound||(window.__nnlHamBound=!0,document.addEventListener(`click`,e=>{let t=e.target;t&&t.closest(`#apk-hamburger-btn, .apk-hamburger-btn`)&&(e.preventDefault(),e.stopPropagation(),O())},!0));let r=document.getElementById(`app-header`);function i(){n&&(window.innerWidth>=880&&window.matchMedia&&window.matchMedia(`(orientation: landscape)`).matches||window.innerWidth>=1024?r&&n.parentElement!==r&&r.insertBefore(n,r.firstChild):n.parentElement!==document.body&&document.body.appendChild(n))}i(),window.addEventListener(`resize`,i),window.addEventListener(`orientationchange`,i),window.__nnlBatchClickBound||(window.__nnlBatchClickBound=!0,document.addEventListener(`click`,e=>{if(e.target.closest(`.apk-batch-pill-btn`)){e.preventDefault(),L();return}})),I();let a=document.querySelector(`.preloader-logo`);if(a&&!a.querySelector(`.apk-logo-badge`)){let e=document.createElement(`div`);e.className=`apk-logo-badge`,e.innerHTML=w,a.insertBefore(e,a.firstChild);let t=a.querySelector(`.logo-text`);t&&(t.textContent=`Nightingale`);let n=document.querySelector(`.preloader-status-container`);n&&n.remove()}let o=document.querySelector(`.header-logo`);o&&o.style.setProperty(`display`,`none`,`important`);let s=()=>{let e=document.getElementById(`auth-screen`),t=!(localStorage.getItem(`token`)||localStorage.getItem(`nnl_access_token`)||localStorage.getItem(`nnl_auth_token`)||localStorage.getItem(`nnl_guest_mode`)===`true`)&&!!(e&&!e.classList.contains(`hide`));document.body.classList.contains(`apk-is-auth`)!==t&&document.body.classList.toggle(`apk-is-auth`,t);let n=document.getElementById(`apk-hamburger-btn`);n&&(t?n.style.setProperty(`display`,`none`,`important`):n.style.removeProperty(`display`));let r=document.getElementById(`apk-side-drawer`);r&&t?(r.style.setProperty(`display`,`none`,`important`),k()):r&&r.style.removeProperty(`display`)};s();let c=document.getElementById(`auth-screen`);if(c){new MutationObserver(s).observe(c,{attributes:!0,attributeFilter:[`class`]});let t=c.closest(`.auth-hero-wrapper`);if(t&&!document.getElementById(`apk-auth-showcase`)){let e=document.createElement(`div`);e.id=`apk-auth-showcase`,e.className=`apk-auth-showcase`,e.innerHTML=`
        <div class="apk-brand-inline-row">
          <h1 class="apk-showcase-title apk-brand-gradient-text">NIGHTINGALE</h1>
        </div>
        <div class="apk-showcase-pills">
          <span class="apk-showcase-pill">Live</span>
          <span class="apk-showcase-pill">Lectures</span>
          <span class="apk-showcase-pill">Notes</span>
        </div>
      `,t.insertBefore(e,c)}let n=document.querySelector(`.apk-auth-showcase .apk-logo-badge`);n&&n.remove();let r=c.querySelector(`.brand-subtitle`);r&&(r.textContent=`Enter your registered mobile number`);let i=document.getElementById(`phone-input`);i&&(i.placeholder=`10-digit number`);let a=document.querySelector(`#send-otp-btn span`);if(a&&(a.textContent=`Get OTP`),t&&!document.getElementById(`apk-auth-botanical`)){let n=document.createElement(`div`);n.id=`apk-auth-botanical`,n.className=`apk-auth-botanical`,n.innerHTML=`
        <img src="${e}" alt="Botanical anatomical heart and lungs illustration" class="apk-botanical-img" draggable="false" />
        <div class="apk-botanical-sparks" aria-hidden="true"></div>
      `;let r=n.querySelector(`.apk-botanical-sparks`),i=0,a=[`<svg viewBox="0 0 24 24" width="10" height="10" fill="none"><g transform="translate(12,12)"><circle cx="0" cy="-3.5" r="2.5" fill="#F472B6"/><circle cx="3.5" cy="-1.2" r="2.5" fill="#FBCFE8"/><circle cx="2" cy="3" r="2.5" fill="#EC4899"/><circle cx="-2" cy="3" r="2.5" fill="#F472B6"/><circle cx="-3.5" cy="-1.2" r="2.5" fill="#FBCFE8"/><circle cx="0" cy="0" r="1.5" fill="#FDE047"/></g></svg>`,`<svg viewBox="0 0 24 24" width="10" height="10" fill="none"><g transform="translate(12,12)"><circle cx="0" cy="-3" r="2.2" fill="#C084FC"/><circle cx="3" cy="1" r="2.2" fill="#DDD6FE"/><circle cx="-3" cy="1" r="2.2" fill="#A855F7"/><circle cx="0" cy="2.5" r="1.8" fill="#E9D5FF"/><circle cx="0" cy="0" r="1.2" fill="#FEF08A"/></g></svg>`,`<svg viewBox="0 0 24 24" width="10" height="10" fill="none"><g transform="translate(12,12)"><ellipse cx="0" cy="-4" rx="1.4" ry="2.6" fill="#FFFFFF"/><ellipse cx="3.5" cy="-2" rx="1.4" ry="2.6" transform="rotate(60 3.5 -2)" fill="#FDF4FF"/><ellipse cx="3.5" cy="2" rx="1.4" ry="2.6" transform="rotate(120 3.5 2)" fill="#FFFFFF"/><ellipse cx="0" cy="4" rx="1.4" ry="2.6" fill="#FDF4FF"/><ellipse cx="-3.5" cy="2" rx="1.4" ry="2.6" transform="rotate(60 -3.5 2)" fill="#FFFFFF"/><ellipse cx="-3.5" cy="-2" rx="1.4" ry="2.6" transform="rotate(120 -3.5 -2)" fill="#FDF4FF"/><circle cx="0" cy="0" r="1.8" fill="#FACC15"/></g></svg>`,`<svg viewBox="0 0 24 24" width="9" height="9" fill="none"><path d="M4 20C4 20 7 11 20 4C20 4 17 17 4 20Z" fill="#34D399" opacity="0.9"/></svg>`,`<svg viewBox="0 0 24 24" width="10" height="10" fill="none"><path d="M12 2C8 6 5 10 5 14a7 7 0 0 0 14 0c0-4-3-8-7-12z" fill="#FB7185" opacity="0.92"/></svg>`,`<svg viewBox="0 0 24 24" width="9" height="9" fill="none"><circle cx="12" cy="12" r="2.6" fill="#FDE047"/><path d="M12 3v18M3 12h18" stroke="#FEF08A" stroke-width="1.4" stroke-linecap="round"/></svg>`],o=(e,t,i=!1)=>{if(!r)return;let o=n.getBoundingClientRect(),s=e-o.left,c=t-o.top;if(s<6||c<6||s>o.width-6||c>o.height-6)return;let l=document.createElement(`span`);l.className=`apk-cursor-flower`,l.innerHTML=a[Math.floor(Math.random()*a.length)],l.style.left=`${s}px`,l.style.top=`${c}px`;let u=Math.random()*Math.PI*2,d=5+Math.random()*12,f=Math.cos(u)*d,p=Math.sin(u)*d-(4+Math.random()*7),m=(Math.random()-.5)*60,h=i?.34+Math.random()*.12:.44+Math.random()*.12;l.style.setProperty(`--target-x`,`${f}px`),l.style.setProperty(`--target-y`,`${p}px`),l.style.setProperty(`--target-rot`,`${m}deg`),l.style.setProperty(`--target-scale`,`${h}`),r.appendChild(l),setTimeout(()=>l.remove(),750)};n.addEventListener(`pointermove`,e=>{let t=Date.now();t-i<90||(i=t,o(e.clientX,e.clientY,!0))}),n.addEventListener(`pointerdown`,e=>{o(e.clientX,e.clientY,!1)}),n.addEventListener(`touchstart`,e=>{if(!e.touches||!e.touches[0])return;try{e.preventDefault()}catch{}let t=e.touches[0];o(t.clientX,t.clientY,!1)},{passive:!1}),n.addEventListener(`touchmove`,e=>{if(!e.touches||!e.touches[0])return;try{e.preventDefault()}catch{}let t=Date.now();if(t-i<55)return;i=t;let n=e.touches[0];o(n.clientX,n.clientY,!0)},{passive:!1}),t.appendChild(n)}}}function B(){let e=localStorage.getItem(`token`)||localStorage.getItem(`nnl_access_token`)||localStorage.getItem(`nnl_auth_token`),t=localStorage.getItem(`nnl_guest_mode`)===`true`||e===`GUEST_OPEN_ACCESS`;e===`GUEST_DEMO_TOKEN`&&(localStorage.removeItem(`token`),localStorage.removeItem(`nnl_access_token`),e=null);let n=window.location.pathname||`/`,r=/\/(all-videos|notes|tests|saved|pyqs)\.html$/i.test(n),i=sessionStorage.getItem(`nnl_explicit_logout`)===`true`;if(r&&(!e&&!t||i)){document.documentElement.style.visibility=`hidden`;try{window.AndroidAuthBridge?.clearSession?.()}catch{}return window.location.replace(`/`),!1}return e||t?(document.body.classList.remove(`apk-is-auth`,`on-login-screen`),document.body.classList.add(`is-logged-in`),document.documentElement.classList.add(`is-logged-in`)):r||(document.body.classList.add(`apk-is-auth`),document.getElementById(`app-header`)?.classList.add(`hide`),document.getElementById(`classroom-dashboard`)?.classList.add(`hide`),document.getElementById(`auth-screen`)?.classList.remove(`hide`)),!0}window.addEventListener(`pageshow`,()=>{B()});function V(){let e=document.querySelector(`.header-nav-tabs .nav-tabs`);if(!e)return;if(window.innerWidth>=768){let t=document.getElementById(`apk-nav-liquid-indicator`);t&&t.remove(),e.querySelectorAll(`.nav-tab`).forEach(t=>{t.__tabletBound||(t.__tabletBound=!0,t.addEventListener(`click`,()=>{e.querySelectorAll(`.nav-tab`).forEach(e=>{e.classList.remove(`active`),e.classList.remove(`floating-active`)}),t.classList.add(`active`)}))});return}let t=document.getElementById(`apk-nav-liquid-indicator`);t||(t=document.createElement(`span`),t.id=`apk-nav-liquid-indicator`,t.setAttribute(`aria-hidden`,`true`),t.style.opacity=`0`,e.insertBefore(t,e.firstChild));let n=(e,n=!1)=>{!e||e.offsetWidth===0||(n&&(t.style.transition=`none`),t.style.width=`${e.offsetWidth}px`,t.style.height=`${e.offsetHeight}px`,t.style.transform=`translate3d(${e.offsetLeft}px, ${e.offsetTop}px, 0)`,t.style.opacity=`1`,n&&(t.offsetWidth,t.style.transition=``))},r=e.querySelector(`.nav-tab.active`),i=sessionStorage.getItem(`nnl_prev_nav_id`),a=i?document.getElementById(i):null;a&&r&&a!==r?(n(a,!0),requestAnimationFrame(()=>{n(r,!1)}),sessionStorage.removeItem(`nnl_prev_nav_id`)):r&&n(r,!0),e.querySelectorAll(`.nav-tab`).forEach(t=>{t.addEventListener(`pointerenter`,()=>{e.querySelectorAll(`.nav-tab`).forEach(e=>e.classList.remove(`floating-active`)),t.classList.add(`floating-active`),n(t,!1)}),t.addEventListener(`pointerdown`,()=>{e.querySelectorAll(`.nav-tab`).forEach(e=>e.classList.remove(`floating-active`)),t.classList.add(`floating-active`),n(t,!1)}),t.addEventListener(`click`,()=>{let r=e.querySelector(`.nav-tab.active`);r&&r.id&&sessionStorage.setItem(`nnl_prev_nav_id`,r.id),e.querySelectorAll(`.nav-tab`).forEach(e=>e.classList.remove(`floating-active`)),t.classList.add(`floating-active`),requestAnimationFrame(()=>{n(e.querySelector(`.nav-tab.active`)||t,!1)})})}),e.addEventListener(`pointerleave`,()=>{e.querySelectorAll(`.nav-tab`).forEach(e=>e.classList.remove(`floating-active`));let t=e.querySelector(`.nav-tab.active`);t&&(t.classList.add(`floating-active`),n(t,!1))}),window.addEventListener(`resize`,()=>{let t=e.querySelector(`.nav-tab.active`);t&&n(t,!0)})}function H(e){e&&e.querySelectorAll(`.class-card, .subject-card, .note-doc-card, .sd-lecture-card, .brochure-card, .test-card, .doc-card, .continue-watching-card`).forEach((e,t)=>{e.classList.contains(`apk-card-arrange`)||(e.style.setProperty(`--card-i`,Math.min(t,16)),e.classList.add(`apk-card-arrange`))})}function U(){if(document.getElementById(`apk-ptr-disc`))return;let e=document.createElement(`div`);e.id=`apk-ptr-disc`,e.className=`apk-ptr-disc`,e.innerHTML=`
    <svg class="apk-ptr-spinner" viewBox="0 0 24 24" fill="none">
      <circle class="apk-ptr-bg" cx="12" cy="12" r="9" stroke="currentColor" stroke-width="2.5" opacity="0.18"/>
      <circle class="apk-ptr-arc" cx="12" cy="12" r="9" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-dasharray="56" stroke-dashoffset="40"/>
    </svg>
  `,document.body.appendChild(e);let t=0,n=!1,r=!1,i=0,a=()=>window.pageYOffset||document.documentElement.scrollTop||document.body.scrollTop||0,o=()=>!!document.querySelector(`.quiz-viewer-overlay:not(.hide), .pdf-modal-overlay:not(.hide), .recording-viewer-overlay:not(.hide), #apk-side-panel:not(.hide), #apk-batch-sheet`);window.addEventListener(`touchstart`,e=>{r||e.touches.length!==1||o()||e.target.closest(`#apk-companion-pet`)||a()<=4&&(t=e.touches[0].clientY,n=!0,i=0)},{passive:!0}),window.addEventListener(`touchmove`,o=>{if(!n||r)return;let s=o.touches[0].clientY-t;if(s<=6||a()>4){i>0&&(i=0,e.classList.remove(`visible`,`ready`),e.style.transform=``);return}if(i=Math.min(85,(s-6)*.45),i>10){e.classList.add(`visible`);let t=i>=48;e.classList.toggle(`ready`,t);let n=e.querySelector(`.apk-ptr-arc`);if(n){let e=Math.max(8,56-i/48*44);n.style.strokeDashoffset=e}e.style.transform=`translate3d(-50%, ${Math.round(i)}px, 0) rotate(${Math.round(i*4)}deg)`}},{passive:!0});let s=()=>{if(n)if(n=!1,i>=48&&!r){r=!0,e.classList.add(`visible`,`ready`,`spinning`),e.style.transform=`translate3d(-50%, 34px, 0)`;let t=document.getElementById(`refetch-btn`)||document.getElementById(`videos-refetch-btn`)||document.getElementById(`notes-refetch-btn`)||document.getElementById(`tests-refetch-btn`);t?t.click():window.location.reload(),setTimeout(()=>{r=!1,i=0,e.classList.remove(`visible`,`ready`,`spinning`),e.style.transform=``},700)}else i=0,e.classList.remove(`visible`,`ready`),e.style.transform=``};window.addEventListener(`touchend`,s,{passive:!0}),window.addEventListener(`touchcancel`,s,{passive:!0})}function W(){document.body.classList.add(`apk-shell-active`);try{(typeof window<`u`&&(window.AndroidAuthBridge||window.AndroidThemeBridge||window.__NNL_ANDROID_APK__)||typeof navigator<`u`&&/NightingaleAndroid/i.test(navigator.userAgent))&&document.body.classList.add(`is-native-android-apk`)}catch{}if(!document.getElementById(`apk-ambient-bg`)){let e=document.createElement(`div`);e.id=`apk-ambient-bg`,document.body.prepend(e)}if(!B())return;z(),V(),j(),D(),U(),y(),E(document.body),H(document.body);let e=()=>{requestAnimationFrame(()=>{let e=document.querySelector(`.header-nav-tabs .nav-tab.active`),t=document.getElementById(`apk-nav-liquid-indicator`);e&&t&&t.style.width===``&&(t.style.width=`${e.offsetWidth}px`,t.style.height=`${e.offsetHeight}px`,t.style.transform=`translate3d(${e.offsetLeft}px, ${e.offsetTop}px, 0)`);let n=document.getElementById(`apk-hamburger-btn`);n&&(document.body.classList.contains(`apk-side-open`)||document.body.classList.contains(`apk-is-auth`)?(n.style.setProperty(`display`,`none`,`important`),n.style.setProperty(`visibility`,`hidden`,`important`)):(n.style.removeProperty(`display`),n.style.removeProperty(`visibility`),n.style.removeProperty(`opacity`),n.style.removeProperty(`pointer-events`)))})};document.addEventListener(`click`,e,{passive:!0}),window.addEventListener(`popstate`,e,{passive:!0})}document.readyState===`loading`?document.addEventListener(`DOMContentLoaded`,W):W();